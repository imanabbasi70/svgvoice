import fs from 'node:fs/promises';
import { config } from '../config/env.js';

/**
 * Standard error class for all Google API client failures.
 */
export class GoogleClientError extends Error {
  /**
   * @param {string} code Machine-readable error code
   * @param {string} message Human-readable error message (sanitized)
   * @param {number|null} statusCode HTTP status code if available
   * @param {boolean} canRetry Whether this error is retryable
   * @param {object|null} details Additional technical details (sanitized)
   */
  constructor(code, message, statusCode = null, canRetry = false, details = null) {
    super(message);
    this.name = 'GoogleClientError';
    this.code = code;
    this.statusCode = statusCode;
    this.canRetry = canRetry;
    this.details = details;
  }
}

/**
 * Strips API keys or credentials from text.
 * @param {string} text
 * @param {string} apiKey
 * @returns {string}
 */
function sanitize(text, apiKey) {
  if (!text || typeof text !== 'string') return '';
  let result = text;
  if (apiKey && apiKey.length > 4) {
    result = result.split(apiKey).join('[REDACTED]');
  }
  result = result.replace(/key=[a-zA-Z0-9_\-]+/gi, 'key=[REDACTED]');
  result = result.replace(/x-goog-api-key:\s*[^\s]+/gi, 'x-goog-api-key: [REDACTED]');
  return result;
}

/**
 * Google Gemini STT & Files Client
 */
export class GoogleClient {
  /**
   * @param {object} [options]
   * @param {string} [options.apiKey]
   * @param {string} [options.baseUrl]
   * @param {number} [options.timeoutMs]
   * @param {typeof fetch} [options.fetchFn]
   */
  constructor(options = {}) {
    this.apiKey = options.apiKey !== undefined ? options.apiKey : config.geminiApiKey;
    this.baseUrl = options.baseUrl || config.googleApiBaseUrl;
    this.timeoutMs = options.timeoutMs || config.googleApiTimeoutMs || 60000;
    this.fetchFn = options.fetchFn || globalThis.fetch;
  }

  /**
   * Validates presence of API key.
   * @private
   */
  _ensureApiKey() {
    if (!this.apiKey || this.apiKey.trim() === '') {
      throw new GoogleClientError(
        'AUTHENTICATION_ERROR',
        'Google Gemini API key is not configured on the backend server.',
        401,
        false
      );
    }
  }

  /**
   * Performs fetch with timeout and error wrapping.
   * @private
   */
  async _request(url, options = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchFn(url, {
        ...options,
        signal: controller.signal
      });
      return response;
    } catch (err) {
      if (err.name === 'AbortError') {
        throw new GoogleClientError(
          'TIMEOUT_ERROR',
          `Request to Google API timed out after ${this.timeoutMs}ms.`,
          408,
          true
        );
      }
      throw new GoogleClientError(
        'NETWORK_ERROR',
        `Network error during communication with Google API: ${sanitize(err.message, this.apiKey)}`,
        null,
        true
      );
    } finally {
      clearTimeout(timeout);
    }
  }

  /**
   * Maps HTTP error responses to typed GoogleClientError.
   * @private
   */
  _handleHttpError(status, rawBody) {
    let parsedMessage = '';
    let errorDetails = null;

    try {
      const json = JSON.parse(rawBody);
      if (json.error) {
        parsedMessage = json.error.message || json.error.status || '';
        errorDetails = json.error;
      }
    } catch {
      parsedMessage = rawBody.slice(0, 300);
    }

    const cleanMsg = sanitize(parsedMessage, this.apiKey);

    switch (status) {
      case 401:
      case 403:
        throw new GoogleClientError(
          'AUTHENTICATION_ERROR',
          `Google API authentication failed: ${cleanMsg || 'Invalid or unauthorized API key.'}`,
          status,
          false,
          errorDetails
        );
      case 400:
        throw new GoogleClientError(
          'BAD_REQUEST',
          `Invalid request to Google API: ${cleanMsg || 'Malformed parameters.'}`,
          status,
          false,
          errorDetails
        );
      case 413:
        throw new GoogleClientError(
          'FILE_LIMIT_EXCEEDED',
          `Uploaded file exceeds Google API size limits: ${cleanMsg || 'Payload too large.'}`,
          status,
          false,
          errorDetails
        );
      case 429:
        throw new GoogleClientError(
          'RATE_LIMIT_EXCEEDED',
          `Google API rate limit or quota exceeded: ${cleanMsg || 'Too many requests.'}`,
          status,
          true,
          errorDetails
        );
      case 500:
      case 502:
      case 503:
      case 504:
        throw new GoogleClientError(
          'GOOGLE_SERVER_ERROR',
          `Google service unavailable or internal error (HTTP ${status}): ${cleanMsg || 'Try again later.'}`,
          status,
          true,
          errorDetails
        );
      default:
        throw new GoogleClientError(
          'GOOGLE_SERVER_ERROR',
          `Unexpected HTTP ${status} from Google API: ${cleanMsg}`,
          status,
          status >= 500,
          errorDetails
        );
    }
  }

  /**
   * Uploads an audio file to Google Files API.
   *
   * @param {object} params
   * @param {Buffer|Uint8Array} [params.fileBuffer]
   * @param {string} [params.filePath]
   * @param {string} params.mimeType (e.g. 'audio/mp4', 'audio/wav', 'audio/mp3')
   * @param {string} [params.displayName]
   * @returns {Promise<{ name: string, uri: string, mimeType: string, sizeBytes?: number }>}
   */
  async uploadAudioFile({ fileBuffer, filePath, mimeType, displayName = 'audio_recording' }) {
    this._ensureApiKey();

    let buffer = fileBuffer;
    if (!buffer && filePath) {
      buffer = await fs.readFile(filePath);
    }

    if (!buffer || buffer.length === 0) {
      throw new GoogleClientError(
        'BAD_REQUEST',
        'Cannot upload empty or non-existent audio buffer.',
        400,
        false
      );
    }

    const uploadUrl = `${this.baseUrl}/upload/v1beta/files?uploadType=multipart`;

    const boundary = `----AvanisMultipartBoundary${Date.now()}`;
    const metadataPart = JSON.stringify({
      file: {
        displayName,
        mimeType
      }
    });

    // Construct standard multipart body
    const preBody = Buffer.from(
      `--${boundary}\r\n` +
      `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
      `${metadataPart}\r\n` +
      `--${boundary}\r\n` +
      `Content-Type: ${mimeType}\r\n\r\n`
    );
    const postBody = Buffer.from(`\r\n--${boundary}--\r\n`);
    const fullBody = Buffer.concat([preBody, buffer, postBody]);

    const response = await this._request(uploadUrl, {
      method: 'POST',
      headers: {
        'x-goog-api-key': this.apiKey,
        'Content-Type': `multipart/related; boundary=${boundary}`,
        'Content-Length': fullBody.length.toString()
      },
      body: fullBody
    });

    const responseText = await response.text();
  console.log("[DIAG] [Google Interactions API Response Status]:", response.status);
  console.log("[DIAG] [Google Interactions API Response Raw Body]:", responseText);
  console.log("[DIAG] [Google Files API Response Status]:", response.status);
  console.log("[DIAG] [Google Files API Response Raw Body]:", responseText);

    if (!response.ok) {
      this._handleHttpError(response.status, responseText);
    }

    let json;
    try {
      json = JSON.parse(responseText);
    } catch {
      throw new GoogleClientError(
        'INVALID_RESPONSE',
        'Google Files API returned non-JSON response.',
        response.status,
        false
      );
    }

    const file = json.file || json;
    if (!file || (!file.uri && !file.name)) {
      throw new GoogleClientError(
        'INVALID_RESPONSE',
        'Google Files API response missing file uri or name.',
        response.status,
        false
      );
    }

    const fileUri = file.uri || `${this.baseUrl}/v1beta/${file.name}`;
    const fileName = file.name || (file.uri ? file.uri.split('/files/')[1] : null);

    return {
      name: fileName,
      uri: fileUri,
      mimeType: file.mimeType || mimeType,
      sizeBytes: file.sizeBytes ? parseInt(file.sizeBytes, 10) : buffer.length,
      rawHttpStatus: response.status,
      rawJson: json
    };
  }

  /**
   * Calls Google Interactions API to transcribe an uploaded audio file.
   *
   * @param {object} params
   * @param {string} params.fileUri File URI from Files API
   * @param {string} params.mimeType File MIME type
   * @param {object} [params.options]
   * @param {string} [params.options.mode] 'smart' (default) or 'verbatim'
   * @param {string[]} [params.options.languageCodes] e.g. ['fa']
   * @returns {Promise<{ text: string, detectedLanguage?: string, durationSeconds?: number, rawStatus?: string, id?: string }>}
   */
  async createTranscriptionInteraction({ fileUri, mimeType, options = {} }) {
    this._ensureApiKey();

    if (!fileUri) {
      throw new GoogleClientError(
        'BAD_REQUEST',
        'File URI is required for transcription interaction.',
        400,
        false
      );
    }

    const interactionUrl = `${this.baseUrl}/v1beta/interactions`;

    const isAdvancedMode = Boolean(options.enableTimestamps || options.enableDiarization);
    const mode = isAdvancedMode ? 'verbatim' : (options.mode || 'smart');

    const transcriptionConfig = {
      mode,
      language_codes: options.languageCodes || ['fa']
    };

    if (options.enableTimestamps) {
      transcriptionConfig.enable_word_time_offsets = true;
    }
    if (options.enableDiarization) {
      transcriptionConfig.enable_speaker_diarization = true;
    }

    const requestBody = {
      model: 'gemini-3.5-transcribe',
      input: [
        {
          type: 'audio',
          uri: fileUri,
          mime_type: mimeType
        }
      ],
      generation_config: {
        transcription_config: transcriptionConfig
      }
    };

    const response = await this._request(interactionUrl, {
      method: 'POST',
      headers: {
        'x-goog-api-key': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    const responseText = await response.text();

    if (!response.ok) {
      this._handleHttpError(response.status, responseText);
    }

    let json;
    try {
      json = JSON.parse(responseText);
    } catch {
      throw new GoogleClientError(
        'INVALID_RESPONSE',
        'Google Interactions API returned malformed JSON.',
        response.status,
        false
      );
    }

    const extractedText = this._extractTranscriptionText(json);

    if (extractedText === null || extractedText === undefined) {
      throw new GoogleClientError(
        'INVALID_RESPONSE',
        'Google Interactions API response did not contain transcribed text.',
        response.status,
        false
      );
    }

    return {
      text: extractedText.trim(),
      detectedLanguage: json.detected_language || options.languageCodes?.[0] || 'fa',
      durationSeconds: json.duration_seconds || null,
      rawStatus: json.status || 'completed',
      id: json.id || null,
      rawHttpStatus: response.status,
      rawJson: json,
      extractedLength: extractedText.trim().length,
      extractorPath: "Standard Google Interactions Extractor"
    };
  }

  /**
   * Robustly extracts transcribed text from Google response variants.
   * @private
   */
  _extractTranscriptionText(data) {
    if (!data) return null;

    // 1. Direct output_text or text at root level (canonical Interactions API schema)
    if (typeof data.output_text === 'string') return data.output_text;
    if (typeof data.text === 'string') return data.text;
    if (typeof data.transcript === 'string') return data.transcript;

    // 2. Standard Interactions API: outputs array
    if (Array.isArray(data.outputs)) {
      for (const output of data.outputs) {
        if (typeof output?.output_text === 'string') return output.output_text;
        if (typeof output?.text === 'string') return output.text;
        if (typeof output?.transcript === 'string') return output.transcript;
        if (typeof output?.content === 'string') return output.content;
        if (Array.isArray(output?.parts)) {
          const part = output.parts.find(p => typeof p?.text === 'string' || typeof p?.output_text === 'string');
          if (part) return part.output_text || part.text;
        }
      }
    }

    // 3. Interactions API: steps array (canonical for multimodal interactions)
    if (Array.isArray(data.steps)) {
      const texts = [];
      for (const step of data.steps) {
        if (Array.isArray(step?.content)) {
          for (const item of step.content) {
            if (typeof item?.text === 'string' && item.text.trim()) {
              texts.push(item.text.trim());
            } else if (typeof item?.output_text === 'string' && item.output_text.trim()) {
              texts.push(item.output_text.trim());
            }
          }
        } else if (typeof step?.content === 'string' && step.content.trim()) {
          texts.push(step.content.trim());
        }
      }
      if (texts.length > 0) {
        return texts.join('\n');
      }
    }

    // 4. Fallback: Gemini content candidates
    if (Array.isArray(data.candidates) && data.candidates[0]?.content?.parts) {
      const part = data.candidates[0].content.parts.find(p => typeof p?.text === 'string');
      if (part) return part.text;
    }

    // 5. Completed status with no speech detected / empty text
    if (data.status === 'completed') {
      return '';
    }

    return null;
  }

  /**
   * Deletes an uploaded file from Google Files API (Best-effort cleanup).
   *
   * @param {string} fileNameOrUri Name (e.g. 'files/abc123xyz') or full URI
   * @returns {Promise<boolean>} True if successfully deleted, false otherwise
   */
  async deleteAudioFile(fileNameOrUri) {
    if (!this.apiKey || !fileNameOrUri) return false;

    try {
      let resourcePath = fileNameOrUri;
      if (resourcePath.includes('/files/')) {
        const parts = resourcePath.split('/files/');
        resourcePath = `files/${parts[parts.length - 1]}`;
      }

      const deleteUrl = `${this.baseUrl}/v1beta/${resourcePath}`;

      const response = await this._request(deleteUrl, {
        method: 'DELETE',
        headers: {
          'x-goog-api-key': this.apiKey
        }
      });

      return response.ok;
    } catch {
      // Best-effort cleanup: never throw from deleteAudioFile
      return false;
    }
  }
}
