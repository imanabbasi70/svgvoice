import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load .env from project root if present
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

export const config = {
  port: parseInt(process.env.PORT || process.env.BACKEND_PORT || '3000', 10),
  host: process.env.HOST || '0.0.0.0',
  nodeEnv: process.env.NODE_ENV || 'development',
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  googleApiBaseUrl: process.env.GOOGLE_API_BASE_URL || 'https://generativelanguage.googleapis.com',
  googleApiTimeoutMs: parseInt(process.env.GOOGLE_API_TIMEOUT_MS || '60000', 10),
  maxAudioUploadBytes: parseInt(process.env.MAX_AUDIO_UPLOAD_BYTES || '26214400', 10), // 25 MB default
  rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX || '30', 10),
  rateLimitTimeWindowMs: parseInt(process.env.RATE_LIMIT_TIME_WINDOW_MS || '60000', 10)
};
