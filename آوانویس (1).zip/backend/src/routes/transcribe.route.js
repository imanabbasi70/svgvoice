import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { pipeline } from 'node:stream/promises';
import { config } from '../config/env.js';
import { TranscriptionService } from '../services/transcription.service.js';
import { TranscriptionServiceError, resolveCanonicalMimeType } from '../services/transcription.errors.js';

/**
 * Parses and validates boolean query or multipart field.
 * @param {string|boolean|undefined} val
 * @param {string} fieldName
 * @returns {boolean}
 */
function parseBooleanField(val, fieldName) {
  if (val === undefined || val === null || val === '') return false;
  if (typeof val === 'boolean') return val;
  const str = String(val).trim().toLowerCase();
  if (str === 'true' || str === '1') return true;
  if (str === 'false' || str === '0') return false;
  throw new TranscriptionServiceError('BAD_REQUEST', `فیلد ${fieldName} باید یک مقدار بولی معتبر (true/false) باشد.`, 400, false);
}

/**
 * Fastify plugin for POST /api/v1/transcribe
 * @param {import('fastify').FastifyInstance} fastify
 * @param {object} [pluginOptions]
 * @param {TranscriptionService} [pluginOptions.transcriptionService]
 */
export async function transcribeRoute(fastify, pluginOptions = {}) {
  const service = pluginOptions.transcriptionService || new TranscriptionService();

  fastify.post('/api/v1/transcribe', async (request, reply) => {
    console.log('[DIAG] [Request Received]', new Date().toISOString(), 'Headers:', JSON.stringify(request.headers));
    let tempFilePath = null;
    let isRequestCompleted = false;
    const abortController = new AbortController();

    try {
      if (!request.isMultipart()) {
        return reply.status(400).send({
          success: false,
          error: {
            code: 'BAD_REQUEST',
            message: 'درخواست باید با فرمت multipart/form-data ارسال شود.',
            canRetry: false
          }
        });
      }

      const maxAudioLimit = pluginOptions.limits?.fileSize || config.maxAudioUploadBytes;

      const parts = request.parts({
        limits: {
          fileSize: maxAudioLimit,
          files: 1
        }
      });

      let audioPartReceived = false;
      let canonicalMime = null;
      let totalBytesWritten = 0;

      // Request options
      let languageCode = 'fa';
      let mode = 'smart';
      let enableTimestamps = false;
      let enableSpeakerDiarization = false;
      let durationSeconds = null;

      for await (const part of parts) {
        if (abortController.signal.aborted) {
          throw new TranscriptionServiceError('OPERATION_CANCELLED', 'درخواست توسط کلاینت لغو شد.', 499, false);
        }

        if (part.type === 'file') {
          if (part.fieldname !== 'audio') {
            // Drain unexpected file stream
            await part.toBuffer();
            continue;
          }

          if (audioPartReceived) {
            await part.toBuffer();
            throw new TranscriptionServiceError('BAD_REQUEST', 'فقط ارسال یک فایل صوتی در فیلد audio مجاز است.', 400, false);
          }

          audioPartReceived = true;

          // Validate MIME type
          canonicalMime = resolveCanonicalMimeType(part.mimetype);
          if (!canonicalMime) {
            await part.toBuffer(); // drain stream
            throw new TranscriptionServiceError(
              'INVALID_AUDIO_FORMAT',
              `فرمت فایل صوتی '${part.mimetype}' پشتیبانی نمی‌شود.`,
              415,
              false
            );
          }

          // Generate secure randomized temporary file path (prevent directory traversal)
          const safeTempName = `avanis_${Date.now()}_${crypto.randomBytes(16).toString('hex')}.tmp`;
          tempFilePath = path.join(os.tmpdir(), safeTempName);
  console.log('[DIAG] [Temp File Target]', tempFilePath, 'MIME:', part.mimetype);

          const writeStream = fs.createWriteStream(tempFilePath);

          // Stream to temporary file while tracking byte count
          part.file.on('data', (chunk) => {
            totalBytesWritten += chunk.length;
            if (totalBytesWritten > maxAudioLimit) {
              part.file.destroy(new Error('FILE_TOO_LARGE'));
            }
          });

          try {
            await pipeline(part.file, writeStream);
          } catch (streamErr) {
            if (part.file.truncated || streamErr.message === 'FILE_TOO_LARGE' || totalBytesWritten > maxAudioLimit) {
              throw new TranscriptionServiceError(
                'FILE_TOO_LARGE',
                `حجم فایل صوتی از سقف مجاز سرور (${Math.max(1, Math.round(maxAudioLimit / (1024 * 1024)))} مگابایت) بیشتر است.`,
                413,
                false
              );
            }
            throw streamErr;
          }

          if (part.file.truncated || totalBytesWritten > maxAudioLimit) {
            throw new TranscriptionServiceError(
              'FILE_TOO_LARGE',
              `حجم فایل صوتی از سقف مجاز سرور (${Math.max(1, Math.round(maxAudioLimit / (1024 * 1024)))} مگابایت) بیشتر است.`,
              413,
              false
            );
          }
        } else if (part.type === 'field') {
          // Parse and validate supported options
          switch (part.fieldname) {
            case 'languageCode': {
              const val = String(part.value || '').trim();
              if (val.length > 0) {
                if (!/^[a-zA-Z]{2,3}(-[a-zA-Z0-9]+)?$/.test(val)) {
                  throw new TranscriptionServiceError('BAD_REQUEST', 'کد زبان (languageCode) ارسالی نامعتبر است.', 400, false);
                }
                languageCode = val;
              }
              break;
            }
            case 'mode': {
              const val = String(part.value || '').trim().toLowerCase();
              if (val !== 'smart' && val !== 'verbatim') {
                throw new TranscriptionServiceError('BAD_REQUEST', 'حالت پردازش (mode) باید فقط smart یا verbatim باشد.', 400, false);
              }
              mode = val;
              break;
            }
            case 'enableTimestamps': {
              enableTimestamps = parseBooleanField(part.value, 'enableTimestamps');
              break;
            }
            case 'enableSpeakerDiarization': {
              enableSpeakerDiarization = parseBooleanField(part.value, 'enableSpeakerDiarization');
              break;
            }
            case 'durationSeconds': {
              const strVal = String(part.value || '').trim();
              if (strVal.length > 0) {
                const parsedNum = Number(strVal);
                if (!Number.isFinite(parsedNum) || parsedNum < 0) {
                  throw new TranscriptionServiceError('BAD_REQUEST', 'مدت زمان صوت (durationSeconds) باید عددی نامنفی باشد.', 400, false);
                }
                durationSeconds = parsedNum;
              }
              break;
            }
          }
        }
      }

      // Check audio existence
      if (!audioPartReceived || !tempFilePath) {
        throw new TranscriptionServiceError('BAD_REQUEST', 'فایل صوتی در فیلد audio ارسال نشده است.', 400, false);
      }

      // Check audio 0-bytes
      if (totalBytesWritten === 0) {
        throw new TranscriptionServiceError('INVALID_AUDIO_FORMAT', 'فایل صوتی ارسال‌شده خالی است (۰ بایت).', 400, false);
      }

      // Execute transcription service
      const result = await service.transcribeAudioFile({
        filePath: tempFilePath,
        mimeType: canonicalMime,
        options: {
          language: languageCode,
          mode,
          enable_timestamps: enableTimestamps,
          enable_diarization: enableSpeakerDiarization,
          durationSeconds,
          deleteLocalFileOnFinish: false // Route manages temporary file in its finally
        },
        signal: abortController.signal
      });

      console.log('[DIAG] [Final Result to Android]', JSON.stringify(result));
  return reply.status(200).send({
        success: true,
        data: {
          fullText: result.fullText,
          detectedLanguage: result.detectedLanguage || languageCode,
          confidence: null,
          durationSeconds: result.durationSeconds !== undefined ? result.durationSeconds : null,
          segments: []
        }
      });

    } catch (err) {
      if (err instanceof TranscriptionServiceError) {
        return reply.status(err.statusCode).send({
          success: false,
          error: {
            code: err.code,
            message: err.message,
            canRetry: err.canRetry
          }
        });
      }

      request.log.error(err, 'Unexpected error handling /api/v1/transcribe');

      return reply.status(500).send({
        success: false,
        error: {
          code: 'TRANSCRIPTION_FAILED',
          message: 'خطای داخلی در پردازش رونویسی صوتی رخ داده است.',
          canRetry: false
        }
      });

    } finally {
      isRequestCompleted = true;
      // finished

      // Assured cleanup of temporary local file
      if (tempFilePath) {
        try {
          await fsp.unlink(tempFilePath);
        } catch {
          // Ignore unlink errors
        }
      }
    }
  });
}
