/**
 * Health check route plugin for Fastify.
 * @param {import("fastify").FastifyInstance} fastify
 */
export async function healthRoute(fastify) {
  fastify.get("/health", async (request, reply) => {
    console.log("HEALTH_REQUEST_RECEIVED", "REMOTE_IP=" + request.ip, "METHOD=" + request.method, "PATH=" + request.url);
    fastify.log.info({
      msg: "HEALTH_REQUEST_RECEIVED",
      remoteIp: request.ip,
      method: request.method,
      path: request.url
    });
    return {
      status: "ok",
      service: "avanis-proxy",
      timestamp: new Date().toISOString()
    };
  });
}
