/**
 * Standard error class for the Transcription Service layer.
 */
export class TranscriptionServiceError extends Error {
  /**
   * @param {string} code Standard machine-readable error code
   * @param {string} message Human-readable safe error message
   * @param {number} statusCode Suggested HTTP status code
   * @param {boolean} canRetry Whether client can retry
   * @param {object|null} details Additional technical details (sanitized)
   */
  constructor(code, message, statusCode = 500, canRetry = false, details = null) {
    super(message);
    this.name = 'TranscriptionServiceError';
    this.code = code;
    this.statusCode = statusCode;
    this.canRetry = canRetry;
    this.details = details;
  }
}

/**
 * Officially documented canonical audio formats supported by Gemini 3.5 Transcribe:
 * WAV, MP3, AIFF, AAC, OGG, FLAC, MPEG, M4A, L16, Opus, ALAW, MULAW, WebM.
 */
export const CANONICAL_GOOGLE_MIME_TYPES = new Set([
  'audio/wav',
  'audio/mp3',
  'audio/aiff',
  'audio/aac',
  'audio/ogg',
  'audio/flac',
  'audio/mpeg',
  'audio/m4a',
  'audio/mp4',
  'audio/l16',
  'audio/opus',
  'audio/alaw',
  'audio/mulaw',
  'audio/webm'
]);

/**
 * Common client/OS input MIME aliases mapped to their canonical Google MIME types.
 * These are strictly input normalization mappings, not additional speculative formats.
 */
export const INPUT_MIME_ALIASES = {
  'audio/x-m4a': 'audio/mp4',
  'audio/x-wav': 'audio/wav',
  'audio/wave': 'audio/wav',
  'audio/x-aiff': 'audio/aiff',
  'audio/x-flac': 'audio/flac',
  'audio/x-pn-wav': 'audio/wav'
};

/**
 * Resolves an incoming MIME type to its canonical Google MIME type.
 * @param {string} mimeType
 * @returns {string|null} Canonical MIME type or null if unsupported.
 */
export function resolveCanonicalMimeType(mimeType) {
  if (!mimeType || typeof mimeType !== 'string') return null;
  const normalized = mimeType.trim().toLowerCase();
  if (CANONICAL_GOOGLE_MIME_TYPES.has(normalized)) {
    return normalized;
  }
  if (INPUT_MIME_ALIASES[normalized]) {
    return INPUT_MIME_ALIASES[normalized];
  }
  return null;
}
