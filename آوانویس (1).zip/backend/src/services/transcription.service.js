import fs from "node:fs/promises";
import { GoogleGenAI } from "@google/genai";
import {
  TranscriptionServiceError,
  resolveCanonicalMimeType
} from "./transcription.errors.js";

const MODELS_PRIORITY = [
  "gemini-3.5-transcribe",
  "gemini-3.1-flash-lite-preview",
  "gemini-3.5-flash",
  "gemini-3.8-flash"
];

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export class TranscriptionService {
  constructor(options = {}) {
    this.apiKey = process.env.GEMINI_API_KEY;
  }

  async transcribeAudioFile({
    filePath,
    mimeType,
    options = {},
    signal = null
  }) {
    const language = options.language || "fa";
    const deleteLocalFile = options.deleteLocalFileOnFinish !== false;

    try {
      if (signal?.aborted) {
        throw new TranscriptionServiceError("OPERATION_CANCELLED", "عملیات لغو شد.", 499, false);
      }

      const stat = await fs.stat(filePath);
      if (stat.size === 0) {
        throw new TranscriptionServiceError("INVALID_AUDIO_FORMAT", "فایل صوتی خالی است.", 400, false);
      }

      const canonicalMime = resolveCanonicalMimeType(mimeType) || "audio/mp4";
      const apiKey = this.apiKey || process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new TranscriptionServiceError("GOOGLE_AUTHENTICATION_ERROR", "کلید GEMINI_API_KEY تنظیم نشده است.", 500, false);
      }

      const ai = new GoogleGenAI({ apiKey });
      const buffer = await fs.readFile(filePath);
      const base64Data = buffer.toString("base64");

      console.log("[GenAI Start] Processing audio file with size:", stat.size, "MIME:", canonicalMime);

      let lastError = null;
      let fullText = "";

      for (const model of MODELS_PRIORITY) {
        if (signal?.aborted) break;

        for (let attempt = 1; attempt <= 2; attempt++) {
          try {
            console.log(`[GenAI Attempt] Model: ${model} (attempt ${attempt})`);
            const response = await ai.models.generateContent({
              model,
              contents: [
                {
                  role: "user",
                  parts: [
                    {
                      inlineData: {
                        mimeType: canonicalMime,
                        data: base64Data
                      }
                    },
                    {
                      text: "این فایل صوتی را به زبان فارسی دقیقاً پیاده‌سازی و رونویسی کن. علائم نگارشی مناسب اضافه کن و فقط متن فارسی نهایی را برگردان. اگر صدا خالی، نامفهوم یا بدون کلام بود، بنویس: «هیچ گفتاری شناسایی نشد.»"
                    }
                  ]
                }
              ]
            });

            fullText = (response?.text || "").trim();
            if (!fullText && response?.candidates?.length) {
              for (const cand of response.candidates) {
                if (cand?.content?.parts?.length) {
                  const extracted = cand.content.parts.map(p => {
                    if (p.text) return p.text;
                    if (p.audioTranscription?.text) return p.audioTranscription.text;
                    if (typeof p.audioTranscription === "string") return p.audioTranscription;
                    return "";
                  }).filter(Boolean).join(" ").trim();
                  if (extracted) {
                    fullText = extracted;
                    break;
                  }
                }
              }
            }

            if (fullText) {
              console.log("[GenAI Success] Model:", model, "Output length:", fullText.length, "Preview:", fullText.slice(0, 100));
              lastError = null;
              break;
            }
          } catch (err) {
            console.warn(`[GenAI Model Warn] Model ${model} attempt ${attempt} failed: ${err.message}`);
            lastError = err;
            if (attempt < 2) await sleep(800);
          }
        }

        if (fullText) break;
      }

      if (lastError && !fullText) {
        throw new TranscriptionServiceError(
          "TRANSCRIPTION_FAILED",
          "خطا در پردازش توسط هوش مصنوعی: " + (lastError.message || lastError),
          502,
          true
        );
      }

      return {
        fullText: fullText || "هیچ گفتاری شناسایی نشد.",
        detectedLanguage: language,
        confidence: null,
        durationSeconds: options.durationSeconds || null,
        segments: []
      };
    } catch (err) {
      if (err instanceof TranscriptionServiceError) throw err;
      throw new TranscriptionServiceError(
        "TRANSCRIPTION_FAILED",
        "خطای سیستمی: " + (err.message || err),
        500,
        false
      );
    } finally {
      if (deleteLocalFile && filePath) {
        try { await fs.unlink(filePath); } catch {}
      }
    }
  }
}
