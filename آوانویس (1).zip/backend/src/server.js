import fastifyCors from "@fastify/cors";
import Fastify from 'fastify';
import fastifyMultipart from '@fastify/multipart';
import fastifyRateLimit from '@fastify/rate-limit';
import { config } from './config/env.js';
import { healthRoute } from './routes/health.route.js';
import { transcribeRoute } from './routes/transcribe.route.js';

/**
 * Builds the Fastify application instance.
 * @param {object} options Additional Fastify options
 * @param {import('./services/transcription.service.js').TranscriptionService} [options.transcriptionService]
 * @param {object|false} [options.rateLimit] Rate limiting options or false to disable
 * @returns {import('fastify').FastifyInstance}
 */
export function buildApp(options = {}) {
  const { transcriptionService, limits, rateLimit, ...fastifyOptions } = options;

  const app = Fastify({
    logger: config.nodeEnv === 'test' ? false : {
      level: config.nodeEnv === 'production' ? 'info' : 'debug',
      // Redact sensitive headers from logs
      redact: ['req.headers.authorization', 'req.headers["x-goog-api-key"]']
    },
    ...fastifyOptions
  });

  // Register CORS
  app.register(fastifyCors, {
    origin: "*",
    methods: ["GET", "POST", "OPTIONS"]
  });

  // Register rate limiting unless explicitly disabled
  if (rateLimit !== false) {
    app.register(fastifyRateLimit, {
      max: rateLimit?.max ?? config.rateLimitMax,
      timeWindow: rateLimit?.timeWindow ?? config.rateLimitTimeWindowMs,
      errorResponseBuilder: (request, context) => ({
        statusCode: 429,
        success: false,
        error: {
          code: 'RATE_LIMIT_EXCEEDED',
          message: 'تعداد درخواست‌های ارسالی بیش از سقف مجاز است. لطفاً کمی بعد دوباره تلاش کنید.',
          canRetry: true
        }
      }),
      ...rateLimit
    });
  }

  const uploadLimits = limits || {
    fileSize: config.maxAudioUploadBytes,
    files: 1
  };

  // Register multipart support
  app.register(fastifyMultipart, {
    limits: uploadLimits
  });

  // Register routes
  app.register(healthRoute);
  app.register(transcribeRoute, { transcriptionService, limits: uploadLimits });

  return app;
}

// Start server if executed directly
const isDirectExecution = process.argv[1] && process.argv[1].endsWith('server.js');
if (isDirectExecution) {
  const server = buildApp();

  const start = async () => {
    try {
      await server.listen({ port: config.port, host: config.host });
      server.log.info(`Server running at http://${config.host}:${config.port}`);
    } catch (err) {
      server.log.error(err);
      process.exit(1);
    }
  };

  // Graceful shutdown
  const signals = ['SIGINT', 'SIGTERM'];
  for (const signal of signals) {
    process.on(signal, async () => {
      server.log.info(`Received ${signal}, closing server gracefully...`);
      await server.close();
      process.exit(0);
    });
  }

  start();
}
