# Avanis Backend Proxy

سرور واسط اختصاصی و امن (Backend Proxy) برای سامانه تبدیل گفتار به متن آوانویس.
این سرویس به عنوان دروازه امن بین اپلیکیشن اندروید و سرویس پردازش هوش مصنوعی عمل می‌کند تا هیچ کلید امنیتی (API Key) وارد برنامه موبایل نشود.

---

## ۱. پیش‌نیازها

* **Node.js**: نسخه ۲۲ یا نسخه ۲۰ LTS به بالا (`node -v`)
* **npm**: نسخه ۱۰ به بالا (`npm -v`)

---

## ۲. نصب وابستگی‌ها

وارد پوشه `backend` شوید و پکیج‌ها را نصب کنید:

```bash
cd backend
npm install
```

---

## ۳. تنظیم متغیرهای محیطی

فایل نمونه `.env.example` را کپی کرده و به نام `.env` ذخیره کنید:

```bash
cp .env.example .env
```

محتوای پیش‌فرض فایل `.env`:
```env
PORT=3000
HOST=0.0.0.0
NODE_ENV=development
GEMINI_API_KEY=
```
*(در این مرحله برای تست سلامت، نیازی به وارد کردن کلید نیست).*

---

## ۴. اجرای سرور توسعه (Development)

برای اجرای سرور با قابلیت Hot-reload در Node.js 22:

```bash
npm run dev
```

یا برای اجرای حالت استاندارد:

```bash
npm start
```

---

## ۵. تست و بررسی سلامت سرور (Health Check)

پس از اجرای سرور، با استفاده از مرورگر یا cURL اندپوینت سلامت را فراخوانی کنید:

```bash
curl http://localhost:3000/health
```

پاسخ مورد انتظار (HTTP 200 OK):
```json
{
  "status": "ok",
  "service": "avanis-proxy",
  "timestamp": "2026-09-26T17:18:43.532Z"
}
```

---

## ۶. اجرای تست‌های خودکار

برای اجرای تست‌های واحد (Unit Tests) مبتنی بر تست رانر داخلی Node.js:

```bash
npm test
```

---

## ۷. مشخصات فنی صوتی و محدودیت‌ها (Technical Specifications & Limitations)

### الف) فرمت‌های صوتی رسمی (Canonical MIME Types)
بر اساس مستندات رسمی Google Gemini 3.5 Transcribe، فرمت‌های صوتی مجاز عبارتند از:
* `WAV` (`audio/wav`)
* `MP3` (`audio/mp3`, `audio/mpeg`)
* `AIFF` (`audio/aiff`)
* `AAC` (`audio/aac`)
* `OGG` (`audio/ogg`)
* `FLAC` (`audio/flac`)
* `MPEG` (`audio/mpeg`)
* `M4A` / `MP4` (`audio/m4a`, `audio/mp4`)
* `L16` (`audio/l16`)
* `Opus` (`audio/opus`)
* `ALAW` (`audio/alaw`)
* `MULAW` (`audio/mulaw`)
* `WebM` (`audio/webm`)

*توجه:* مقادیر ورودی مانند `audio/x-m4a` و `audio/x-wav` صرفاً الیاس‌های ورودی کلاینت هستند که قبل از ارسال به Google، به MIMEهای رسمی و Canonical تبدیل می‌شوند.

### ب) محدودیت سنجش مدت زمان صوت (Duration Validation Limitation)
* مقدار `durationSeconds` ارسال‌شده از کلاینت موبایل صرفاً یک **Advisory Client Hint** (پیشنهاد مشورتی کلاینت) است و اندازه‌گیری معتبر و مستقل سمت سرور تلقی نمی‌شود.
* سرور بک‌اند هیچ کتابخانه خارجی سنگینی (مانند ffmpeg) را برای سنجش باینری مدت زمان بارگذاری نمی‌کند و از تولید مقادیر تخمینی یا ساختگی برای مدت زمان خودداری می‌نماید.
* فیلد `durationSeconds` در خروجی رونویسی در صورتی که توسط Google API اعلام نشود، به صورت دقیق مقدار `null` باقی می‌ماند.

---

## ۸. مشخصات قرارداد API رونویسی (`POST /api/v1/transcribe`)

### مشخصات درخواست (Multipart Request):
* **فیلد فایل صوتی (اجباری):** `audio`
* **گزینه‌های اختیاری:**
  * `languageCode`: کد زبان (پیش‌فرض: `fa`)
  * `mode`: حالت رونویسی (`smart` یا `verbatim` - پیش‌فرض: `smart`)
  * `enableTimestamps`: تایم‌استمپ کلمات (`true` یا `false` - پیش‌فرض: `false`)
  * `enableSpeakerDiarization`: تفکیک گویندگان (`true` یا `false` - پیش‌فرض: `false`)
  * `durationSeconds`: طول صوت ارسالی کلاینت به ثانیه (صرفاً پیشنهاد مشورتی کلاینت)

### ساختار پاسخ موفق (HTTP 200 OK):
```json
{
  "success": true,
  "data": {
    "fullText": "متن پیاده‌سازی‌شده صوت...",
    "detectedLanguage": "fa",
    "confidence": null,
    "durationSeconds": null,
    "segments": []
  }
}
```

### ساختار پاسخ خطا (HTTP 4xx / 5xx):
```json
{
  "success": false,
  "error": {
    "code": "INVALID_AUDIO_FORMAT",
    "message": "فرمت فایل صوتی پشتیبانی نمی‌شود.",
    "canRetry": false
  }
}
```

### کدهای خطای استاندارد:
* `BAD_REQUEST` (400): پارامتر یا ورودی نامعتبر
* `FILE_TOO_LARGE` (413): عبور حجم فایل از سقف مجاز سرور (`MAX_AUDIO_UPLOAD_BYTES`)
* `INVALID_AUDIO_FORMAT` (415): عدم تطابق فرمت فایل صوتی با MIMEهای مجاز Google
* `AUDIO_TOO_LONG` (422): عبور مدت زمان صوت از سقف مجاز مدل
* `RATE_LIMIT_EXCEEDED` (429): تعداد درخواست‌های بیش از حد در بازه زمانی (`RATE_LIMIT_MAX`)
* `OPERATION_CANCELLED` (499): انصراف یا قطع زودهنگام اتصال توسط کلاینت
* `GOOGLE_AUTHENTICATION_ERROR` (500): خطای احراز هویت سرور با کلید API
* `GOOGLE_SERVER_ERROR` (502) / `INVALID_GOOGLE_RESPONSE` (502): خطای پاسخ ارائه‌دهنده
* `NETWORK_ERROR` (503): خطای ارتباطی بین سرور پروکسی و گوگل
* `TIMEOUT_ERROR` (504): پایان مهلت زمانی پردازش در گوگل

