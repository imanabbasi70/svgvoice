import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { TranscriptionService } from '../src/services/transcription.service.js';
import { TranscriptionServiceError } from '../src/services/transcription.errors.js';
import { GoogleClientError } from '../src/clients/google.client.js';

const FAKE_SECRET_KEY = 'AIzaSySecretDoNotLeak_9876543210';

/**
 * Creates a temporary file with specified bytes.
 */
async function createTempAudioFile(content = 'fake audio bytes') {
  const tmpFile = path.join(os.tmpdir(), `test_audio_${Date.now()}_${Math.random().toString(36).substring(7)}.m4a`);
  await fs.writeFile(tmpFile, content);
  return tmpFile;
}

/**
 * Checks if a file still exists on disk.
 */
async function fileExists(filePath) {
  try {
    await fs.stat(filePath);
    return true;
  } catch {
    return false;
  }
}

// 1. موفقیت کامل: upload -> interaction -> delete -> cleanup
test('transcribeAudioFile: full success lifecycle with automatic cleanup', async () => {
  const tmpFile = await createTempAudioFile('sample audio 123');

  let uploadCalled = false;
  let interactionCalled = false;
  let deleteCalled = false;

  const fakeGoogleClient = {
    async uploadAudioFile() {
      uploadCalled = true;
      return {
        name: 'files/test_google_123',
        uri: 'https://generativelanguage.googleapis.com/v1beta/files/test_google_123',
        mimeType: 'audio/mp4'
      };
    },
    async createTranscriptionInteraction() {
      interactionCalled = true;
      return {
        text: 'این یک تست موفقیت‌آمیز است.',
        detectedLanguage: 'fa',
        durationSeconds: 42
      };
    },
    async deleteAudioFile(id) {
      deleteCalled = true;
      assert.equal(id, 'files/test_google_123');
      return true;
    }
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  const result = await service.transcribeAudioFile({
    filePath: tmpFile,
    mimeType: 'audio/mp4',
    options: { language: 'fa', mode: 'smart' }
  });

  assert.equal(uploadCalled, true, 'Upload should have been called');
  assert.equal(interactionCalled, true, 'Interaction should have been called');
  assert.equal(deleteCalled, true, 'Google delete should have been called');
  assert.equal(result.fullText, 'این یک تست موفقیت‌آمیز است.');
  assert.equal(result.detectedLanguage, 'fa');
  assert.equal(result.durationSeconds, 42);
  assert.equal(result.confidence, null);
  assert.deepEqual(result.segments, []);

  // Local file must be cleaned up
  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false, 'Local file must be unlinked in finally');
});

// 2. خطا در upload: interaction نباید اجرا شود و local cleanup باید انجام شود
test('transcribeAudioFile: upload failure skips interaction and cleans up local file', async () => {
  const tmpFile = await createTempAudioFile('sample audio');

  let interactionCalled = false;

  const fakeGoogleClient = {
    async uploadAudioFile() {
      throw new GoogleClientError('FILE_LIMIT_EXCEEDED', 'File is too large', 413, false);
    },
    async createTranscriptionInteraction() {
      interactionCalled = true;
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'FILE_TOO_LARGE');
      assert.equal(err.statusCode, 413);
      return true;
    }
  );

  assert.equal(interactionCalled, false, 'Interaction must not be called after upload failure');
  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false, 'Local file must be cleaned up');
});

// 3. خطا در interaction: delete Google باید تلاش شود و local cleanup انجام شود
test('transcribeAudioFile: interaction failure attempts Google deletion and cleans up local file', async () => {
  const tmpFile = await createTempAudioFile('sample audio');
  let deleteCalledWith = null;

  const fakeGoogleClient = {
    async uploadAudioFile() {
      return {
        name: 'files/uploaded_id_999',
        uri: 'https://generativelanguage.googleapis.com/v1beta/files/uploaded_id_999',
        mimeType: 'audio/mp4'
      };
    },
    async createTranscriptionInteraction() {
      throw new GoogleClientError('INVALID_RESPONSE', 'Malformed model output', 502, false);
    },
    async deleteAudioFile(id) {
      deleteCalledWith = id;
      return true;
    }
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'INVALID_GOOGLE_RESPONSE');
      return true;
    }
  );

  assert.equal(deleteCalledWith, 'files/uploaded_id_999', 'Google delete must be attempted even on failure');
  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false, 'Local file must be cleaned up');
});

// 4. خطا در delete: transcription همچنان موفق باشد و local cleanup انجام شود
test('transcribeAudioFile: deleteAudioFile failure does not cause transcription failure', async () => {
  const tmpFile = await createTempAudioFile('sample audio');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      return {
        name: 'files/id_delete_fail',
        uri: 'https://generativelanguage.googleapis.com/v1beta/files/id_delete_fail',
        mimeType: 'audio/mp4'
      };
    },
    async createTranscriptionInteraction() {
      return { text: 'محتوای موفق', detectedLanguage: 'fa' };
    },
    async deleteAudioFile() {
      throw new Error('Google delete endpoint unreachable');
    }
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  const result = await service.transcribeAudioFile({
    filePath: tmpFile,
    mimeType: 'audio/mp4'
  });

  assert.equal(result.fullText, 'محتوای موفق');
  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false, 'Local file must be cleaned up');
});

// 5. فایل local وجود ندارد
test('transcribeAudioFile: throws INVALID_AUDIO_FORMAT when local file does not exist', async () => {
  const fakeGoogleClient = {
    async uploadAudioFile() {},
    async createTranscriptionInteraction() {},
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({
      filePath: '/tmp/non_existent_audio_file_999.m4a',
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'INVALID_AUDIO_FORMAT');
      assert.equal(err.statusCode, 400);
      return true;
    }
  );
});

// 6. فایل خالی (0 bytes)
test('transcribeAudioFile: throws INVALID_AUDIO_FORMAT when audio file is 0 bytes', async () => {
  const emptyFile = await createTempAudioFile('');

  const service = new TranscriptionService({ googleClient: {} });

  await assert.rejects(
    () => service.transcribeAudioFile({
      filePath: emptyFile,
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'INVALID_AUDIO_FORMAT');
      assert.equal(err.statusCode, 400);
      return true;
    }
  );

  const localStillExists = await fileExists(emptyFile);
  assert.equal(localStillExists, false, 'Empty file must be cleaned up');
});

// 7. audio بیش از 3600 ثانیه
test('transcribeAudioFile: throws AUDIO_TOO_LONG when duration exceeds 3600s in normal mode', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const service = new TranscriptionService({ googleClient: {} });

  await assert.rejects(
    () => service.transcribeAudioFile({
      filePath: tmpFile,
      mimeType: 'audio/mp4',
      options: { durationSeconds: 3601 }
    }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'AUDIO_TOO_LONG');
      assert.equal(err.statusCode, 422);
      return true;
    }
  );

  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false);
});

// 8. audio بیش از 1800 ثانیه در حالت timestamps / diarization
test('transcribeAudioFile: throws AUDIO_TOO_LONG when duration exceeds 1800s with timestamps', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const service = new TranscriptionService({ googleClient: {} });

  await assert.rejects(
    () => service.transcribeAudioFile({
      filePath: tmpFile,
      mimeType: 'audio/mp4',
      options: { durationSeconds: 1805, enable_timestamps: true }
    }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'AUDIO_TOO_LONG');
      assert.equal(err.statusCode, 422);
      return true;
    }
  );

  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false);
});

// 9. خطای Network
test('transcribeAudioFile: maps NETWORK_ERROR from GoogleClient', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      throw new GoogleClientError('NETWORK_ERROR', 'Connection reset by peer', null, true);
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'NETWORK_ERROR');
      assert.equal(err.statusCode, 503);
      assert.equal(err.canRetry, true);
      return true;
    }
  );
});

// 10. Timeout
test('transcribeAudioFile: maps TIMEOUT_ERROR from GoogleClient', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      throw new GoogleClientError('TIMEOUT_ERROR', 'Request timed out after 60000ms', 408, true);
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'TIMEOUT_ERROR');
      assert.equal(err.statusCode, 504);
      assert.equal(err.canRetry, true);
      return true;
    }
  );
});

// 11. Google 429
test('transcribeAudioFile: maps RATE_LIMIT_EXCEEDED from GoogleClient', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      throw new GoogleClientError('RATE_LIMIT_EXCEEDED', 'Quota limit exceeded', 429, true);
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'RATE_LIMIT_EXCEEDED');
      assert.equal(err.statusCode, 429);
      assert.equal(err.canRetry, true);
      return true;
    }
  );
});

// 12. Google 5xx
test('transcribeAudioFile: maps GOOGLE_SERVER_ERROR from GoogleClient', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      throw new GoogleClientError('GOOGLE_SERVER_ERROR', 'Internal service error', 503, true);
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'GOOGLE_SERVER_ERROR');
      assert.equal(err.statusCode, 502);
      assert.equal(err.canRetry, true);
      return true;
    }
  );
});

// 13. اطمینان از عدم نشت Secret یا API Key در Error خروجی
test('transcribeAudioFile: ensures API key or internal secret is never leaked in error', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      throw new GoogleClientError(
        'AUTHENTICATION_ERROR',
        `Auth failed with key ${FAKE_SECRET_KEY}`,
        401,
        false
      );
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await assert.rejects(
    () => service.transcribeAudioFile({ filePath: tmpFile, mimeType: 'audio/mp4' }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.ok(!err.message.includes(FAKE_SECRET_KEY));
      assert.equal(err.code, 'GOOGLE_AUTHENTICATION_ERROR');
      return true;
    }
  );
});

// 14. Cancellation via AbortSignal
test('transcribeAudioFile: aborts early when AbortSignal is already cancelled', async () => {
  const tmpFile = await createTempAudioFile('sample');
  const controller = new AbortController();
  controller.abort();

  const service = new TranscriptionService({ googleClient: {} });

  await assert.rejects(
    () => service.transcribeAudioFile({
      filePath: tmpFile,
      mimeType: 'audio/mp4',
      signal: controller.signal
    }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'OPERATION_CANCELLED');
      return true;
    }
  );

  const localStillExists = await fileExists(tmpFile);
  assert.equal(localStillExists, false, 'Local file cleaned up on cancel');
});

// 15. MIME normalization: resolves client alias to canonical Google MIME type
test('transcribeAudioFile: normalizes audio/x-m4a alias to canonical audio/mp4 for Google upload', async () => {
  const tmpFile = await createTempAudioFile('sample');
  let uploadedMime = null;

  const fakeGoogleClient = {
    async uploadAudioFile({ mimeType }) {
      uploadedMime = mimeType;
      return {
        name: 'files/test_alias',
        uri: 'https://generativelanguage.googleapis.com/v1beta/files/test_alias',
        mimeType
      };
    },
    async createTranscriptionInteraction() {
      return { text: 'تست موفق alias' };
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  await service.transcribeAudioFile({
    filePath: tmpFile,
    mimeType: 'audio/x-m4a'
  });

  assert.equal(uploadedMime, 'audio/mp4', 'Input alias audio/x-m4a must map to canonical audio/mp4');
});

// 16. Unsupported MIME rejection
test('transcribeAudioFile: throws 415 when MIME type is not supported by Gemini', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const service = new TranscriptionService({ googleClient: {} });

  await assert.rejects(
    () => service.transcribeAudioFile({
      filePath: tmpFile,
      mimeType: 'audio/unsupported-xyz'
    }),
    (err) => {
      assert.ok(err instanceof TranscriptionServiceError);
      assert.equal(err.code, 'INVALID_AUDIO_FORMAT');
      assert.equal(err.statusCode, 415);
      return true;
    }
  );
});

// 17. Duration nullable when omitted by provider (never fabricated)
test('transcribeAudioFile: durationSeconds remains null when provider does not report it', async () => {
  const tmpFile = await createTempAudioFile('sample');

  const fakeGoogleClient = {
    async uploadAudioFile() {
      return {
        name: 'files/test_null_dur',
        uri: 'https://generativelanguage.googleapis.com/v1beta/files/test_null_dur',
        mimeType: 'audio/mp4'
      };
    },
    async createTranscriptionInteraction() {
      return {
        text: 'متن بدون مدت زمان گوگل',
        detectedLanguage: 'fa'
        // durationSeconds is undefined
      };
    },
    async deleteAudioFile() {}
  };

  const service = new TranscriptionService({ googleClient: fakeGoogleClient });

  const result = await service.transcribeAudioFile({
    filePath: tmpFile,
    mimeType: 'audio/mp4'
  });

  assert.equal(result.durationSeconds, null, 'durationSeconds must remain strictly null when provider omits it');
});
