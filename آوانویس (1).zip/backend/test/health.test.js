import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildApp } from '../src/server.js';

test('GET /health returns 200 with status ok', async () => {
  const app = buildApp();

  const response = await app.inject({
    method: 'GET',
    url: '/health'
  });

  assert.equal(response.statusCode, 200);

  const payload = JSON.parse(response.payload);
  assert.equal(payload.status, 'ok');
  assert.equal(payload.service, 'avanis-proxy');
  assert.ok(payload.timestamp, 'Timestamp should be present');

  await app.close();
});
