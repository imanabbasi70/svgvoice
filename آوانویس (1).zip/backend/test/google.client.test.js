import { test } from 'node:test';
import assert from 'node:assert/strict';
import { GoogleClient, GoogleClientError } from '../src/clients/google.client.js';

const FAKE_API_KEY = 'AIzaSyFakeSecretKey_1234567890abcdefg';
const BASE_URL = 'https://generativelanguage.googleapis.com';

/**
 * Creates a mock fetch function that responds based on matching URL and method.
 */
function createMockFetch(handler) {
  return async (url, options) => {
    return handler(url.toString(), options);
  };
}

// 1. Upload موفق
test('uploadAudioFile: succeeds with valid response', async () => {
  const mockFetch = createMockFetch((url, options) => {
    assert.equal(options.headers['x-goog-api-key'], FAKE_API_KEY);
    assert.ok(options.headers['Content-Type'].includes('multipart/related'));

    return new Response(JSON.stringify({
      file: {
        name: 'files/test123xyz',
        uri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
        mimeType: 'audio/mp4',
        sizeBytes: '4096'
      }
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });
  const result = await client.uploadAudioFile({
    fileBuffer: Buffer.from('fake audio data'),
    mimeType: 'audio/mp4',
    displayName: 'sample.m4a'
  });

  assert.equal(result.name, 'files/test123xyz');
  assert.equal(result.uri, 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz');
  assert.equal(result.mimeType, 'audio/mp4');
  assert.equal(result.sizeBytes, 4096);
});

// 2. Upload با HTTP error (مثلاً 413 File Limit)
test('uploadAudioFile: throws FILE_LIMIT_EXCEEDED on 413', async () => {
  const mockFetch = createMockFetch(() => {
    return new Response(JSON.stringify({
      error: { code: 413, message: 'File size exceeds limit' }
    }), { status: 413 });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  await assert.rejects(
    () => client.uploadAudioFile({
      fileBuffer: Buffer.from('huge audio data'),
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'FILE_LIMIT_EXCEEDED');
      assert.equal(err.statusCode, 413);
      assert.equal(err.canRetry, false);
      return true;
    }
  );
});

// 3. Upload با response نامعتبر
test('uploadAudioFile: throws INVALID_RESPONSE on non-JSON response', async () => {
  const mockFetch = createMockFetch(() => {
    return new Response('<html>Error Gateway</html>', { status: 200 });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  await assert.rejects(
    () => client.uploadAudioFile({
      fileBuffer: Buffer.from('audio bytes'),
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'INVALID_RESPONSE');
      return true;
    }
  );
});

// 4. Interaction موفق با ساختار Interactions API
test('createTranscriptionInteraction: succeeds with smart transcription', async () => {
  let capturedBody = null;

  const mockFetch = createMockFetch((url, options) => {
    assert.equal(url, `${BASE_URL}/v1beta/interactions`);
    assert.equal(options.headers['x-goog-api-key'], FAKE_API_KEY);
    capturedBody = JSON.parse(options.body);

    return new Response(JSON.stringify({
      id: 'inter-789',
      status: 'completed',
      outputs: [
        {
          type: 'text',
          text: 'سلام، این یک متن پیاده‌سازی‌شده آزمایشی است.'
        }
      ]
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });
  const result = await client.createTranscriptionInteraction({
    fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
    mimeType: 'audio/mp4',
    options: { mode: 'smart', languageCodes: ['fa'] }
  });

  assert.equal(result.text, 'سلام، این یک متن پیاده‌سازی‌شده آزمایشی است.');
  assert.equal(capturedBody.model, 'gemini-3.5-transcribe');
  assert.equal(capturedBody.input[0].type, 'audio');
  assert.equal(capturedBody.generation_config.transcription_config.mode, 'smart');
  assert.deepEqual(capturedBody.generation_config.transcription_config.language_codes, ['fa']);
});

// 4b. Interaction با output_text مستقیم و حالت verbatim هنگام فعال بودن timestamps
test('createTranscriptionInteraction: extracts output_text and forces verbatim for timestamps', async () => {
  let capturedBody = null;

  const mockFetch = createMockFetch((url, options) => {
    capturedBody = JSON.parse(options.body);

    return new Response(JSON.stringify({
      id: 'inter-output-text-test',
      status: 'completed',
      output_text: 'متن استخراج‌شده از فیلد output_text مستند.'
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });
  const result = await client.createTranscriptionInteraction({
    fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
    mimeType: 'audio/mp4',
    options: { mode: 'smart', enableTimestamps: true } // mode was smart, but timestamps forces verbatim
  });

  assert.equal(result.text, 'متن استخراج‌شده از فیلد output_text مستند.');
  assert.equal(capturedBody.generation_config.transcription_config.mode, 'verbatim');
  assert.equal(capturedBody.generation_config.transcription_config.enable_word_time_offsets, true);
});

// 5. Interaction با HTTP 4xx (401/403 Auth error)
test('createTranscriptionInteraction: throws AUTHENTICATION_ERROR on 401/403', async () => {
  const mockFetch = createMockFetch(() => {
    return new Response(JSON.stringify({
      error: { code: 401, message: `API key ${FAKE_API_KEY} not valid.` }
    }), { status: 401 });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  await assert.rejects(
    () => client.createTranscriptionInteraction({
      fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'AUTHENTICATION_ERROR');
      assert.equal(err.statusCode, 401);
      assert.equal(err.canRetry, false);
      // Ensure API key is sanitized from error message
      assert.ok(!err.message.includes(FAKE_API_KEY));
      assert.ok(err.message.includes('[REDACTED]'));
      return true;
    }
  );
});

// 6. Interaction با HTTP 429 (Rate Limit / Quota)
test('createTranscriptionInteraction: throws RATE_LIMIT_EXCEEDED on 429', async () => {
  const mockFetch = createMockFetch(() => {
    return new Response(JSON.stringify({
      error: { code: 429, message: 'Resource has been exhausted (quota limit).' }
    }), { status: 429 });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  await assert.rejects(
    () => client.createTranscriptionInteraction({
      fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'RATE_LIMIT_EXCEEDED');
      assert.equal(err.statusCode, 429);
      assert.equal(err.canRetry, true);
      return true;
    }
  );
});

// 7. Interaction با HTTP 5xx (Google Server Error)
test('createTranscriptionInteraction: throws GOOGLE_SERVER_ERROR on 503', async () => {
  const mockFetch = createMockFetch(() => {
    return new Response('Backend server temporarily unavailable', { status: 503 });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  await assert.rejects(
    () => client.createTranscriptionInteraction({
      fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'GOOGLE_SERVER_ERROR');
      assert.equal(err.statusCode, 503);
      assert.equal(err.canRetry, true);
      return true;
    }
  );
});

// 8. Network failure (fetch throws)
test('createTranscriptionInteraction: throws NETWORK_ERROR on socket drop', async () => {
  const mockFetch = createMockFetch(() => {
    throw new TypeError(`fetch failed when reaching host with key=${FAKE_API_KEY}`);
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  await assert.rejects(
    () => client.createTranscriptionInteraction({
      fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/test123xyz',
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'NETWORK_ERROR');
      assert.equal(err.canRetry, true);
      // Key must not leak even on network error
      assert.ok(!err.message.includes(FAKE_API_KEY));
      return true;
    }
  );
});

// 9. Timeout (AbortError)
test('uploadAudioFile: throws TIMEOUT_ERROR when request exceeds timeoutMs', async () => {
  const slowFetch = createMockFetch(async (url, options) => {
    return new Promise((resolve, reject) => {
      const signal = options.signal;
      if (signal) {
        signal.addEventListener('abort', () => {
          const abortErr = new Error('The operation was aborted');
          abortErr.name = 'AbortError';
          reject(abortErr);
        });
      }
    });
  });

  const client = new GoogleClient({
    apiKey: FAKE_API_KEY,
    timeoutMs: 20, // very small timeout for test
    fetchFn: slowFetch
  });

  await assert.rejects(
    () => client.uploadAudioFile({
      fileBuffer: Buffer.from('audio bytes'),
      mimeType: 'audio/mp4'
    }),
    (err) => {
      assert.ok(err instanceof GoogleClientError);
      assert.equal(err.code, 'TIMEOUT_ERROR');
      assert.equal(err.statusCode, 408);
      assert.equal(err.canRetry, true);
      assert.ok(!err.message.includes(FAKE_API_KEY));
      return true;
    }
  );
});

// 10. Delete Audio File (best effort)
test('deleteAudioFile: sends DELETE and returns true on 200, false on 404', async () => {
  let deletedUrls = [];
  const mockFetch = createMockFetch((url, options) => {
    assert.equal(options.method, 'DELETE');
    deletedUrls.push(url);
    if (url.includes('not_found')) {
      return new Response('', { status: 404 });
    }
    return new Response('{}', { status: 200 });
  });

  const client = new GoogleClient({ apiKey: FAKE_API_KEY, fetchFn: mockFetch });

  const ok = await client.deleteAudioFile('files/test123xyz');
  assert.equal(ok, true);
  assert.ok(deletedUrls[0].endsWith('/v1beta/files/test123xyz'));

  const failed = await client.deleteAudioFile('files/not_found');
  assert.equal(failed, false);
});
