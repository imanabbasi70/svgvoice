import { test } from 'node:test';
import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import { buildApp } from '../src/server.js';
import { TranscriptionServiceError } from '../src/services/transcription.errors.js';

const SECRET_API_KEY = 'AIzaSySecretNeverLeak_1234567890';

/**
 * Builds a standard multipart/form-data payload.
 */
function buildMultipartPayload({ fields = {}, file = null, boundary = '----AvanisTestBoundary987654321' } = {}) {
  const parts = [];

  for (const [key, val] of Object.entries(fields)) {
    parts.push(
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${val}\r\n`)
    );
  }

  if (file) {
    const { fieldname = 'audio', filename = 'sample.m4a', mimetype = 'audio/mp4', content = 'fake audio bytes 12345' } = file;
    const contentBuffer = Buffer.isBuffer(content) ? content : Buffer.from(content);
    parts.push(
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${fieldname}"; filename="${filename}"\r\nContent-Type: ${mimetype}\r\n\r\n`),
      contentBuffer,
      Buffer.from('\r\n')
    );
  }

  parts.push(Buffer.from(`--${boundary}--\r\n`));

  const body = Buffer.concat(parts);
  const headers = {
    'content-type': `multipart/form-data; boundary=${boundary}`,
    'content-length': body.length.toString()
  };

  return { body, headers };
}

// 1. Successful transcription
test('POST /api/v1/transcribe: succeeds with valid audio and returns normalized contract', async () => {
  let receivedParams = null;
  const mockService = {
    async transcribeAudioFile(params) {
      receivedParams = params;
      return {
        fullText: 'سلام، این متن تبدیل‌شده آزمایشی است.',
        detectedLanguage: 'fa',
        confidence: null,
        durationSeconds: 15.5,
        segments: []
      };
    }
  };

  const app = buildApp({ transcriptionService: mockService });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'good audio sample' },
    fields: { languageCode: 'fa', mode: 'smart', durationSeconds: '15.5' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 200);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, true);
  assert.equal(json.data.fullText, 'سلام، این متن تبدیل‌شده آزمایشی است.');
  assert.equal(json.data.detectedLanguage, 'fa');
  assert.equal(json.data.confidence, null);
  assert.equal(json.data.durationSeconds, 15.5);
  assert.deepEqual(json.data.segments, []);

  assert.ok(receivedParams);
  assert.equal(receivedParams.mimeType, 'audio/mp4');
  assert.equal(receivedParams.options.language, 'fa');
  assert.equal(receivedParams.options.mode, 'smart');

  await app.close();
});

// 2. Missing audio field -> 400
test('POST /api/v1/transcribe: returns 400 when audio file part is missing', async () => {
  const app = buildApp({ transcriptionService: {} });

  const { body, headers } = buildMultipartPayload({
    fields: { languageCode: 'fa' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 400);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'BAD_REQUEST');

  await app.close();
});

// 3. Empty audio (0 bytes) -> 400
test('POST /api/v1/transcribe: returns 400 when audio file is empty (0 bytes)', async () => {
  const app = buildApp({ transcriptionService: {} });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: Buffer.alloc(0) }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 400);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'INVALID_AUDIO_FORMAT');

  await app.close();
});

// 4. Unsupported MIME -> 415
test('POST /api/v1/transcribe: returns 415 when MIME type is not supported', async () => {
  const app = buildApp({ transcriptionService: {} });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'application/pdf', content: 'fake pdf content' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 415);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'INVALID_AUDIO_FORMAT');

  await app.close();
});

// 5. Invalid mode -> 400
test('POST /api/v1/transcribe: returns 400 when mode is not smart or verbatim', async () => {
  const app = buildApp({ transcriptionService: {} });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'sound data' },
    fields: { mode: 'invalid_super_mode' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 400);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'BAD_REQUEST');

  await app.close();
});

// 6. Invalid boolean -> 400
test('POST /api/v1/transcribe: returns 400 when boolean field has invalid string', async () => {
  const app = buildApp({ transcriptionService: {} });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'sound data' },
    fields: { enableTimestamps: 'not_a_bool' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 400);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'BAD_REQUEST');

  await app.close();
});

// 7. Invalid durationSeconds -> 400
test('POST /api/v1/transcribe: returns 400 when durationSeconds is negative or NaN', async () => {
  const app = buildApp({ transcriptionService: {} });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'sound data' },
    fields: { durationSeconds: '-10' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 400);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'BAD_REQUEST');

  await app.close();
});

// 8. Upload too large -> 413
test('POST /api/v1/transcribe: returns 413 when file size exceeds server limit', async () => {
  const smallLimitApp = buildApp({
    transcriptionService: {
      async transcribeAudioFile() {
        throw new Error('Service should not be called when payload exceeds size limit');
      }
    },
    limits: { fileSize: 50 } // tiny limit for test
  });

  const hugePayload = Buffer.alloc(500, 'a');
  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: hugePayload }
  });

  const response = await smallLimitApp.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 413);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'FILE_TOO_LARGE');

  await smallLimitApp.close();
});

// 9. TranscriptionService network error -> 503
test('POST /api/v1/transcribe: returns 503 on service NETWORK_ERROR', async () => {
  const mockService = {
    async transcribeAudioFile() {
      throw new TranscriptionServiceError('NETWORK_ERROR', 'Network connection dropped', 503, true);
    }
  };

  const app = buildApp({ transcriptionService: mockService });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio content' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 503);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'NETWORK_ERROR');
  assert.equal(json.error.canRetry, true);

  await app.close();
});

// 10. Google rate limit -> 429
test('POST /api/v1/transcribe: returns 429 on RATE_LIMIT_EXCEEDED', async () => {
  const mockService = {
    async transcribeAudioFile() {
      throw new TranscriptionServiceError('RATE_LIMIT_EXCEEDED', 'Quota exceeded', 429, true);
    }
  };

  const app = buildApp({ transcriptionService: mockService });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio content' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 429);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'RATE_LIMIT_EXCEEDED');
  assert.equal(json.error.canRetry, true);

  await app.close();
});

// 11. Google server error -> 502
test('POST /api/v1/transcribe: returns 502 on GOOGLE_SERVER_ERROR', async () => {
  const mockService = {
    async transcribeAudioFile() {
      throw new TranscriptionServiceError('GOOGLE_SERVER_ERROR', 'Google service error 503', 502, true);
    }
  };

  const app = buildApp({ transcriptionService: mockService });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio content' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 502);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'GOOGLE_SERVER_ERROR');
  assert.equal(json.error.canRetry, true);

  await app.close();
});

// 12. Authentication error -> 500
test('POST /api/v1/transcribe: returns 500 on GOOGLE_AUTHENTICATION_ERROR', async () => {
  const mockService = {
    async transcribeAudioFile() {
      throw new TranscriptionServiceError('GOOGLE_AUTHENTICATION_ERROR', 'Auth failed', 500, false);
    }
  };

  const app = buildApp({ transcriptionService: mockService });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio content' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 500);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'GOOGLE_AUTHENTICATION_ERROR');
  assert.equal(json.error.canRetry, false);

  await app.close();
});

// 13. Non-multipart request -> 400
test('POST /api/v1/transcribe: returns 400 when Content-Type is not multipart', async () => {
  const app = buildApp({ transcriptionService: {} });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers: { 'content-type': 'application/json' },
    payload: JSON.stringify({ audio: 'base64' })
  });

  assert.equal(response.statusCode, 400);
  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'BAD_REQUEST');

  await app.close();
});

// 14 & 15. Temporary file cleanup after success and service failure
test('POST /api/v1/transcribe: temporary file is cleaned up after success and after failure', async () => {
  let observedFilePath = null;

  const mockServiceSuccess = {
    async transcribeAudioFile({ filePath }) {
      observedFilePath = filePath;
      // Confirm file exists while service executes
      const stat = await fsp.stat(filePath);
      assert.ok(stat.size > 0);

      return { fullText: 'موفق', detectedLanguage: 'fa' };
    }
  };

  const appSuccess = buildApp({ transcriptionService: mockServiceSuccess });
  const payload1 = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'test content' }
  });

  await appSuccess.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers: payload1.headers,
    payload: payload1.body
  });

  // Verify file has been deleted in finally
  let existsAfterSuccess = true;
  try {
    await fsp.stat(observedFilePath);
  } catch {
    existsAfterSuccess = false;
  }
  assert.equal(existsAfterSuccess, false, 'Temporary file must be deleted after successful request');
  await appSuccess.close();

  // Test cleanup on failure
  let observedFilePathFailure = null;
  const mockServiceFailure = {
    async transcribeAudioFile({ filePath }) {
      observedFilePathFailure = filePath;
      throw new TranscriptionServiceError('TRANSCRIPTION_FAILED', 'Internal crash', 500, false);
    }
  };

  const appFailure = buildApp({ transcriptionService: mockServiceFailure });
  const payload2 = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'test content' }
  });

  await appFailure.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers: payload2.headers,
    payload: payload2.body
  });

  let existsAfterFailure = true;
  try {
    await fsp.stat(observedFilePathFailure);
  } catch {
    existsAfterFailure = false;
  }
  assert.equal(existsAfterFailure, false, 'Temporary file must be deleted after request failure');
  await appFailure.close();
});

// 16. Secret / stack trace leakage check
test('POST /api/v1/transcribe: ensures secret API key and stack traces never leak in error response', async () => {
  const mockService = {
    async transcribeAudioFile() {
      const err = new Error(`Database connection failed with key ${SECRET_API_KEY}`);
      err.stack = `Error: at secretFunction (/app/applet/backend/secret.js:1:1) key=${SECRET_API_KEY}`;
      throw err; // Non-TranscriptionServiceError to trigger 500 fallback
    }
  };

  const app = buildApp({ transcriptionService: mockService });

  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'sample content' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 500);
  assert.ok(!response.payload.includes(SECRET_API_KEY), 'Response must not contain secret key');
  assert.ok(!response.payload.includes('stack'), 'Response must not contain stack trace');
  assert.ok(!response.payload.includes('/app/applet/backend'), 'Response must not contain file paths');

  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'TRANSCRIPTION_FAILED');

  await app.close();
});

// 17. Abort hardening: normal request lifecycle does NOT trigger abort
test('POST /api/v1/transcribe: normal lifecycle does not trigger AbortSignal in service', async () => {
  let observedSignal = null;
  const mockService = {
    async transcribeAudioFile({ signal }) {
      observedSignal = signal;
      assert.equal(signal.aborted, false, 'Signal must not be aborted during normal request execution');
      return { fullText: 'متن نرمال', detectedLanguage: 'fa' };
    }
  };

  const app = buildApp({ transcriptionService: mockService });
  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'test audio bytes' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 200);
  assert.ok(observedSignal);
  assert.equal(observedSignal.aborted, false, 'Signal must remain non-aborted on normal completion');

  await app.close();
});

// 18. durationSeconds: rejects Infinity, -Infinity, and NaN
test('POST /api/v1/transcribe: rejects non-finite durationSeconds (Infinity and NaN)', async () => {
  const app = buildApp({ transcriptionService: {} });

  // Test Infinity
  const payloadInfinity = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio content' },
    fields: { durationSeconds: 'Infinity' }
  });
  const resInfinity = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers: payloadInfinity.headers,
    payload: payloadInfinity.body
  });
  assert.equal(resInfinity.statusCode, 400);
  const jsonInf = JSON.parse(resInfinity.payload);
  assert.equal(jsonInf.error.code, 'BAD_REQUEST');

  // Test NaN string
  const payloadNaN = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio content' },
    fields: { durationSeconds: 'not_a_number' }
  });
  const resNaN = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers: payloadNaN.headers,
    payload: payloadNaN.body
  });
  assert.equal(resNaN.statusCode, 400);
  const jsonNaN = JSON.parse(resNaN.payload);
  assert.equal(jsonNaN.error.code, 'BAD_REQUEST');

  await app.close();
});

// 19. Security regression: raw Google error details and authorization headers never leak
test('POST /api/v1/transcribe: raw Google errors and authorization headers never leak to client', async () => {
  const mockService = {
    async transcribeAudioFile() {
      // Simulate an error containing raw Google error details with key and internal path
      throw new TranscriptionServiceError(
        'GOOGLE_SERVER_ERROR',
        'Google service error occurred',
        502,
        true,
        {
          rawGoogleDetails: 'Internal upstream grpc:443 error at /google/internal/v1beta key=AIzaSySecretNeverLeak_1234567890',
          headers: { 'x-goog-api-key': 'AIzaSySecretNeverLeak_1234567890', 'authorization': 'Bearer secret-token' }
        }
      );
    }
  };

  const app = buildApp({ transcriptionService: mockService });
  const { body, headers } = buildMultipartPayload({
    file: { mimetype: 'audio/mp4', content: 'audio bytes' }
  });

  const response = await app.inject({
    method: 'POST',
    url: '/api/v1/transcribe',
    headers,
    payload: body
  });

  assert.equal(response.statusCode, 502);
  assert.ok(!response.payload.includes('AIzaSySecretNeverLeak'), 'Response must not contain API key');
  assert.ok(!response.payload.includes('secret-token'), 'Response must not contain auth token');
  assert.ok(!response.payload.includes('/google/internal'), 'Response must not contain internal Google paths');
  assert.ok(!response.payload.includes('rawGoogleDetails'), 'Response must not leak raw error details');

  const json = JSON.parse(response.payload);
  assert.equal(json.success, false);
  assert.equal(json.error.code, 'GOOGLE_SERVER_ERROR');
  assert.equal(json.error.canRetry, true);

  await app.close();
});

// 20. Rate limiting test: returns 429 when client exceeds request limit
test('POST /api/v1/transcribe: returns 429 when client exceeds configured rate limit', async () => {
  const mockService = {
    async transcribeAudioFile() {
      return { fullText: 'متن تستی', detectedLanguage: 'fa' };
    }
  };

  const app = buildApp({
    transcriptionService: mockService,
    rateLimit: { max: 2, timeWindow: 60000 }
  });

  const payload1 = buildMultipartPayload({ file: { mimetype: 'audio/mp4', content: 'test 1' } });
  const res1 = await app.inject({ method: 'POST', url: '/api/v1/transcribe', headers: payload1.headers, payload: payload1.body });
  assert.equal(res1.statusCode, 200);

  const payload2 = buildMultipartPayload({ file: { mimetype: 'audio/mp4', content: 'test 2' } });
  const res2 = await app.inject({ method: 'POST', url: '/api/v1/transcribe', headers: payload2.headers, payload: payload2.body });
  assert.equal(res2.statusCode, 200);

  const payload3 = buildMultipartPayload({ file: { mimetype: 'audio/mp4', content: 'test 3' } });
  const res3 = await app.inject({ method: 'POST', url: '/api/v1/transcribe', headers: payload3.headers, payload: payload3.body });
  assert.equal(res3.statusCode, 429);

  const json3 = JSON.parse(res3.payload);
  assert.equal(json3.success, false);
  assert.equal(json3.error.code, 'RATE_LIMIT_EXCEEDED');
  assert.equal(json3.error.canRetry, true);

  await app.close();
});

