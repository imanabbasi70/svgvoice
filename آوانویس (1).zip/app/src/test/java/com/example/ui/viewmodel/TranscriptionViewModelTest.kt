package com.example.ui.viewmodel

import com.example.audio.AudioMetadata
import com.example.audio.stt.TranscriptionConfig
import com.example.audio.stt.TranscriptionError
import com.example.audio.stt.TranscriptionRepository
import com.example.audio.stt.TranscriptionResult
import com.example.audio.stt.TranscriptionStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File

class FakeTranscriptionRepository : TranscriptionRepository {
    var emitStatusList: List<TranscriptionStatus> = emptyList()
    var transcribeCallCount = 0
    var cancelCallCount = 0
    var lastMetadata: AudioMetadata? = null

    override fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig
    ): Flow<TranscriptionStatus> = flow {
        transcribeCallCount++
        lastMetadata = audioMetadata
        for (status in emitStatusList) {
            emit(status)
        }
    }

    override suspend fun cancel() {
        cancelCallCount++
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class TranscriptionViewModelTest {

    private val testDispatcher = StandardTestDispatcher()
    private val fakeRepository = FakeTranscriptionRepository()
    private lateinit var viewModel: TranscriptionViewModel
    private val dummyFile = File("test.m4a")
    private val dummyMetadata = AudioMetadata(file = dummyFile, durationMs = 10000, sizeBytes = 500)

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        viewModel = TranscriptionViewModel(fakeRepository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun startTranscription_updatesStateToSuccess() = runTest {
        val expectedResult = TranscriptionResult(
            fullText = "متن تست شده",
            durationSeconds = 10
        )
        fakeRepository.emitStatusList = listOf(
            TranscriptionStatus.Uploading(0.5f),
            TranscriptionStatus.Transcribing,
            TranscriptionStatus.Success(expectedResult)
        )

        viewModel.startTranscription(dummyMetadata)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.status is TranscriptionStatus.Success)
        assertEquals(expectedResult, state.result)
        assertEquals(1, fakeRepository.transcribeCallCount)
        assertFalse(state.isProcessing)
    }

    @Test
    fun startTranscription_whenErrorIsRetryable_canRetryIsTrue() = runTest {
        val networkError = TranscriptionError.Network("Connection timeout")
        fakeRepository.emitStatusList = listOf(
            TranscriptionStatus.Error(networkError)
        )

        viewModel.startTranscription(dummyMetadata)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.status is TranscriptionStatus.Error)
        assertEquals(networkError, state.error)
        assertTrue(state.canRetry)
        assertFalse(state.isProcessing)
    }

    @Test
    fun startTranscription_whenErrorIsNotRetryable_canRetryIsFalse() = runTest {
        val tooLongError = TranscriptionError.AudioTooLong(60)
        fakeRepository.emitStatusList = listOf(
            TranscriptionStatus.Error(tooLongError)
        )

        viewModel.startTranscription(dummyMetadata)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.status is TranscriptionStatus.Error)
        assertEquals(tooLongError, state.error)
        assertFalse(state.canRetry)
    }

    @Test
    fun retry_whenCanRetryIsTrue_restartsTranscription() = runTest {
        val networkError = TranscriptionError.Network("Failed")
        fakeRepository.emitStatusList = listOf(
            TranscriptionStatus.Error(networkError)
        )

        viewModel.startTranscription(dummyMetadata)
        advanceUntilIdle()
        assertEquals(1, fakeRepository.transcribeCallCount)

        viewModel.retry()
        advanceUntilIdle()
        assertEquals(2, fakeRepository.transcribeCallCount)
    }

    @Test
    fun retry_whenCanRetryIsFalse_doesNotRestart() = runTest {
        val tooLongError = TranscriptionError.AudioTooLong(60)
        fakeRepository.emitStatusList = listOf(
            TranscriptionStatus.Error(tooLongError)
        )

        viewModel.startTranscription(dummyMetadata)
        advanceUntilIdle()
        assertEquals(1, fakeRepository.transcribeCallCount)

        viewModel.retry()
        advanceUntilIdle()
        assertEquals(1, fakeRepository.transcribeCallCount) // Call count did not increase
    }

    @Test
    fun cancelTranscription_setsStateToCancelledAndCallsRepositoryCancel() = runTest {
        viewModel.startTranscription(dummyMetadata)
        viewModel.cancelTranscription()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.status is TranscriptionStatus.Cancelled)
        assertEquals(1, fakeRepository.cancelCallCount)
    }

    @Test
    fun startTranscription_whenCalledTwice_cancelsFirstJob() = runTest {
        val secondMetadata = AudioMetadata(file = File("second.m4a"), durationMs = 20000, sizeBytes = 1000)

        fakeRepository.emitStatusList = listOf(
            TranscriptionStatus.Uploading(0.1f)
        )

        viewModel.startTranscription(dummyMetadata)
        testScheduler.runCurrent() // Runs the first launch

        assertEquals(1, fakeRepository.transcribeCallCount)

        viewModel.startTranscription(secondMetadata)
        advanceUntilIdle()

        assertEquals(2, fakeRepository.transcribeCallCount)
        assertEquals(secondMetadata, viewModel.uiState.value.currentAudioMetadata)
    }
}
