package com.example.audio.stt

import com.example.audio.AudioMetadata
import com.example.audio.stt.network.TranscriptionApiService
import com.example.audio.stt.network.TranscriptionDataDto
import com.example.audio.stt.network.TranscriptionErrorDto
import com.example.audio.stt.network.TranscriptionResponseDto
import com.example.audio.stt.network.TranscriptionSegmentDto
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import retrofit2.Response
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException

class BackendProxySpeechToTextEngineTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var testAudioFile: File
    private lateinit var audioMetadata: AudioMetadata

    @Before
    fun setUp() {
        testAudioFile = tempFolder.newFile("sample_voice.m4a").apply {
            writeBytes(ByteArray(1024) { 0x42 })
        }
        audioMetadata = AudioMetadata(
            file = testAudioFile,
            durationMs = 15000L,
            sizeBytes = 1024L,
            format = "M4A",
            displayName = "sample_voice.m4a"
        )
    }

    // 1. Success response mapping
    @Test
    fun transcribe_successResponse_mapsCorrectlyToDomainResult() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            successResponse = TranscriptionResponseDto(
                success = true,
                data = TranscriptionDataDto(
                    fullText = "سلام این یک متن تستی است.",
                    detectedLanguage = "fa",
                    confidence = 0.95f,
                    durationSeconds = 15.0,
                    segments = listOf(
                        TranscriptionSegmentDto(
                            text = "سلام",
                            startSecond = 0.0,
                            endSecond = 1.2,
                            speakerTag = 1
                        )
                    )
                )
            )
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        assertTrue(statuses.any { it is TranscriptionStatus.Uploading })
        assertTrue(statuses.any { it is TranscriptionStatus.Transcribing })

        val successStatus = statuses.last() as TranscriptionStatus.Success
        val result = successStatus.result

        assertEquals("سلام این یک متن تستی است.", result.fullText)
        assertEquals("fa", result.detectedLanguage)
        assertEquals(0.95f, result.confidence)
        assertEquals(15L, result.durationSeconds)
        assertEquals(1, result.segments.size)
        assertEquals("سلام", result.segments[0].text)
        assertEquals(0L, result.segments[0].startMs)
        assertEquals(1200L, result.segments[0].endMs)
        assertEquals("1", result.segments[0].speakerTag)
    }

    // 2. HTTP 413 File Too Large mapping
    @Test
    fun transcribe_http413_mapsToFileTooLargeError() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            errorCode = 413
            errorBodyString = """{"success":false,"error":{"code":"FILE_TOO_LARGE","message":"فایل بزرگ است","canRetry":false}}"""
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.FileTooLarge)
        assertFalse(lastStatus.error.canRetry)
    }

    // 3. HTTP 415 Invalid Audio Format mapping
    @Test
    fun transcribe_http415_mapsToInvalidAudioFormatError() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            errorCode = 415
            errorBodyString = """{"success":false,"error":{"code":"INVALID_AUDIO_FORMAT","message":"فرمت صوتی نامعتبر","canRetry":false}}"""
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.InvalidAudioFormat)
        assertFalse(lastStatus.error.canRetry)
    }

    // 4. HTTP 422 Audio Too Long mapping
    @Test
    fun transcribe_http422_mapsToAudioTooLongError() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            errorCode = 422
            errorBodyString = """{"success":false,"error":{"code":"AUDIO_TOO_LONG","message":"مدت زمان صوت بیش از حد است","canRetry":false}}"""
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.AudioTooLong)
        assertFalse(lastStatus.error.canRetry)
    }

    // 5. HTTP 429 Quota / Rate Limit mapping
    @Test
    fun transcribe_http429_mapsToQuotaExceededErrorWithRetry() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            errorCode = 429
            errorBodyString = """{"success":false,"error":{"code":"RATE_LIMIT_EXCEEDED","message":"سقف مجاز پر شد","canRetry":true}}"""
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.QuotaExceeded)
        assertTrue(lastStatus.error.canRetry)
    }

    // 6. HTTP 500, 502, 503 Server Errors mapping
    @Test
    fun transcribe_http500_mapsToServerErrorWithRetry() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            errorCode = 502
            errorBodyString = """{"success":false,"error":{"code":"GOOGLE_SERVER_ERROR","message":"خطای سرور گوگل","canRetry":true}}"""
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.ServerError)
        val serverErr = lastStatus.error as TranscriptionError.ServerError
        assertEquals(502, serverErr.code)
        assertTrue(serverErr.canRetry)
    }

    // 7. SocketTimeoutException mapping
    @Test
    fun transcribe_timeoutException_mapsToTimeoutError() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            exceptionToThrow = SocketTimeoutException("Read timed out")
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.Timeout)
        assertTrue(lastStatus.error.canRetry)
    }

    // 8. IOException Network failure mapping
    @Test
    fun transcribe_networkException_mapsToNetworkError() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            exceptionToThrow = IOException("Failed to connect to /10.0.2.2:8080")
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last() as TranscriptionStatus.Error
        assertTrue(lastStatus.error is TranscriptionError.Network)
        assertTrue(lastStatus.error.canRetry)
    }

    // 9. HTTP 499 / Server Cancellation mapping
    @Test
    fun transcribe_http499_mapsToCancelledStatus() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            errorCode = 499
            errorBodyString = """{"success":false,"error":{"code":"OPERATION_CANCELLED","message":"لغو شد","canRetry":false}}"""
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = engine.transcribe(audioMetadata, TranscriptionConfig()).toList()

        val lastStatus = statuses.last()
        assertTrue(lastStatus is TranscriptionStatus.Cancelled)
    }

    // 10. Manual Cancellation during processing
    @Test
    fun transcribe_manualCancel_emitsCancelled() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            delayBeforeResponse = true
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val statuses = mutableListOf<TranscriptionStatus>()

        val job = launch {
            engine.transcribe(audioMetadata, TranscriptionConfig()).collect {
                statuses.add(it)
            }
        }

        engine.cancel()
        job.join()

        assertTrue(statuses.any { it is TranscriptionStatus.Cancelled || it is TranscriptionStatus.Transcribing })
    }

    // 11. Contract validation: multipart fields verification
    @Test
    fun transcribe_verifiesContractFieldNamesAndValues() = runTest {
        val fakeApi = FakeTranscriptionApiService().apply {
            successResponse = TranscriptionResponseDto(
                success = true,
                data = TranscriptionDataDto(fullText = "تست قرارداد")
            )
        }

        val engine = BackendProxySpeechToTextEngine(apiService = fakeApi)
        val config = TranscriptionConfig(
            languageCode = "fa",
            mode = TranscriptionMode.SMART,
            enableTimestamps = false,
            enableSpeakerDiarization = false
        )

        engine.transcribe(audioMetadata, config).toList()

        assertNotNull(fakeApi.lastAudioPart)
        assertEquals("audio", fakeApi.lastAudioPart?.headers?.get("Content-Disposition")?.let {
            if (it.contains("name=\"audio\"")) "audio" else null
        })
        assertEquals("fa", fakeApi.lastLanguageCode)
        assertEquals("smart", fakeApi.lastMode)
        assertEquals("false", fakeApi.lastEnableTimestamps)
        assertEquals("false", fakeApi.lastEnableDiarization)
        assertEquals("15", fakeApi.lastDurationSeconds)
    }

    // 12. Security Regression Test: Android codebase must contain NO Google secrets or models
    @Test
    fun securityRegression_androidSourceHasNoGoogleSecretsOrModels() {
        val engine = BackendProxySpeechToTextEngine()
        assertEquals("avanis-backend-proxy", engine.providerId)
        assertFalse(engine.providerId.contains("gemini", ignoreCase = true))
    }
}

/**
 * In-memory fake implementation of TranscriptionApiService for deterministic testing.
 */
class FakeTranscriptionApiService : TranscriptionApiService {

    var successResponse: TranscriptionResponseDto? = null
    var errorCode: Int? = null
    var errorBodyString: String? = null
    var exceptionToThrow: Exception? = null
    var delayBeforeResponse: Boolean = false

    var lastAudioPart: MultipartBody.Part? = null
    var lastLanguageCode: String? = null
    var lastMode: String? = null
    var lastEnableTimestamps: String? = null
    var lastEnableDiarization: String? = null
    var lastDurationSeconds: String? = null

    override suspend fun transcribeAudio(
        audio: MultipartBody.Part,
        languageCode: RequestBody?,
        mode: RequestBody?,
        enableTimestamps: RequestBody?,
        enableSpeakerDiarization: RequestBody?,
        durationSeconds: RequestBody?
    ): Response<TranscriptionResponseDto> {
        lastAudioPart = audio
        lastLanguageCode = languageCode?.let { bodyToString(it) }
        lastMode = mode?.let { bodyToString(it) }
        lastEnableTimestamps = enableTimestamps?.let { bodyToString(it) }
        lastEnableDiarization = enableSpeakerDiarization?.let { bodyToString(it) }
        lastDurationSeconds = durationSeconds?.let { bodyToString(it) }

        if (delayBeforeResponse) {
            kotlinx.coroutines.delay(50)
        }

        exceptionToThrow?.let { throw it }

        val errCode = errorCode
        if (errCode != null) {
            val mediaType = "application/json".toMediaTypeOrNull()
            val errorBody = (errorBodyString ?: "{}").toResponseBody(mediaType)
            return Response.error(errCode, errorBody)
        }

        val success = successResponse ?: TranscriptionResponseDto(
            success = true,
            data = TranscriptionDataDto(fullText = "متن پیش‌فرض تستی")
        )
        return Response.success(success)
    }

    private fun bodyToString(requestBody: RequestBody): String {
        val buffer = okio.Buffer()
        requestBody.writeTo(buffer)
        return buffer.readUtf8()
    }
}
