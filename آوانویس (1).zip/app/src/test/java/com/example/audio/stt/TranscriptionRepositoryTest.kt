package com.example.audio.stt

import com.example.audio.AudioMetadata
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class TranscriptionRepositoryTest {

    private val fakeEngine = FakeSpeechToTextEngine()
    private val repository = TranscriptionRepositoryImpl(fakeEngine)

    @Test
    fun transcribe_whenFileDoesNotExist_emitsInvalidAudioFormat_andDoesNotCallEngine() = runTest {
        val nonExistentFile = File("non_existent_${System.currentTimeMillis()}.m4a")
        val metadata = AudioMetadata(
            file = nonExistentFile,
            durationMs = 5000,
            sizeBytes = 1000
        )

        val results = repository.transcribe(metadata).toList()

        assertEquals(1, results.size)
        assertTrue(results[0] is TranscriptionStatus.Error)
        val error = (results[0] as TranscriptionStatus.Error).error
        assertTrue(error is TranscriptionError.InvalidAudioFormat)
        assertEquals(0, fakeEngine.transcribeCallCount)
    }

    @Test
    fun transcribe_whenFileIsEmpty_emitsInvalidAudioFormat_andDoesNotCallEngine() = runTest {
        val emptyFile = File.createTempFile("empty_audio", ".m4a").apply {
            deleteOnExit()
        }
        val metadata = AudioMetadata(
            file = emptyFile,
            durationMs = 5000,
            sizeBytes = 0
        )

        val results = repository.transcribe(metadata).toList()

        emptyFile.delete()
        assertEquals(1, results.size)
        assertTrue(results[0] is TranscriptionStatus.Error)
        val error = (results[0] as TranscriptionStatus.Error).error
        assertTrue(error is TranscriptionError.InvalidAudioFormat)
        assertEquals(0, fakeEngine.transcribeCallCount)
    }

    @Test
    fun transcribe_whenAudioDurationExceedsLimit_emitsAudioTooLong_andDoesNotCallEngine() = runTest {
        val tempFile = File.createTempFile("valid_audio", ".m4a").apply {
            writeBytes(byteArrayOf(1, 2, 3, 4))
            deleteOnExit()
        }
        // Duration 3700 seconds exceeds standard 3600 seconds (1 hour) limit
        val metadata = AudioMetadata(
            file = tempFile,
            durationMs = 3700 * 1000L,
            sizeBytes = 4
        )

        val results = repository.transcribe(metadata).toList()

        tempFile.delete()
        assertEquals(1, results.size)
        assertTrue(results[0] is TranscriptionStatus.Error)
        val error = (results[0] as TranscriptionStatus.Error).error
        assertTrue(error is TranscriptionError.AudioTooLong)
        assertEquals(60, (error as TranscriptionError.AudioTooLong).maxAllowedMinutes)
        assertEquals(0, fakeEngine.transcribeCallCount)
    }

    @Test
    fun transcribe_whenValid_delegatesToEngineAndEmitsSequence() = runTest {
        val tempFile = File.createTempFile("valid_audio", ".m4a").apply {
            writeBytes(byteArrayOf(1, 2, 3, 4))
            deleteOnExit()
        }
        val metadata = AudioMetadata(
            file = tempFile,
            durationMs = 60 * 1000L,
            sizeBytes = 4
        )

        val expectedResult = TranscriptionResult(
            fullText = "متن واقعی آزمایشی",
            durationSeconds = 60
        )

        fakeEngine.emitStatusSequence = listOf(
            TranscriptionStatus.Uploading(0.5f),
            TranscriptionStatus.Transcribing,
            TranscriptionStatus.Success(expectedResult)
        )

        val results = repository.transcribe(metadata).toList()

        tempFile.delete()
        assertEquals(3, results.size)
        assertTrue(results[0] is TranscriptionStatus.Uploading)
        assertTrue(results[1] is TranscriptionStatus.Transcribing)
        assertTrue(results[2] is TranscriptionStatus.Success)
        assertEquals(expectedResult, (results[2] as TranscriptionStatus.Success).result)
        assertEquals(1, fakeEngine.transcribeCallCount)
    }

    @Test
    fun cancel_delegatesToEngineCancel() = runTest {
        repository.cancel()
        assertEquals(1, fakeEngine.cancelCallCount)
    }
}
