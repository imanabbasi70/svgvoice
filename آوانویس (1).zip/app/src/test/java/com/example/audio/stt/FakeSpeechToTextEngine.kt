package com.example.audio.stt

import com.example.audio.AudioMetadata
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class FakeSpeechToTextEngine : SpeechToTextEngine {
    override val providerId: String = "fake-test-engine"

    var emitStatusSequence: List<TranscriptionStatus> = emptyList()
    var transcribeCallCount = 0
    var cancelCallCount = 0
    var lastPassedMetadata: AudioMetadata? = null
    var lastPassedConfig: TranscriptionConfig? = null

    override fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig
    ): Flow<TranscriptionStatus> = flow {
        transcribeCallCount++
        lastPassedMetadata = audioMetadata
        lastPassedConfig = config
        for (status in emitStatusSequence) {
            emit(status)
        }
    }

    override suspend fun cancel() {
        cancelCallCount++
    }
}
