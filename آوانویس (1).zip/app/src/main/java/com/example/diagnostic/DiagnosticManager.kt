package com.example.diagnostic

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Diagnostic data model holding live, unmocked stage transitions and metrics.
 */
data class DiagnosticState(
    val currentStage: String = "IDLE",
    val logs: List<String> = emptyList(),

    // Stage 1 & 2: Recording & File Diagnostics
    val permissionGranted: Boolean? = null,
    val recordingStarted: Boolean? = null,
    val recordingStopped: Boolean? = null,
    val fileExists: Boolean? = null,
    val filePath: String? = null,
    val fileSizeBytes: Long? = null,
    val durationMs: Long? = null,
    val mimeType: String? = null,
    val hasAudioTrack: Boolean? = null,

    // Stage 3 & 4: Network & Backend Diagnostics
    val transcriptionStarted: Boolean = false,
    val requestUrl: String? = null,
    val httpMethod: String? = null,
    val requestStartedTime: String? = null,
    val httpStatus: Int? = null,
    val responseBodyLength: Int? = null,
    val responseBodyPreview: String? = null,

    // Stage 5: Exceptions (never swallowed)
    val exceptionClass: String? = null,
    val exceptionMessage: String? = null,
    val exceptionCause: String? = null,

    // Final result & UI
    val textReceivedLength: Int? = null,
    val textReceivedPreview: String? = null,
    val uiDisplayConfirmed: Boolean = false
)

object DiagnosticManager {
    private const val TAG = "LiveDiagnostic"
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private val _state = MutableStateFlow(DiagnosticState())
    val state: StateFlow<DiagnosticState> = _state.asStateFlow()

    private fun addLog(entry: String) {
        val timestamp = timeFormat.format(Date())
        val logLine = "[$timestamp] $entry"
        Log.i(TAG, logLine)
        println(logLine)
        _state.update { current ->
            current.copy(logs = (current.logs + logLine).takeLast(40))
        }
    }

    fun setStage(stage: String) {
        addLog("STAGE: $stage")
        _state.update { it.copy(currentStage = stage) }
    }

    fun recordPermission(isGranted: Boolean) {
        setStage("RECORD_PERMISSION")
        addLog("PERMISSION: ${if (isGranted) "GRANTED" else "DENIED"}")
        _state.update { it.copy(permissionGranted = isGranted) }
    }

    fun recordRecordingStart(startedSuccessfully: Boolean) {
        setStage("RECORDING_START")
        addLog("RECORDING_START: success=$startedSuccessfully")
        _state.update { it.copy(recordingStarted = startedSuccessfully) }
        if (startedSuccessfully) {
            setStage("RECORDING_ACTIVE")
        }
    }

    fun recordRecordingStop(
        stoppedSuccessfully: Boolean,
        file: java.io.File?,
        durationMs: Long,
        hasAudioTrack: Boolean,
        mimeType: String
    ) {
        setStage("RECORDING_STOP")
        val exists = file != null && file.exists()
        val size = if (exists) file!!.length() else 0L

        addLog("RECORDING_STOP: stopped=$stoppedSuccessfully")
        setStage("FILE_VALIDATION")
        addLog("FILE_VALIDATION: exists=$exists, size=$size, duration=${durationMs}ms, hasAudio=$hasAudioTrack")

        _state.update {
            it.copy(
                recordingStopped = stoppedSuccessfully,
                fileExists = exists,
                filePath = file?.absolutePath,
                fileSizeBytes = size,
                durationMs = durationMs,
                mimeType = mimeType,
                hasAudioTrack = hasAudioTrack
            )
        }
    }

    fun recordTranscriptionStart(filePath: String, sizeBytes: Long) {
        setStage("TRANSCRIPTION_START")
        addLog("TRANSCRIPTION_START: file=$filePath, size=$sizeBytes")
        _state.update {
            it.copy(
                transcriptionStarted = true,
                exceptionClass = null,
                exceptionMessage = null,
                exceptionCause = null
            )
        }
    }

    fun recordNetworkStart(url: String, method: String = "POST") {
        val now = timeFormat.format(Date())
        setStage("NETWORK_START")
        addLog("BACKEND_REQUEST_STARTED: $method $url")
        _state.update {
            it.copy(
                requestUrl = url,
                httpMethod = method,
                requestStartedTime = now,
                httpStatus = null,
                responseBodyLength = null,
                responseBodyPreview = null
            )
        }
    }

    fun recordNetworkResponse(statusCode: Int, bodyLength: Int, preview: String) {
        setStage("NETWORK_RESPONSE")
        addLog("BACKEND_RESPONSE_RECEIVED: status=$statusCode, length=$bodyLength")
        addLog("RESPONSE_BODY_PREVIEW: ${preview.take(150)}")
        _state.update {
            it.copy(
                httpStatus = statusCode,
                responseBodyLength = bodyLength,
                responseBodyPreview = preview
            )
        }
    }

    fun recordNetworkException(e: Throwable, statusCode: Int? = null, body: String? = null) {
        val exClass = e::class.java.name
        val exMsg = e.message ?: "No error message"
        val exCause = e.cause?.toString() ?: "None"

        addLog("REQUEST_EXCEPTION: class=$exClass, msg=$exMsg, status=$statusCode")
        if (body != null) {
            addLog("EXCEPTION_BODY: ${body.take(200)}")
        }

        _state.update {
            it.copy(
                httpStatus = statusCode ?: it.httpStatus,
                responseBodyPreview = body ?: it.responseBodyPreview,
                exceptionClass = exClass,
                exceptionMessage = exMsg,
                exceptionCause = exCause
            )
        }
    }

    fun recordTextReceived(text: String) {
        setStage("TEXT_RECEIVED")
        addLog("TEXT_RECEIVED: length=${text.length}, preview=${text.take(60)}")
        _state.update {
            it.copy(
                textReceivedLength = text.length,
                textReceivedPreview = text.take(100)
            )
        }
    }

    fun recordUiDisplay() {
        setStage("UI_DISPLAY")
        addLog("UI_DISPLAY: Success rendering transcription on screen")
        _state.update { it.copy(uiDisplayConfirmed = true) }
    }

    fun reset() {
        _state.value = DiagnosticState()
        addLog("DIAGNOSTIC_RESET")
    }
}
