package com.example.diagnostic

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DiagnosticFileInfo(
    val permission: String = "NOT_TESTED",
    val recordingStarted: Boolean = false,
    val recordingStopped: Boolean = false,
    val fileExists: Boolean = false,
    val filePath: String = "",
    val fileSizeBytes: Long = 0L,
    val durationMs: Long = 0L,
    val mimeType: String = "",
    val hasAudioTrack: Boolean = false
)

data class DiagnosticNetworkInfo(
    val requestUrl: String = "",
    val httpMethod: String = "POST",
    val requestStarted: Boolean = false,
    val httpStatus: Int = 0,
    val responseBodyLength: Int = 0,
    val responseBodyPreview: String = "",
    val requestExceptionClass: String = "",
    val requestExceptionMessage: String = "",
    val requestExceptionCause: String = "",
    val responseBodyError: String = ""
)

data class DiagnosticState(
    val currentStage: String = "IDLE",
    val recordPermission: String = "NOT_TESTED",
    val recordingStart: String = "NOT_TESTED",
    val recordingActive: String = "NOT_TESTED",
    val recordingStop: String = "NOT_TESTED",
    val fileValidation: String = "NOT_TESTED",
    val transcriptionStart: String = "NOT_TESTED",
    val networkStart: String = "NOT_TESTED",
    val networkResponse: String = "NOT_TESTED",
    val textReceived: String = "NOT_TESTED",
    val uiDisplay: String = "NOT_TESTED",
    val fileInfo: DiagnosticFileInfo = DiagnosticFileInfo(),
    val networkInfo: DiagnosticNetworkInfo = DiagnosticNetworkInfo(),
    val logs: List<String> = emptyList(),
    val customBackendUrl: String = ""
) {
    fun toFormattedReport(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val timeStr = dateFormat.format(Date())
        return """
=== REAL DEVICE DIAGNOSTIC REPORT ($timeStr) ===
STAGE_SUMMARY:
  RECORD_PERMISSION: $recordPermission
  RECORDING_START: $recordingStart
  RECORDING_ACTIVE: $recordingActive
  RECORDING_STOP: $recordingStop
  FILE_VALIDATION: $fileValidation
  TRANSCRIPTION_START: $transcriptionStart
  NETWORK_START: $networkStart
  NETWORK_RESPONSE: $networkResponse (HTTP ${networkInfo.httpStatus})
  TEXT_RECEIVED: $textReceived
  UI_DISPLAY: $uiDisplay

FILE_DETAILS:
  permission: ${fileInfo.permission}
  recordingStarted: ${fileInfo.recordingStarted}
  recordingStopped: ${fileInfo.recordingStopped}
  fileExists: ${fileInfo.fileExists}
  filePath: ${fileInfo.filePath}
  fileSizeBytes: ${fileInfo.fileSizeBytes}
  durationMs: ${fileInfo.durationMs}
  mimeType: ${fileInfo.mimeType}
  hasAudioTrack: ${fileInfo.hasAudioTrack}

NETWORK_DETAILS:
  REQUEST_URL: ${networkInfo.requestUrl}
  HTTP_METHOD: ${networkInfo.httpMethod}
  REQUEST_STARTED: ${networkInfo.requestStarted}
  HTTP_STATUS: ${networkInfo.httpStatus}
  RESPONSE_BODY_LENGTH: ${networkInfo.responseBodyLength}
  RESPONSE_BODY_PREVIEW: ${networkInfo.responseBodyPreview}
  EXCEPTION_CLASS: ${networkInfo.requestExceptionClass}
  EXCEPTION_MESSAGE: ${networkInfo.requestExceptionMessage}
  EXCEPTION_CAUSE: ${networkInfo.requestExceptionCause}
  RESPONSE_ERROR_BODY: ${networkInfo.responseBodyError}

RAW_LOG_TRAIL:
${logs.joinToString("\n")}
=============================================
""".trimIndent()
    }
}

object DiagnosticLogger {
    private val _state = MutableStateFlow(DiagnosticState())
    val state: StateFlow<DiagnosticState> = _state.asStateFlow()

    fun reset() {
        _state.value = DiagnosticState(customBackendUrl = _state.value.customBackendUrl)
        log("DIAGNOSTIC_RESET", "Diagnostic pipeline state cleared.")
    }

    fun updateBackendUrl(url: String) {
        _state.update { it.copy(customBackendUrl = url) }
        log("CONFIG_UPDATE", "Backend URL updated to: $url")
    }

    fun log(stage: String, message: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        val logLine = "[$timestamp] [$stage] $message"
        Log.i("AvaNevisDiag", logLine)
        _state.update { current ->
            current.copy(
                logs = (current.logs + logLine).takeLast(100),
                currentStage = stage
            )
        }
    }

    fun logPermission(granted: Boolean) {
        val status = if (granted) "PASS" else "FAIL"
        _state.update {
            it.copy(
                recordPermission = status,
                fileInfo = it.fileInfo.copy(permission = if (granted) "GRANTED" else "DENIED")
            )
        }
        log("RECORD_PERMISSION", if (granted) "Permission GRANTED" else "Permission DENIED")
    }

    fun logRecordingStart(started: Boolean, errorMsg: String? = null) {
        val status = if (started) "PASS" else "FAIL"
        _state.update {
            it.copy(
                recordingStart = status,
                fileInfo = it.fileInfo.copy(recordingStarted = started)
            )
        }
        log("RECORDING_START", if (started) "Recording started successfully." else "Failed to start: $errorMsg")
    }

    fun logRecordingActive(durationSeconds: Long) {
        _state.update { it.copy(recordingActive = "PASS") }
        log("RECORDING_ACTIVE", "Recording active for $durationSeconds sec.")
    }

    fun logRecordingStop(
        stopped: Boolean,
        fileExists: Boolean,
        filePath: String,
        fileSizeBytes: Long,
        durationMs: Long,
        mimeType: String,
        hasAudioTrack: Boolean,
        validationPassed: Boolean,
        validationError: String? = null
    ) {
        val stopStatus = if (stopped) "PASS" else "FAIL"
        val valStatus = if (validationPassed) "PASS" else "FAIL"

        _state.update {
            it.copy(
                recordingStop = stopStatus,
                fileValidation = valStatus,
                fileInfo = DiagnosticFileInfo(
                    permission = it.fileInfo.permission,
                    recordingStarted = it.fileInfo.recordingStarted,
                    recordingStopped = stopped,
                    fileExists = fileExists,
                    filePath = filePath,
                    fileSizeBytes = fileSizeBytes,
                    durationMs = durationMs,
                    mimeType = mimeType,
                    hasAudioTrack = hasAudioTrack
                )
            )
        }

        log("RECORDING_STOP", "Stopped=$stopped")
        log("FILE_VALIDATION", "Exists=$fileExists, Size=$fileSizeBytes B, Duration=$durationMs ms, Mime=$mimeType, Track=$hasAudioTrack -> $valStatus ${validationError ?: ""}")
    }

    fun logTranscriptionStart(filePath: String, sizeBytes: Long) {
        _state.update { it.copy(transcriptionStart = "PASS") }
        log("TRANSCRIPTION_START", "Android pipeline initiating transcription for file=$filePath ($sizeBytes B)")
    }

    fun logNetworkStart(url: String, method: String = "POST") {
        _state.update {
            it.copy(
                networkStart = "PASS",
                networkInfo = it.networkInfo.copy(
                    requestUrl = url,
                    httpMethod = method,
                    requestStarted = true
                )
            )
        }
        log("NETWORK_START", "Sending HTTP $method request to $url")
    }

    fun logNetworkSuccess(httpStatus: Int, bodyLength: Int, bodyPreview: String) {
        _state.update {
            it.copy(
                networkResponse = "PASS",
                networkInfo = it.networkInfo.copy(
                    httpStatus = httpStatus,
                    responseBodyLength = bodyLength,
                    responseBodyPreview = bodyPreview.take(300)
                )
            )
        }
        log("NETWORK_RESPONSE", "HTTP $httpStatus Success. Body Length: $bodyLength. Preview: ${bodyPreview.take(100)}")
    }

    fun logNetworkError(
        httpStatus: Int,
        exception: Throwable?,
        errorBody: String?
    ) {
        val excClass = exception?.javaClass?.name ?: "None"
        val excMsg = exception?.message ?: "None"
        val excCause = exception?.cause?.toString() ?: "None"
        val bodyErr = errorBody?.take(500) ?: "None"

        _state.update {
            it.copy(
                networkResponse = "FAIL",
                networkInfo = it.networkInfo.copy(
                    httpStatus = httpStatus,
                    requestExceptionClass = excClass,
                    requestExceptionMessage = excMsg,
                    requestExceptionCause = excCause,
                    responseBodyError = bodyErr
                )
            )
        }
        log("NETWORK_RESPONSE", "FAIL Status=$httpStatus Exc=$excClass Msg=$excMsg Body=$bodyErr")
    }

    fun logTextReceived(textLength: Int, textPreview: String) {
        _state.update { it.copy(textReceived = "PASS") }
        log("TEXT_RECEIVED", "Extracted text length=$textLength. Preview: ${textPreview.take(80)}")
    }

    fun logUiDisplay(textLength: Int) {
        _state.update { it.copy(uiDisplay = "PASS") }
        log("UI_DISPLAY", "UI state updated with text ($textLength chars) on screen.")
    }
}
