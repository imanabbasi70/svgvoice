package com.example.audio

import android.content.Context
import com.example.R
import java.io.File
import java.io.FileOutputStream

object SampleAudioHelper {

    fun getSampleAudio(context: Context, sampleIndex: Int = 1): AudioMetadata {
        val rawResId = if (sampleIndex == 2) R.raw.sample_meeting else R.raw.sample_persian
        val fileName = if (sampleIndex == 2) "sample_meeting.mp3" else "sample_persian.mp3"
        val displayName = if (sampleIndex == 2) "جلسه هماهنگی تیم" else "پیام صوتی آزمایشی"
        val duration = if (sampleIndex == 2) 7600L else 4800L

        val targetFile = File(context.cacheDir, fileName)
        if (!targetFile.exists() || targetFile.length() == 0L) {
            context.resources.openRawResource(rawResId).use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
        }

        return AudioMetadata(
            file = targetFile,
            durationMs = duration,
            sizeBytes = targetFile.length(),
            format = "MP3",
            displayName = displayName
        )
    }
}
