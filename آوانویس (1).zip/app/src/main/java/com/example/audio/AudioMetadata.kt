package com.example.audio

import java.io.File
import java.util.Locale

data class AudioMetadata(
    val file: File,
    val durationMs: Long,
    val sizeBytes: Long,
    val format: String = "M4A",
    val displayName: String? = null
) {
    val durationFormatted: String
        get() {
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }

    val sizeFormatted: String
        get() {
            return when {
                sizeBytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f مگابایت", sizeBytes.toFloat() / (1024 * 1024))
                sizeBytes >= 1024 -> String.format(Locale.US, "%.0f کیلوبایت", sizeBytes.toFloat() / 1024)
                else -> "$sizeBytes بایت"
            }
        }
}
