package com.example.audio.stt

import com.example.audio.AudioMetadata
import kotlinx.coroutines.flow.Flow

/**
 * Universal interface for speech-to-text providers.
 *
 * Implementations process an input [AudioMetadata] and emit progressive
 * [TranscriptionStatus] updates, culminating in a [TranscriptionResult] or [TranscriptionError].
 */
interface SpeechToTextEngine {

    /**
     * Unique identifier of the underlying provider/model (e.g. "avanis-backend-proxy").
     */
    val providerId: String
        get() = "avanis-backend-proxy"

    /**
     * Initiates the transcription pipeline for the given audio metadata.
     *
     * @param audioMetadata Verified audio file information from microphone recording or file import.
     * @param config Target transcription configuration (language, mode, timestamps).
     * @return A cold [Flow] emitting lifecycle status updates.
     */
    fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig = TranscriptionConfig()
    ): Flow<TranscriptionStatus>

    /**
     * Actively cancels any pending upload, background job, or network request,
     * releasing resources and cleaning up temporary state.
     */
    suspend fun cancel()
}
