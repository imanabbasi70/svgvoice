package com.example.audio.stt

/**
 * Transcription output mode for the engine.
 */
enum class TranscriptionMode {
    /**
     * Optimizes transcript for readability: removes disfluencies and applies smart punctuation.
     * Cannot be combined with timestamps or speaker diarization.
     */
    SMART,

    /**
     * Exact verbatim transcript including filler words and pauses.
     * Required when timestamps or speaker diarization are enabled.
     */
    VERBATIM
}

/**
 * Configuration options for audio transcription.
 *
 * @param languageCode Target audio language code (default is "fa" for Persian).
 * @param mode Requested output mode (default SMART).
 * @param enableTimestamps Word or segment-level timestamps (default false in MVP).
 * @param enableSpeakerDiarization Identifies individual speakers (default false in MVP).
 */
data class TranscriptionConfig(
    val languageCode: String = "fa",
    val mode: TranscriptionMode = TranscriptionMode.SMART,
    val enableTimestamps: Boolean = false,
    val enableSpeakerDiarization: Boolean = false
) {
    /**
     * If timestamps or diarization are enabled, VERBATIM is required by model specifications.
     */
    val effectiveMode: TranscriptionMode
        get() = if (enableTimestamps || enableSpeakerDiarization) {
            TranscriptionMode.VERBATIM
        } else {
            mode
        }

    /**
     * Documented limits:
     * - Standard request: max 1 hour (3600 seconds)
     * - Request with timestamps or speaker diarization: max 30 minutes (1800 seconds)
     */
    val maxAllowedDurationSeconds: Long
        get() = if (enableTimestamps || enableSpeakerDiarization) {
            1800L // 30 minutes
        } else {
            3600L // 1 hour (60 minutes)
        }

    /**
     * Validates audio duration against model capacity limits.
     * Returns a [TranscriptionError.AudioTooLong] if violated, or null if valid.
     */
    fun validateDuration(durationSeconds: Long): TranscriptionError.AudioTooLong? {
        val maxAllowed = maxAllowedDurationSeconds
        return if (durationSeconds > maxAllowed) {
            val maxMinutes = (maxAllowed / 60).toInt()
            TranscriptionError.AudioTooLong(maxMinutes)
        } else {
            null
        }
    }
}
