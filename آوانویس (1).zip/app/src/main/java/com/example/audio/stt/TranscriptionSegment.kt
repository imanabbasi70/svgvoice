package com.example.audio.stt

/**
 * Represents a timed or diarized audio chunk.
 *
 * @param startMs Beginning timestamp of the segment in milliseconds.
 * @param endMs Ending timestamp of the segment in milliseconds.
 * @param text The transcribed text for this segment.
 * @param speakerTag Optional speaker identifier (e.g. "Speaker 1") when diarization is active.
 */
data class TranscriptionSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val speakerTag: String? = null
)
