package com.example.audio.stt

/**
 * Strongly-typed errors for the Speech-to-Text pipeline.
 *
 * @param userMessagePersian A clear, user-facing Persian description.
 * @param canRetry Indicates whether the user can retry the operation.
 */
sealed class TranscriptionError(
    val userMessagePersian: String,
    val canRetry: Boolean
) {
    data class Network(val details: String) : TranscriptionError(
        userMessagePersian = "خطا در برقراری ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید.",
        canRetry = true
    )

    object Timeout : TranscriptionError(
        userMessagePersian = "زمان پردازش صوت توسط سرور به پایان رسید (Timeout).",
        canRetry = true
    )

    data class AudioTooLong(val maxAllowedMinutes: Int) : TranscriptionError(
        userMessagePersian = "طول فایل صوتی بیش از حد مجاز ($maxAllowedMinutes دقیقه) است.",
        canRetry = false
    )

    data class FileTooLarge(val maxAllowedMb: Long) : TranscriptionError(
        userMessagePersian = "حجم فایل صوتی بیش از حد مجاز ($maxAllowedMb مگابایت) است.",
        canRetry = false
    )

    object InvalidAudioFormat : TranscriptionError(
        userMessagePersian = "فرمت فایل صوتی انتخاب‌شده توسط موتور تبدیل قابل شناسایی یا خواندن نیست.",
        canRetry = false
    )

    data class QuotaExceeded(val retryAllowed: Boolean = true) : TranscriptionError(
        userMessagePersian = "سهمیه پردازش تبدیل صوت به متن یا سقف تعداد درخواست‌ها پر شده است.",
        canRetry = retryAllowed
    )

    data class ServerError(val code: Int, val details: String) : TranscriptionError(
        userMessagePersian = "خطای موقت در سرور پردازشگر ($code). لطفاً دقایقی دیگر تلاش کنید.",
        canRetry = true
    )

    data class Unknown(val details: String) : TranscriptionError(
        userMessagePersian = "خطای غیرمنتظره در فرآیند تبدیل صوت رخ داد.",
        canRetry = true
    )
}
