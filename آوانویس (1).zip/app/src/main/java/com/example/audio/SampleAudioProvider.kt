package com.example.audio

import android.content.Context
import java.io.File
import java.io.FileOutputStream

data class SampleAudioItem(
    val id: String,
    val title: String,
    val description: String,
    val assetFileName: String,
    val durationFormatted: String,
    val durationMs: Long
)

object SampleAudioProvider {
    val samples = listOf(
        SampleAudioItem(
            id = "sample_meeting",
            title = "جلسه کاری و صورتجلسه فنی",
            description = "صوت فارسی واضح: هماهنگی جلسه هفتگی تیم و گزارش پیشرفت پروژه‌ها",
            assetFileName = "samples/sample_meeting.wav",
            durationFormatted = "00:09",
            durationMs = 9500L
        ),
        SampleAudioItem(
            id = "sample_daily",
            title = "یادداشت روزانه و برنامه‌ریزی",
            description = "صوت فارسی واضح: لیست کارهای هفتگی، تماس‌ها و انتشار نسخه جدید",
            assetFileName = "samples/sample_daily.wav",
            durationFormatted = "00:09",
            durationMs = 9600L
        )
    )

    fun loadSample(context: Context, item: SampleAudioItem): AudioMetadata? {
        return try {
            val cacheFile = File(context.cacheDir, "${item.id}.wav")
            context.assets.open(item.assetFileName).use { input ->
                FileOutputStream(cacheFile).use { output ->
                    input.copyTo(output)
                }
            }
            AudioMetadata(
                file = cacheFile,
                durationMs = item.durationMs,
                sizeBytes = cacheFile.length(),
                format = "WAV",
                displayName = item.title
            )
        } catch (e: Exception) {
            null
        }
    }
}
