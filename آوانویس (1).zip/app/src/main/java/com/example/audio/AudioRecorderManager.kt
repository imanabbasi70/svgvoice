package com.example.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException

import com.example.diagnostic.DiagnosticLogger

class AudioRecorderManager(private val context: Context) {
    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var recordingStartTime: Long = 0L

    var isRecording: Boolean = false
        private set
    var isPaused: Boolean = false
        private set

    private var recorderStartedSuccessfully: Boolean = false

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun createMediaRecorder(): MediaRecorder {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
    }

    fun start(outputFile: File): Result<Unit> {
        // 1. Validate Microphone Permission
        val permGranted = hasAudioPermission()
        DiagnosticLogger.logPermission(permGranted)
        if (!permGranted) {
            Log.e("AudioRecorderManager", "[REAL RECORDING RESULT] permission = DENIED")
            DiagnosticLogger.logRecordingStart(false, "Microphone permission DENIED")
            return Result.failure(SecurityException("دسترسی میکروفون فعال نیست."))
        }

        return try {
            cancel() // Clean up any lingering instance or partial file

            // Ensure parent folder exists
            outputFile.parentFile?.let { parent ->
                if (!parent.exists()) parent.mkdirs()
            }

            val recorder = createMediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)

                try {
                    setAudioChannels(1) // Mono for voice clarity
                    setAudioSamplingRate(44100)
                    setAudioEncodingBitRate(128000)
                } catch (configException: Exception) {
                    Log.w("AudioRecorderManager", "Device rejected custom sample/bit rate, falling back to defaults", configException)
                }

                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            mediaRecorder = recorder
            currentOutputFile = outputFile
            recordingStartTime = System.currentTimeMillis()
            isRecording = true
            isPaused = false
            recorderStartedSuccessfully = true

            DiagnosticLogger.logRecordingStart(true)
            Log.i("AudioRecorderManager", "[PIPELINE] RECORDING_STARTED")
            Result.success(Unit)
        } catch (e: Exception) {
            recorderStartedSuccessfully = false
            Log.e("AudioRecorderManager", "Failed to start MediaRecorder: ${e.message}", e)
            DiagnosticLogger.logRecordingStart(false, e.message)
            cleanUpOnError()
            Result.failure(e)
        }
    }

    fun pause(): Result<Unit> {
        if (!isRecording || isPaused) return Result.success(Unit)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mediaRecorder?.pause()
                isPaused = true
                Result.success(Unit)
            } else {
                Result.failure(UnsupportedOperationException("مکث در این نسخه اندروید پشتیبانی نمی‌شود."))
            }
        } catch (e: Exception) {
            Log.e("AudioRecorderManager", "Failed to pause MediaRecorder", e)
            Result.failure(e)
        }
    }

    fun resume(): Result<Unit> {
        if (!isRecording || !isPaused) return Result.success(Unit)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                mediaRecorder?.resume()
                isPaused = false
                Result.success(Unit)
            } else {
                Result.failure(UnsupportedOperationException("ادامه ضبط در این نسخه اندروید پشتیبانی نمی‌شود."))
            }
        } catch (e: Exception) {
            Log.e("AudioRecorderManager", "Failed to resume MediaRecorder", e)
            Result.failure(e)
        }
    }

    fun stop(): Result<AudioMetadata> {
        if (!isRecording) {
            return Result.failure(IllegalStateException("هیچ عملیات ضبط صدایی در حال اجرا نیست."))
        }

        val file = currentOutputFile
        val elapsed = System.currentTimeMillis() - recordingStartTime
        var recorderStoppedCleanly = false

        try {
            mediaRecorder?.apply {
                try {
                    stop()
                    recorderStoppedCleanly = true
                } catch (stopEx: Exception) {
                    Log.w("AudioRecorderManager", "MediaRecorder.stop() exception: ${stopEx.message}", stopEx)
                }
                reset()
                release()
            }
        } catch (e: Exception) {
            Log.e("AudioRecorderManager", "Error while resetting/releasing MediaRecorder", e)
        } finally {
            mediaRecorder = null
            isRecording = false
            isPaused = false
        }

        Log.i("AudioRecorderManager", "[PIPELINE] STOP_COMPLETED")

        // File Quality & Audio Track Verification
        val fileExists = file != null && file.exists()
        val fileSizeBytes = if (fileExists) file!!.length() else 0L

        var mimeType = "audio/mp4"
        var durationMs = elapsed
        var hasAudioTrack = false

        if (fileExists && fileSizeBytes > 0L) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file!!.absolutePath)
                val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationStr?.toLongOrNull()?.let { durationMs = it }

                val detectedMime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
                if (!detectedMime.isNullOrBlank()) {
                    mimeType = detectedMime
                }

                val hasAudioMeta = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
                hasAudioTrack = hasAudioMeta == "yes" || hasAudioMeta == "true" || durationMs > 0
            } catch (e: Exception) {
                Log.w("AudioRecorderManager", "Metadata extraction warning: ${e.message}")
                hasAudioTrack = fileSizeBytes >= 10240L
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
        }

        // Print Mandatory REAL RECORDING RESULT Diagnostic
        val perm = if (hasAudioPermission()) "GRANTED" else "DENIED"
        val realRecordingResult = """
[REAL RECORDING RESULT]
permission = $perm
recordingStarted = $recorderStartedSuccessfully
recordingStopped = $recorderStoppedCleanly
filePath = ${file?.absolutePath ?: "null"}
fileExists = $fileExists
fileSizeBytes = $fileSizeBytes
durationMs = $durationMs
mimeType = $mimeType
hasAudioTrack = $hasAudioTrack
""".trimIndent()
        Log.i("AudioRecorderManager", realRecordingResult)
        println(realRecordingResult)

        val validationPassed = fileExists && fileSizeBytes >= 10240L && durationMs >= 1000L && hasAudioTrack
        val valErr = when {
            !fileExists -> "File does not exist"
            fileSizeBytes < 10240L -> "File size too small ($fileSizeBytes bytes < 10KB)"
            durationMs < 1000L -> "Duration too short ($durationMs ms < 1s)"
            !hasAudioTrack -> "No valid audio track detected"
            else -> null
        }

        DiagnosticLogger.logRecordingStop(
            stopped = recorderStoppedCleanly,
            fileExists = fileExists,
            filePath = file?.absolutePath ?: "",
            fileSizeBytes = fileSizeBytes,
            durationMs = durationMs,
            mimeType = mimeType,
            hasAudioTrack = hasAudioTrack,
            validationPassed = validationPassed,
            validationError = valErr
        )

        // Strict validation: Require file to be valid with speech audio
        if (!validationPassed) {
            file?.delete()
            currentOutputFile = null
            return Result.failure(IOException(valErr ?: "فایل صوتی معتبر ایجاد نشد. دوباره ضبط کنید."))
        }

        Log.i("AudioRecorderManager", "[PIPELINE] FILE_READY size=$fileSizeBytes")

        val metadata = AudioMetadata(
            file = file!!,
            durationMs = durationMs,
            sizeBytes = fileSizeBytes,
            format = "M4A"
        )
        currentOutputFile = null
        return Result.success(metadata)
    }

    fun cancel() {
        try {
            mediaRecorder?.apply {
                try { stop() } catch (_: Exception) {}
                reset()
                release()
            }
        } catch (e: Exception) {
            Log.w("AudioRecorderManager", "Error while cancelling recorder", e)
        } finally {
            mediaRecorder = null
            isRecording = false
            isPaused = false
            currentOutputFile?.delete()
            currentOutputFile = null
            recorderStartedSuccessfully = false
        }
    }

    fun getMaxAmplitude(): Int {
        return try {
            if (isRecording && !isPaused) {
                mediaRecorder?.maxAmplitude ?: 0
            } else {
                0
            }
        } catch (e: Exception) {
            0
        }
    }

    private fun cleanUpOnError() {
        try {
            mediaRecorder?.reset()
            mediaRecorder?.release()
        } catch (_: Exception) {}
        mediaRecorder = null
        isRecording = false
        isPaused = false
        currentOutputFile?.delete()
        currentOutputFile = null
        recorderStartedSuccessfully = false
    }
}
