package com.example.audio.stt

import android.content.Context
import com.example.BuildConfig

object ServerConfig {
    private const val PREFS_NAME = "avanis_server_config"
    private const val KEY_BACKEND_URL = "custom_backend_url"

    // Reliable public HTTPS TryCloudflare Tunnel connecting to backend
    const val DEFAULT_FALLBACK_URL = "https://educated-africa-alter-extensive.trycloudflare.com/"

    @Volatile
    private var cachedUrl: String? = null

    fun getBaseUrl(context: Context? = null): String {
        cachedUrl?.let { return it }
        if (context != null) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val saved = prefs.getString(KEY_BACKEND_URL, null)
            if (!saved.isNullOrBlank()) {
                val normalized = normalize(saved)
                cachedUrl = normalized
                return normalized
            }
        }
        val buildUrl = try { BuildConfig.BACKEND_BASE_URL } catch (_: Exception) { "" }
        val defaultUrl = if (buildUrl.isNotBlank()) normalize(buildUrl) else DEFAULT_FALLBACK_URL
        cachedUrl = defaultUrl
        return defaultUrl
    }

    fun setBaseUrl(context: Context, url: String) {
        val normalized = normalize(url)
        cachedUrl = normalized
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_BACKEND_URL, normalized)
            .apply()
    }

    fun resetToDefault(context: Context) {
        cachedUrl = null
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_BACKEND_URL)
            .apply()
    }

    fun normalize(url: String): String {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return DEFAULT_FALLBACK_URL
        return if (trimmed.endsWith("/")) trimmed else "$trimmed/"
    }
}
