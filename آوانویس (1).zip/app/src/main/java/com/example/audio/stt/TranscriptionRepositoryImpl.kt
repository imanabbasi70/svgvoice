package com.example.audio.stt

import com.example.audio.AudioMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

import com.example.diagnostic.DiagnosticLogger

class TranscriptionRepositoryImpl(
    private val engine: SpeechToTextEngine = BackendProxySpeechToTextEngine()
) : TranscriptionRepository {

    override fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig
    ): Flow<TranscriptionStatus> = flow {
        // 1. Pre-flight domain validation: File existence and non-zero length
        val file = audioMetadata.file
        if (!file.exists() || file.length() <= 0L) {
            emit(TranscriptionStatus.Error(TranscriptionError.InvalidAudioFormat))
            return@flow
        }

        // 2. Pre-flight domain validation: Duration limit check based on model capacity
        val durationSeconds = audioMetadata.durationMs / 1000
        val durationError = config.validateDuration(durationSeconds)
        if (durationError != null) {
            emit(TranscriptionStatus.Error(durationError))
            return@flow
        }

        // Log TRANSCRIPTION_START step
        DiagnosticLogger.logTranscriptionStart(file.absolutePath, file.length())

        // 3. Delegate to engine for provider-specific transcription and error handling
        try {
            engine.transcribe(audioMetadata, config).collect { status ->
                emit(status)
            }
        } catch (e: CancellationException) {
            // Re-throw cancellation to allow proper coroutine lifecycle handling
            throw e
        } catch (e: Exception) {
            DiagnosticLogger.logNetworkError(0, e, null)
            emit(TranscriptionStatus.Error(TranscriptionError.Unknown(e.message ?: "خطای ناشناخته در پردازش صوت.")))
        }
    }

    override suspend fun cancel() {
        engine.cancel()
    }
}
