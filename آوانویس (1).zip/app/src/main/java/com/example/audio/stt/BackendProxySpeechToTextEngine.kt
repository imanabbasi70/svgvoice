package com.example.audio.stt

import android.util.Log
import com.example.BuildConfig
import com.example.audio.AudioMetadata
import com.example.audio.stt.network.TranscriptionApiService
import com.example.audio.stt.network.TranscriptionResponseDto
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import okio.source
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.example.diagnostic.DiagnosticLogger
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * SpeechToTextEngine implementation that communicates exclusively with
 * the Avanis Backend Proxy via HTTP multipart streaming.
 */
class BackendProxySpeechToTextEngine(
    private val apiService: TranscriptionApiService? = null,
    private val baseUrl: String = BuildConfig.BACKEND_BASE_URL,
    private val okHttpClient: OkHttpClient? = null
) : SpeechToTextEngine {

    override val providerId: String = "avanis-backend-proxy"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val activeService: TranscriptionApiService by lazy {
        apiService ?: createRetrofitService()
    }

    private val isCancelled = AtomicBoolean(false)

    private fun createOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("bypass-tunnel-reminder", "true")
                    .addHeader("User-Agent", "AvaNevis/1.0.0")
                    .build()
                chain.proceed(request)
            }
            .build()
    }

    private fun createRetrofitService(): TranscriptionApiService {
        val client = okHttpClient ?: createOkHttpClient()

        val normalizedBaseUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        val retrofit = Retrofit.Builder()
            .baseUrl(normalizedBaseUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        return retrofit.create(TranscriptionApiService::class.java)
    }

    override fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig
    ): Flow<TranscriptionStatus> = flow {
        isCancelled.set(false)

        // 1. Initial State: Uploading
        emit(TranscriptionStatus.Uploading(0.0f))

        val file = audioMetadata.file
        if (!file.exists() || file.length() == 0L) {
            emit(TranscriptionStatus.Error(TranscriptionError.InvalidAudioFormat))
            return@flow
        }

        // 2. Prepare Multipart streaming request body without buffering entire file in memory
        val mimeType = when (audioMetadata.format.uppercase()) {
            "WAV" -> "audio/wav"
            "MP3" -> "audio/mpeg"
            "OGG" -> "audio/ogg"
            "FLAC" -> "audio/flac"
            "AAC" -> "audio/aac"
            "WEBM" -> "audio/webm"
            else -> "audio/mp4"
        }
        val mediaType = mimeType.toMediaTypeOrNull()
        val countingBody = CountingFileRequestBody(file, mediaType) { progress ->
            // Progressive upload tracking
        }

        val audioPart = MultipartBody.Part.createFormData(
            name = "audio",
            filename = file.name,
            body = countingBody
        )

        val plainTextType = "text/plain".toMediaTypeOrNull()
        val languageCodePart = config.languageCode.toRequestBody(plainTextType)
        val modePart = config.effectiveMode.name.lowercase().toRequestBody(plainTextType)
        val enableTimestampsPart = config.enableTimestamps.toString().toRequestBody(plainTextType)
        val enableDiarizationPart = config.enableSpeakerDiarization.toString().toRequestBody(plainTextType)

        // Client Duration Hint (seconds)
        val durationSecondsPart = if (audioMetadata.durationMs > 0) {
            (audioMetadata.durationMs / 1000).toString().toRequestBody(plainTextType)
        } else {
            null
        }

        currentCoroutineContext().ensureActive()
        if (isCancelled.get()) {
            emit(TranscriptionStatus.Cancelled)
            return@flow
        }

        // Determine active target URL (from custom UI setting if present, otherwise default BuildConfig)
        val customUrl = DiagnosticLogger.state.value.customBackendUrl.trim()
        val effectiveBaseUrl = if (customUrl.isNotBlank()) customUrl else baseUrl

        if (effectiveBaseUrl.isBlank() || effectiveBaseUrl.contains("NO_PUBLIC_BACKEND_AVAILABLE")) {
            DiagnosticLogger.logNetworkError(0, null, "NO_PUBLIC_BACKEND_CONFIGURED")
            emit(TranscriptionStatus.Error(TranscriptionError.Network("آدرس سرور عمومی در این نسخه تنظیم نشده است (NO_PUBLIC_BACKEND_AVAILABLE). لطفاً آدرس HTTPS عمومی سرور خود را در کادر عیب‌یابی (Diagnostic) وارد کنید.")))
            return@flow
        }
        val targetService = if (customUrl.isNotBlank()) {
            val normUrl = if (customUrl.endsWith("/")) customUrl else "$customUrl/"
            Retrofit.Builder()
                .baseUrl(normUrl)
                .client(okHttpClient ?: createOkHttpClient())
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(TranscriptionApiService::class.java)
        } else {
            activeService
        }

        // 3. State transition: Transcribing (upload complete / server processing)
        emit(TranscriptionStatus.Transcribing)

        val fullRequestUrl = "${if (effectiveBaseUrl.endsWith("/")) effectiveBaseUrl else "$effectiveBaseUrl/"}api/v1/transcribe"
        DiagnosticLogger.logNetworkStart(fullRequestUrl, "POST")

        val startTime = System.currentTimeMillis()
        val response: Response<TranscriptionResponseDto>
        try {
            response = targetService.transcribeAudio(
                audio = audioPart,
                languageCode = languageCodePart,
                mode = modePart,
                enableTimestamps = enableTimestampsPart,
                enableSpeakerDiarization = enableDiarizationPart,
                durationSeconds = durationSecondsPart
            )
            val duration = System.currentTimeMillis() - startTime
            logD("AvaNevisDiag", "[Request Completed] Status: ${response.code()}, Duration: ${duration}ms")
        } catch (e: CancellationException) {
            logD("AvaNevisDiag", "[Request Cancelled] Job was cancelled by user/scope.")
            emit(TranscriptionStatus.Cancelled)
            throw e
        } catch (e: UnknownHostException) {
            DiagnosticLogger.logNetworkError(0, e, null)
            logE("AvaNevisDiag", "[UnknownHostException] Cannot resolve host: $effectiveBaseUrl", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Network("[UnknownHostException] آدرس سرور یافت نشد: $effectiveBaseUrl")))
            return@flow
        } catch (e: ConnectException) {
            DiagnosticLogger.logNetworkError(0, e, null)
            logE("AvaNevisDiag", "[ConnectException] Direct connection refused on $effectiveBaseUrl", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Network("[ConnectException] عدم امکان برقراری ارتباط با پورت/سرور $effectiveBaseUrl")))
            return@flow
        } catch (e: SocketTimeoutException) {
            DiagnosticLogger.logNetworkError(0, e, null)
            logE("AvaNevisDiag", "[SocketTimeoutException] Server response timed out on $effectiveBaseUrl", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Timeout))
            return@flow
        } catch (e: SSLHandshakeException) {
            DiagnosticLogger.logNetworkError(0, e, null)
            logE("AvaNevisDiag", "[SSLHandshakeException] SSL/TLS certificate error on $effectiveBaseUrl", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Network("[SSLHandshakeException] خطای گواهی امنیتی SSL در ارتباط با سرور")))
            return@flow
        } catch (e: IOException) {
            DiagnosticLogger.logNetworkError(0, e, null)
            logE("AvaNevisDiag", "[IOException] Network transport error: ${e.message}", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Network("[IOException] ${e.javaClass.simpleName}: ${e.message}")))
            return@flow
        } catch (e: Exception) {
            DiagnosticLogger.logNetworkError(0, e, null)
            logE("AvaNevisDiag", "[Exception] Error: ${e.message}", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Unknown("[${e.javaClass.simpleName}] ${e.message}")))
            return@flow
        }

        currentCoroutineContext().ensureActive()
        if (isCancelled.get()) {
            emit(TranscriptionStatus.Cancelled)
            return@flow
        }

        // 4. Handle HTTP Response
        if (response.isSuccessful) {
            val body = response.body()
            val rawJsonPreview = body?.toString() ?: ""
            DiagnosticLogger.logNetworkSuccess(response.code(), rawJsonPreview.length, rawJsonPreview)

            if (body?.success == true && body.data != null) {
                val data = body.data
                val domainResult = TranscriptionResult(
                    fullText = data.fullText,
                    detectedLanguage = data.detectedLanguage ?: config.languageCode,
                    confidence = data.confidence,
                    durationSeconds = data.durationSeconds?.toLong() ?: (audioMetadata.durationMs / 1000),
                    segments = data.segments?.map { seg ->
                        TranscriptionSegment(
                            startMs = ((seg.startSecond ?: 0.0) * 1000).toLong(),
                            endMs = ((seg.endSecond ?: 0.0) * 1000).toLong(),
                            text = seg.text ?: "",
                            speakerTag = seg.speakerTag?.toString()
                        )
                    } ?: emptyList()
                )
                DiagnosticLogger.logTextReceived(domainResult.fullText.length, domainResult.fullText)
                emit(TranscriptionStatus.Success(domainResult))
            } else {
                val errorMsg = body?.error?.message ?: "پاسخ نامعتبر از سرور پردازشگر."
                DiagnosticLogger.logNetworkError(response.code(), null, errorMsg)
                emit(TranscriptionStatus.Error(TranscriptionError.ServerError(response.code(), errorMsg)))
            }
        } else {
            // Map HTTP error code according to standard contract
            val errorBodyString = response.errorBody()?.string() ?: ""
            DiagnosticLogger.logNetworkError(response.code(), null, errorBodyString)

            val parsedError = parseErrorBody(errorBodyString)
            val mappedError = mapHttpError(
                statusCode = response.code(),
                serverMessage = parsedError?.message ?: "HTTP ${response.code()}: $errorBodyString",
                canRetry = parsedError?.canRetry ?: true,
                config = config
            )

            if (response.code() == 499) {
                emit(TranscriptionStatus.Cancelled)
            } else {
                emit(TranscriptionStatus.Error(mappedError))
            }
        }
    }

    override suspend fun cancel() {
        isCancelled.set(true)
    }

    private fun parseErrorBody(json: String?): com.example.audio.stt.network.TranscriptionErrorDto? {
        if (json.isNullOrBlank()) return null
        return try {
            val adapter = moshi.adapter(TranscriptionResponseDto::class.java)
            adapter.fromJson(json)?.error
        } catch (_: Exception) {
            null
        }
    }

    private fun mapHttpError(
        statusCode: Int,
        serverMessage: String?,
        canRetry: Boolean,
        config: TranscriptionConfig
    ): TranscriptionError {
        return when (statusCode) {
            413 -> TranscriptionError.FileTooLarge(maxAllowedMb = 25)
            415 -> TranscriptionError.InvalidAudioFormat
            422 -> TranscriptionError.AudioTooLong(
                maxAllowedMinutes = (config.maxAllowedDurationSeconds / 60).toInt()
            )
            429 -> TranscriptionError.QuotaExceeded(
                retryAllowed = canRetry
            )
            408, 504 -> TranscriptionError.Timeout
            500, 502, 503 -> TranscriptionError.ServerError(
                code = statusCode,
                details = serverMessage ?: "خطای موقت در سرور رونویسی ($statusCode)."
            )
            else -> TranscriptionError.Unknown(
                details = serverMessage ?: "خطای ناشناخته در پردازش صوت ($statusCode)."
            )
        }
    }

    private fun logD(tag: String, msg: String) {
        try {
            Log.d(tag, msg)
        } catch (_: Throwable) {
            println("[$tag] $msg")
        }
    }

    private fun logE(tag: String, msg: String, tr: Throwable? = null) {
        try {
            if (tr != null) Log.e(tag, msg, tr) else Log.e(tag, msg)
        } catch (_: Throwable) {
            System.err.println("[$tag] ERROR: $msg")
            tr?.printStackTrace()
        }
    }
}

/**
 * Custom RequestBody that streams file bytes directly from disk
 * without loading the complete audio file into memory.
 */
internal class CountingFileRequestBody(
    private val file: File,
    private val contentType: okhttp3.MediaType?,
    private val onProgress: (progressPercent: Float) -> Unit
) : RequestBody() {

    override fun contentType(): okhttp3.MediaType? = contentType

    override fun contentLength(): Long = file.length()

    override fun writeTo(sink: BufferedSink) {
        val totalLength = contentLength()
        var uploadedBytes = 0L

        file.source().use { source ->
            val buffer = okio.Buffer()
            var readCount: Long
            while (source.read(buffer, 8192L).also { readCount = it } != -1L) {
                sink.write(buffer, readCount)
                uploadedBytes += readCount
                if (totalLength > 0) {
                    val progress = (uploadedBytes.toFloat() / totalLength).coerceIn(0.0f, 1.0f)
                    onProgress(progress)
                }
            }
        }
    }
}
