package com.example.audio.stt

import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.audio.AudioMetadata
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * SpeechToTextEngine implementation that calls Google Gemini Generative Language API
 * directly from the client without requiring an intermediary proxy server.
 * Uses officially supported STT and Flash models with fallback support.
 */
class DirectGeminiSpeechToTextEngine(
    private val apiKey: String = "",
    private val okHttpClient: OkHttpClient? = null
) : SpeechToTextEngine {

    override val providerId: String = "google-gemini-direct"

    private val isCancelled = AtomicBoolean(false)

    private val client: OkHttpClient by lazy {
        okHttpClient ?: OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Priority list of Gemini models supporting Persian STT
    private val priorityModels = listOf(
        "gemini-3.5-transcribe",
        "gemini-3.1-flash-lite-preview",
        "gemini-flash-latest",
        "gemini-3.8-flash"
    )

    override fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig
    ): Flow<TranscriptionStatus> = flow {
        isCancelled.set(false)

        val file = audioMetadata.file
        val audioMimeType = when (audioMetadata.format.uppercase()) {
            "WAV" -> "audio/wav"
            "MP3" -> "audio/mpeg"
            "OGG" -> "audio/ogg"
            "FLAC" -> "audio/flac"
            "AAC" -> "audio/aac"
            else -> "audio/mp4"
        }

        // Detailed Upload & File Logging
        val uploadLog = """
[UPLOAD]
absolutePath = ${file.absolutePath}
exists = ${file.exists()}
sizeBytes = ${file.length()}
mimeType = $audioMimeType
""".trimIndent()
        Log.i("DirectGeminiSTT", uploadLog)
        println(uploadLog)

        if (!file.exists() || file.length() < 1024L) {
            emit(TranscriptionStatus.Error(TranscriptionError.InvalidAudioFormat))
            return@flow
        }

        val effectiveApiKey = apiKey
        if (effectiveApiKey.isBlank()) {
            Log.e("DirectGeminiSTT", "Gemini API key is not supplied directly to client.")
            emit(TranscriptionStatus.Error(TranscriptionError.ServerError(401, "کلید اختصاصی Gemini در اپلیکیشن غیرفعال شده است. اتصال باید از طریق Backend امن انجام شود.")))
            return@flow
        }

        // 1. Pipeline: Uploading / Reading File
        logPipeline("UPLOAD_STARTED")
        emit(TranscriptionStatus.Uploading(0.3f))

        val fileBytes = try {
            file.readBytes()
        } catch (e: Exception) {
            Log.e("DirectGeminiSTT", "Failed to read audio file: ${e.message}", e)
            emit(TranscriptionStatus.Error(TranscriptionError.Unknown("خطا در خواندن فایل صوتی از حافظه.")))
            return@flow
        }

        val base64Data = Base64.encodeToString(fileBytes, Base64.NO_WRAP)
        emit(TranscriptionStatus.Uploading(1.0f))
        logPipeline("UPLOAD_COMPLETED")

        currentCoroutineContext().ensureActive()
        if (isCancelled.get()) {
            emit(TranscriptionStatus.Cancelled)
            return@flow
        }

        // 2. Pipeline: Transcribing
        logPipeline("TRANSCRIPTION_STARTED")
        emit(TranscriptionStatus.Transcribing)

        var extractedFullText: String? = null
        var lastErrorMessage: String? = null
        var lastStatusCode: Int = 0

        val promptText = if (config.languageCode == "fa") {
            "این فایل صوتی را به زبان فارسی دقیقاً پیاده‌سازی و رونویسی کن. علائم نگارشی مناسب اضافه کن و فقط متن فارسی نهایی را برگردان. اگر صدا خالی، نامفهوم یا بدون کلام بود، بنویس: «هیچ گفتاری شناسایی نشد.»"
        } else {
            "Transcribe this audio accurately. Include proper punctuation and return only the transcript text."
        }

        for (modelName in priorityModels) {
            if (isCancelled.get()) break
            currentCoroutineContext().ensureActive()

            Log.i("DirectGeminiSTT", "[Gemini Attempt] Trying model: $modelName")

            val jsonPayload = buildRequestBody(audioMimeType, base64Data, promptText)
            val requestUrl = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$effectiveApiKey"

            val request = Request.Builder()
                .url(requestUrl)
                .header("Content-Type", "application/json")
                .post(jsonPayload.toRequestBody("application/json".toMediaType()))
                .build()

            try {
                val response = client.newCall(request).execute()
                lastStatusCode = response.code
                val responseBodyStr = response.body?.string() ?: ""

                Log.i("DirectGeminiSTT", "HTTP_STATUS = $lastStatusCode")
                Log.d("DirectGeminiSTT", "RESPONSE_BODY = ${responseBodyStr.take(300)}")

                if (response.isSuccessful && responseBodyStr.isNotBlank()) {
                    val parsedText = extractTextFromGeminiJson(responseBodyStr)
                    if (!parsedText.isNullOrBlank()) {
                        extractedFullText = parsedText
                        Log.i("DirectGeminiSTT", "[Gemini Success] Model $modelName returned ${parsedText.length} chars.")
                        break
                    }
                } else {
                    lastErrorMessage = "کد پاسخ: $lastStatusCode - ${extractErrorMessage(responseBodyStr)}"
                    Log.w("DirectGeminiSTT", "Model $modelName failed: $lastErrorMessage")
                }
            } catch (e: CancellationException) {
                logPipeline("TRANSCRIPTION_CANCELLED")
                emit(TranscriptionStatus.Cancelled)
                throw e
            } catch (e: SocketTimeoutException) {
                Log.e("DirectGeminiSTT", "Timeout on $modelName: ${e.message}")
                lastErrorMessage = "مهلت پاسخ‌دهی سرور به پایان رسید."
            } catch (e: IOException) {
                Log.e("DirectGeminiSTT", "Network IO error on $modelName: ${e.message}")
                lastErrorMessage = "خطا در برقراری ارتباط اینترنتی."
            } catch (e: Exception) {
                Log.e("DirectGeminiSTT", "Unexpected error on $modelName: ${e.message}")
                lastErrorMessage = e.message ?: "خطای ناشناخته در پردازش صوت."
            }

            // Brief pause before trying fallback model if rate-limited or busy
            if (lastStatusCode == 503 || lastStatusCode == 429) {
                delay(1000L)
            }
        }

        currentCoroutineContext().ensureActive()
        if (isCancelled.get()) {
            emit(TranscriptionStatus.Cancelled)
            return@flow
        }

        if (!extractedFullText.isNullOrBlank()) {
            logPipeline("TRANSCRIPTION_COMPLETED")
            logPipeline("TEXT_RECEIVED length=${extractedFullText.length}")

            val result = TranscriptionResult(
                fullText = extractedFullText,
                detectedLanguage = config.languageCode,
                confidence = 0.95f,
                durationSeconds = audioMetadata.durationMs / 1000,
                segments = emptyList()
            )
            emit(TranscriptionStatus.Success(result))
        } else {
            val finalError = lastErrorMessage ?: "امکان تبدیل صوت به متن فراهم نشد."
            Log.e("DirectGeminiSTT", "All models failed. Final error: $finalError")
            emit(TranscriptionStatus.Error(TranscriptionError.ServerError(lastStatusCode.takeIf { it > 0 } ?: 500, finalError)))
        }
    }

    override suspend fun cancel() {
        isCancelled.set(true)
    }

    private fun buildRequestBody(mimeType: String, base64Audio: String, prompt: String): String {
        return """
{
  "contents": [
    {
      "role": "user",
      "parts": [
        {
          "inlineData": {
            "mimeType": "$mimeType",
            "data": "$base64Audio"
          }
        },
        {
          "text": "$prompt"
        }
      ]
    }
  ]
}
""".trimIndent()
    }

    private fun extractTextFromGeminiJson(json: String): String? {
        return try {
            val mapAdapter = moshi.adapter(Map::class.java)
            val root = mapAdapter.fromJson(json) as? Map<*, *> ?: return null
            val candidates = root["candidates"] as? List<*> ?: return null
            if (candidates.isEmpty()) return null

            val firstCandidate = candidates[0] as? Map<*, *> ?: return null
            val content = firstCandidate["content"] as? Map<*, *> ?: return null
            val parts = content["parts"] as? List<*> ?: return null
            if (parts.isEmpty()) return null

            val firstPart = parts[0] as? Map<*, *> ?: return null

            // 1. Check direct part.text
            val directText = firstPart["text"] as? String
            if (!directText.isNullOrBlank()) return directText.trim()

            // 2. Check part.audioTranscription.text (specialized transcribe model output)
            val audioTranscription = firstPart["audioTranscription"] as? Map<*, *>
            val transcribedText = audioTranscription?.get("text") as? String
            if (!transcribedText.isNullOrBlank()) return transcribedText.trim()

            null
        } catch (e: Exception) {
            Log.e("DirectGeminiSTT", "Error extracting text from Gemini JSON: ${e.message}", e)
            null
        }
    }

    private fun extractErrorMessage(json: String): String {
        return try {
            val mapAdapter = moshi.adapter(Map::class.java)
            val root = mapAdapter.fromJson(json) as? Map<*, *> ?: return json.take(150)
            val error = root["error"] as? Map<*, *>
            (error?.get("message") as? String) ?: json.take(150)
        } catch (_: Exception) {
            json.take(150)
        }
    }

    private fun logPipeline(step: String) {
        val msg = "[PIPELINE] $step"
        Log.i("DirectGeminiSTT", msg)
        println(msg)
    }
}
