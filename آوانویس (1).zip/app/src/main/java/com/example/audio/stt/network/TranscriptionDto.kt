package com.example.audio.stt.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Standard HTTP response envelope returned by the Backend Proxy.
 */
@JsonClass(generateAdapter = true)
data class TranscriptionResponseDto(
    @Json(name = "success") val success: Boolean,
    @Json(name = "data") val data: TranscriptionDataDto? = null,
    @Json(name = "error") val error: TranscriptionErrorDto? = null
)

/**
 * Successful transcription payload matching the Backend contract.
 */
@JsonClass(generateAdapter = true)
data class TranscriptionDataDto(
    @Json(name = "fullText") val fullText: String,
    @Json(name = "detectedLanguage") val detectedLanguage: String? = null,
    @Json(name = "confidence") val confidence: Float? = null,
    @Json(name = "durationSeconds") val durationSeconds: Double? = null,
    @Json(name = "segments") val segments: List<TranscriptionSegmentDto>? = emptyList()
)

/**
 * Audio segment data for future timestamp or diarization support.
 */
@JsonClass(generateAdapter = true)
data class TranscriptionSegmentDto(
    @Json(name = "text") val text: String? = null,
    @Json(name = "startSecond") val startSecond: Double? = null,
    @Json(name = "endSecond") val endSecond: Double? = null,
    @Json(name = "speakerTag") val speakerTag: Int? = null
)

/**
 * Standard error payload returned by the Backend Proxy.
 */
@JsonClass(generateAdapter = true)
data class TranscriptionErrorDto(
    @Json(name = "code") val code: String,
    @Json(name = "message") val message: String,
    @Json(name = "canRetry") val canRetry: Boolean = false
)
