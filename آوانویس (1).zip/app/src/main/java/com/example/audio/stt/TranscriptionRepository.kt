package com.example.audio.stt

import com.example.audio.AudioMetadata
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for audio transcription operations.
 * Abstracts the underlying [SpeechToTextEngine] and provides domain-level validation.
 */
interface TranscriptionRepository {

    /**
     * Pre-validates the audio file and begins the transcription stream.
     *
     * @param audioMetadata The verified audio file metadata.
     * @param config The requested transcription configuration.
     * @return Flow emitting sequential [TranscriptionStatus] updates.
     */
    fun transcribe(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig = TranscriptionConfig()
    ): Flow<TranscriptionStatus>

    /**
     * Actively requests cancellation of any active transcription operation.
     */
    suspend fun cancel()
}
