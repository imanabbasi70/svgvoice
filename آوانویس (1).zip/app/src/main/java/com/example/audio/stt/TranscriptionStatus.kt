package com.example.audio.stt

/**
 * Lifecycle states of an audio transcription request.
 */
sealed class TranscriptionStatus {
    object Idle : TranscriptionStatus()

    /**
     * File is being uploaded to the backend/file service.
     * @param progressPercent Progress fraction between 0.0f and 1.0f, or null if indeterminate.
     */
    data class Uploading(val progressPercent: Float? = null) : TranscriptionStatus()

    /**
     * Audio file has been received and is currently being processed by the transcription model.
     */
    object Transcribing : TranscriptionStatus()

    /**
     * Successfully transcribed with verified domain result.
     */
    data class Success(val result: TranscriptionResult) : TranscriptionStatus()

    /**
     * An error occurred during upload or transcription.
     */
    data class Error(val error: TranscriptionError) : TranscriptionStatus()

    /**
     * Explicitly cancelled by user action.
     */
    object Cancelled : TranscriptionStatus()
}
