package com.example.audio

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class AudioFileImporter(private val context: Context) {

    /**
     * Imports an audio file selected by the user via Storage Access Framework,
     * copies it securely into the app's internal cache directory on Dispatchers.IO,
     * performs initial media validation, and extracts AudioMetadata.
     *
     * @param uri The content:// URI returned by ActivityResultContracts.OpenDocument
     * @param maxSizeBytes Optional configurable upper size limit (defaults to 150 MB for MVP)
     */
    suspend fun importAudioFile(
        uri: Uri,
        maxSizeBytes: Long? = 150 * 1024 * 1024L // 150 MB configurable
    ): Result<AudioMetadata> = withContext(Dispatchers.IO) {
        var tempFile: File? = null

        try {
            val contentResolver = context.contentResolver

            // 1. Query display name and optional reported size
            var displayName = "audio_imported_${System.currentTimeMillis()}"
            var reportedSize: Long? = null

            try {
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            val queriedName = cursor.getString(nameIndex)
                            if (!queriedName.isNullOrBlank()) {
                                displayName = queriedName
                            }
                        }

                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                            reportedSize = cursor.getLong(sizeIndex)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("AudioFileImporter", "Could not query OpenableColumns for URI: $uri", e)
            }

            // 2. Check size limit if reported beforehand
            val initialSize = reportedSize
            if (maxSizeBytes != null && initialSize != null && initialSize > maxSizeBytes) {
                val maxMb = maxSizeBytes / (1024 * 1024)
                return@withContext Result.failure(
                    IOException("حجم فایل انتخابی بیش از سقف مجاز ($maxMb مگابایت) است.")
                )
            }

            // 3. Prepare target destination in internal cache
            val importDir = File(context.cacheDir, "imported_audio").apply {
                if (!exists()) mkdirs()
            }

            // Sanitize extension and file name
            val safeExtension = getExtensionFromFileName(displayName)
                ?: getExtensionFromMime(contentResolver.getType(uri))
                ?: "m4a"

            val targetFileName = "imp_${System.currentTimeMillis()}.$safeExtension"
            tempFile = File(importDir, targetFileName)

            // 4. Stream and copy bytes safely with a 64KB buffer
            var totalBytesCopied = 0L
            val inputStream = contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IOException("امکان باز کردن فایل صوتی انتخابی وجود ندارد."))

            inputStream.use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalBytesCopied += bytesRead

                        if (maxSizeBytes != null && totalBytesCopied > maxSizeBytes) {
                            tempFile?.delete()
                            val maxMb = maxSizeBytes / (1024 * 1024)
                            return@withContext Result.failure(
                                IOException("حجم فایل انتخابی بیش از سقف مجاز ($maxMb مگابایت) است.")
                            )
                        }
                    }
                    output.flush()
                }
            }

            if (totalBytesCopied == 0L || !tempFile.exists() || tempFile.length() == 0L) {
                tempFile.delete()
                return@withContext Result.failure(IOException("فایل صوتی انتخابی خالی یا غیرقابل خواندن است."))
            }

            // 5. Initial validation & metadata extraction via MediaMetadataRetriever
            val durationMs = validateAndExtractDuration(tempFile)
            val detectedFormat = safeExtension.uppercase()

            val metadata = AudioMetadata(
                file = tempFile,
                durationMs = durationMs,
                sizeBytes = tempFile.length(),
                format = detectedFormat,
                displayName = displayName
            )

            Result.success(metadata)
        } catch (e: Exception) {
            Log.e("AudioFileImporter", "Error importing audio file from $uri", e)
            tempFile?.delete()
            val friendlyError = when {
                e is IOException && e.message != null -> e.message!!
                else -> "خطا در وارد کردن و پردازش فایل صوتی. لطفاً مجدداً تلاش کنید."
            }
            Result.failure(Exception(friendlyError, e))
        }
    }

    private fun validateAndExtractDuration(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val parsedDuration = durationStr?.toLongOrNull() ?: 0L
            parsedDuration
        } catch (e: Exception) {
            Log.w("AudioFileImporter", "MediaMetadataRetriever initial check warning for ${file.name}", e)
            0L // Keep file if it has valid bytes; STT engine in Phase 5 will perform full decode
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun getExtensionFromFileName(fileName: String): String? {
        val dotIndex = fileName.lastIndexOf('.')
        if (dotIndex in 1 until fileName.length - 1) {
            val ext = fileName.substring(dotIndex + 1).lowercase()
            if (ext in listOf("mp3", "m4a", "wav", "ogg", "aac", "flac", "wma")) {
                return ext
            }
        }
        return null
    }

    private fun getExtensionFromMime(mimeType: String?): String? {
        return when (mimeType?.lowercase()) {
            "audio/mpeg", "audio/mp3" -> "mp3"
            "audio/mp4", "audio/x-m4a" -> "m4a"
            "audio/wav", "audio/x-wav" -> "wav"
            "audio/ogg", "application/ogg" -> "ogg"
            "audio/aac" -> "aac"
            else -> null
        }
    }
}
