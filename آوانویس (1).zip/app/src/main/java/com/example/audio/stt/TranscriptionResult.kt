package com.example.audio.stt

/**
 * Verified domain result returned by a SpeechToTextEngine.
 *
 * @param fullText The complete transcribed Persian or detected text.
 * @param detectedLanguage The BCP-47 language tag detected by the engine (e.g. "fa").
 * @param confidence Confidence score between 0.0 and 1.0 if natively supported; null if unsupported.
 * @param durationSeconds Audio duration processed in seconds.
 * @param segments Timed or speaker-diarized segments if requested; empty list in standard MVP mode.
 */
data class TranscriptionResult(
    val fullText: String,
    val detectedLanguage: String? = null,
    val confidence: Float? = null,
    val durationSeconds: Long,
    val segments: List<TranscriptionSegment> = emptyList()
)
