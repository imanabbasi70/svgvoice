package com.example.audio.stt.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

/**
 * Retrofit contract for communicating strictly with the Avanis Backend Proxy.
 * Does not communicate with any external speech-to-text API directly.
 */
interface TranscriptionApiService {

    @Multipart
    @POST("api/v1/transcribe")
    suspend fun transcribeAudio(
        @Part audio: MultipartBody.Part,
        @Part("languageCode") languageCode: RequestBody? = null,
        @Part("mode") mode: RequestBody? = null,
        @Part("enableTimestamps") enableTimestamps: RequestBody? = null,
        @Part("enableSpeakerDiarization") enableSpeakerDiarization: RequestBody? = null,
        @Part("durationSeconds") durationSeconds: RequestBody? = null
    ): Response<TranscriptionResponseDto>
}
