package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.navigation.AppScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.RecordScreen
import com.example.ui.screens.ResultScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AvaNevisTheme
import com.example.ui.viewmodel.FileImportViewModel
import com.example.ui.viewmodel.RecorderViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.layout.Arrangement
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Default to Light Theme for pristine White and Purple Goftino experience
            var isDarkTheme by remember { mutableStateOf(false) }
            AvaNevisTheme(darkTheme = isDarkTheme) {
                MainAppHost(
                    isDarkTheme = isDarkTheme,
                    onToggleDarkTheme = { isDarkTheme = it }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppHost(
    isDarkTheme: Boolean,
    onToggleDarkTheme: (Boolean) -> Unit
) {
    val recorderViewModel: RecorderViewModel = viewModel()
    val fileImportViewModel: FileImportViewModel = viewModel()
    val fileImportUiState by fileImportViewModel.uiState.collectAsStateWithLifecycle()
    
    // Start directly on Record screen (the beautiful Mic mockup screen)
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Record) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(fileImportUiState.errorMessage) {
        fileImportUiState.errorMessage?.let { errorMsg ->
            snackbarHostState.showSnackbar(errorMsg)
            fileImportViewModel.clearError()
        }
    }

    if (fileImportUiState.isImporting) {
        Dialog(onDismissRequest = { /* Keep active while processing */ }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Row(
                    modifier = Modifier.padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = fileImportUiState.loadingMessage ?: "در حال پردازش فایل...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }

    val showBottomBar = currentScreen is AppScreen.Home ||
            currentScreen is AppScreen.Record ||
            currentScreen is AppScreen.History ||
            currentScreen is AppScreen.Settings

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("app_root_scaffold"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            // Hide default top bar on Record Screen as it has its own beautiful custom branding header
            if (showBottomBar && currentScreen !is AppScreen.Record) {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "لوگوی آوانویس",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text(
                                    text = "آوانویس",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = when (currentScreen) {
                                        is AppScreen.Home -> "استودیوی هوشمند گفتار به متن"
                                        is AppScreen.History -> "تاریخچه یادداشت‌ها"
                                        is AppScreen.Settings -> "تنظیمات و امنیت"
                                        else -> ""
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Record,
                        onClick = { currentScreen = AppScreen.Record },
                        icon = {
                            Icon(imageVector = Icons.Default.Mic, contentDescription = "اصلی (ضبط)")
                        },
                        label = { Text("اصلی (ضبط)") },
                        modifier = Modifier.testTag("nav_item_record"),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Home,
                        onClick = { currentScreen = AppScreen.Home },
                        icon = {
                            Icon(imageVector = Icons.Default.AudioFile, contentDescription = "فایل صوتی")
                        },
                        label = { Text("فایل صوتی") },
                        modifier = Modifier.testTag("nav_item_home"),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.History,
                        onClick = { currentScreen = AppScreen.History },
                        icon = {
                            Icon(imageVector = Icons.Default.History, contentDescription = "تاریخچه")
                        },
                        label = { Text("تاریخچه") },
                        modifier = Modifier.testTag("nav_item_history"),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Settings,
                        onClick = { currentScreen = AppScreen.Settings },
                        icon = {
                            Icon(imageVector = Icons.Default.Settings, contentDescription = "تنظیمات")
                        },
                        label = { Text("تنظیمات اندروید") },
                        modifier = Modifier.testTag("nav_item_settings"),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is AppScreen.Home -> {
                    HomeScreen(
                        onNavigateToRecord = { currentScreen = AppScreen.Record },
                        onAudioFileSelected = { uri ->
                            fileImportViewModel.importAudioFile(uri) { metadata ->
                                currentScreen = AppScreen.Result(audioMetadata = metadata)
                            }
                        },
                        onNavigateToResult = { id ->
                            currentScreen = AppScreen.Result(id)
                        },
                        onNavigateToHistory = {
                            currentScreen = AppScreen.History
                        }
                    )
                }
                is AppScreen.Record -> {
                    RecordScreen(
                        viewModel = recorderViewModel,
                        onNavigateBack = { currentScreen = AppScreen.Home },
                        onFinishAndTranscribe = { metadata ->
                            currentScreen = AppScreen.Result(audioMetadata = metadata)
                        }
                    )
                }
                is AppScreen.Result -> {
                    ResultScreen(
                        transcriptionId = screen.transcriptionId,
                        audioMetadata = screen.audioMetadata,
                        onNavigateBack = { currentScreen = AppScreen.Home }
                    )
                }
                is AppScreen.History -> {
                    HistoryScreen(
                        onNavigateToResult = { id ->
                            currentScreen = AppScreen.Result(id)
                        }
                    )
                }
                is AppScreen.Settings -> {
                    SettingsScreen(
                        isDarkTheme = isDarkTheme,
                        onToggleDarkTheme = onToggleDarkTheme
                    )
                }
            }
        }
    }
}
