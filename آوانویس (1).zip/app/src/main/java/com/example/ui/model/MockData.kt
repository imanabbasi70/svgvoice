package com.example.ui.model

data class MockTranscription(
    val id: String,
    val title: String,
    val summary: String,
    val fullText: String,
    val durationFormatted: String,
    val dateFormatted: String,
    val wordCount: Int,
    val fileSizeFormatted: String,
    val audioFormat: String = "M4A"
)

object MockDataProvider {
    val sampleList = listOf(
        MockTranscription(
            id = "sample_1",
            title = "جلسه برنامه‌ریزی محصول",
            summary = "بررسی ویژگی‌های کلیدی فاز اول اپلیکیشن آوانویس و هماهنگی با تیم توسعه...",
            fullText = "در این جلسه مقرر گردید که فاز اول اپلیکیشن آوانویس بر روی پایداری ضبط صدا و ارائه خروجی دقیق زبان فارسی متمرکز باشد.\n" +
                    "همچنین تصمیم گرفته شد که فرمت M4A با انکودر AAC به عنوان فرمت استاندارد ضبط در اندروید استفاده شود تا علاوه بر حجم پایین، بالاترین کیفیت برای تبدیل صوت به متن فراهم گردد.\n" +
                    "در فازهای بعدی امکاناتی نظیر خروجی PDF و اشتراک‌گذاری پیشرفته نیز افزوده خواهد شد.",
            durationFormatted = "۰۴:۲۵",
            dateFormatted = "امروز - ۱۰:۳۰",
            wordCount = 64,
            fileSizeFormatted = "۲.۱ مگابایت"
        ),
        MockTranscription(
            id = "sample_2",
            title = "یادداشت صوتی مصاحبه دانشگاهی",
            summary = "پاسخ‌های استاد راهنما در خصوص روش تحقیق و زمان‌بندی تحویل پایان‌نامه...",
            fullText = "نکات مهم مطرح‌شده توسط استاد:\n" +
                    "۱. بازبینی بخش پیشینه پژوهش تا پایان هفته آینده.\n" +
                    "۲. استفاده از منابع به‌روز دو سال اخیر در فصل دوم.\n" +
                    "۳. هماهنگی جلسه بعدی در روز دوشنبه ساعت ۱۰ صبح.",
            durationFormatted = "۰۸:۱۲",
            dateFormatted = "دیروز - ۱۶:۴۵",
            wordCount = 42,
            fileSizeFormatted = "۳.۸ مگابایت"
        ),
        MockTranscription(
            id = "sample_3",
            title = "ایده‌های پادکست تکنولوژی",
            summary = "بررسی ترندهای هوش مصنوعی در سال ۲۰۲۶ و کاربرد آن در ابزارهای روزمره...",
            fullText = "موضوع این قسمت: چطور هوش مصنوعی مولد روند تولید محتوای صوتی و متنی را دگرگون کرده است؟\n" +
                    "بخش اول: معرفی ابزارهای مدرن ضبط صدا و رونویسی بلادرنگ.\n" +
                    "بخش دوم: بررسی چالش‌های امنیتی و حریم خصوصی در پردازش‌های ابری.",
            durationFormatted = "۰۲:۴۵",
            dateFormatted = "۳ روز پیش",
            wordCount = 51,
            fileSizeFormatted = "۱.۳ مگابایت"
        )
    )

    fun getById(id: String): MockTranscription {
        return sampleList.find { it.id == id } ?: sampleList.first()
    }
}
