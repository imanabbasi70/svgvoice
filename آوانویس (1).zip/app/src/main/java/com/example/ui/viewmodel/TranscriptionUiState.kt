package com.example.ui.viewmodel

import com.example.audio.AudioMetadata
import com.example.audio.stt.TranscriptionConfig
import com.example.audio.stt.TranscriptionError
import com.example.audio.stt.TranscriptionResult
import com.example.audio.stt.TranscriptionStatus

/**
 * UI State representing the current progress and outcome of speech-to-text.
 */
data class TranscriptionUiState(
    val status: TranscriptionStatus = TranscriptionStatus.Idle,
    val currentAudioMetadata: AudioMetadata? = null,
    val config: TranscriptionConfig = TranscriptionConfig()
) {
    val isProcessing: Boolean
        get() = status is TranscriptionStatus.Uploading || status is TranscriptionStatus.Transcribing

    val canRetry: Boolean
        get() = (status as? TranscriptionStatus.Error)?.error?.canRetry == true

    val result: TranscriptionResult?
        get() = (status as? TranscriptionStatus.Success)?.result

    val error: TranscriptionError?
        get() = (status as? TranscriptionStatus.Error)?.error
}
