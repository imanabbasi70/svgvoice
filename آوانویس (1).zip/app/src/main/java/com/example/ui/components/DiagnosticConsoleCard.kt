package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.diagnostic.DiagnosticManager
import com.example.diagnostic.DiagnosticState

@Composable
fun DiagnosticConsoleCard(
    modifier: Modifier = Modifier,
    initialExpanded: Boolean = true
) {
    val state by DiagnosticManager.state.collectAsState()
    var isExpanded by remember { mutableStateOf(initialExpanded) }
    val clipboardManager = LocalClipboardManager.current

    val stageColor = when (state.currentStage) {
        "UI_DISPLAY", "TEXT_RECEIVED" -> Color(0xFF10B981) // Green
        "NETWORK_START", "TRANSCRIPTION_START", "RECORDING_ACTIVE" -> Color(0xFF3B82F6) // Blue
        "IDLE" -> Color(0xFF6B7280) // Gray
        else -> if (state.exceptionClass != null || state.httpStatus != null && state.httpStatus!! >= 400) {
            Color(0xFFEF4444) // Red
        } else {
            Color(0xFFF59E0B) // Amber
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, stageColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0F172A) // Dark terminal slate
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Title & Stage Indicator & Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(stageColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = "Diagnostic",
                            tint = stageColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "حالت تشخیص زنده (Diagnostic Mode)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(stageColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = state.currentStage,
                                color = stageColor,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            val allLogs = state.logs.joinToString("\n")
                            val summary = """
=== DIAGNOSTIC REPORT ===
Stage: ${state.currentStage}
Permission: ${state.permissionGranted}
RecordingStarted: ${state.recordingStarted}
RecordingStopped: ${state.recordingStopped}
FileExists: ${state.fileExists}
FilePath: ${state.filePath}
Size: ${state.fileSizeBytes} bytes
Duration: ${state.durationMs} ms
AudioTrack: ${state.hasAudioTrack}
URL: ${state.requestUrl}
HTTP Status: ${state.httpStatus}
Exception: ${state.exceptionClass} : ${state.exceptionMessage}
ResponsePreview: ${state.responseBodyPreview}
TextLength: ${state.textReceivedLength}

=== LOGS ===
$allLogs
""".trimIndent()
                            clipboardManager.setText(AnnotatedString(summary))
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Report",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Expand",
                        tint = Color.Gray,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Step 1 & 2: Recording & File Summary
                    MetricRow(
                        label = "ضبط و فایل:",
                        value = if (state.recordingStarted == true) "Recording: OK" else "Recording: Pending",
                        isSuccess = state.recordingStarted == true
                    )

                    state.fileSizeBytes?.let { size ->
                        MetricRow(
                            label = "حجم فایل:",
                            value = "$size بایت (${size / 1024} KB)",
                            isSuccess = size > 1024
                        )
                    }

                    state.durationMs?.let { dur ->
                        MetricRow(
                            label = "مدت زمان:",
                            value = "${dur} ms (${dur / 1000}s)",
                            isSuccess = dur >= 1000
                        )
                    }

                    state.hasAudioTrack?.let { track ->
                        MetricRow(
                            label = "تراژک صوتی:",
                            value = if (track) "AudioTrack: true" else "AudioTrack: false (بی‌صدا)",
                            isSuccess = track
                        )
                    }

                    // Step 3 & 4: Network & Backend Summary
                    state.requestUrl?.let { url ->
                        MetricRow(
                            label = "آدرس سرور:",
                            value = url.take(45) + if (url.length > 45) "..." else "",
                            isSuccess = true
                        )
                    }

                    state.httpStatus?.let { code ->
                        MetricRow(
                            label = "کد پاسخ HTTP:",
                            value = "HTTP $code",
                            isSuccess = code in 200..299
                        )
                    }

                    // Step 5: Exceptions (Prominent if present)
                    state.exceptionClass?.let { exClass ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF450A0A)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "خطای دقیق: ${exClass.substringAfterLast('.')}",
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = state.exceptionMessage ?: "Unknown",
                                    color = Color(0xFFFEE2E2),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                if (!state.exceptionCause.isNullOrBlank() && state.exceptionCause != "None") {
                                    Text(
                                        text = "علت: ${state.exceptionCause}",
                                        color = Color(0xFFFECACA),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // Response Preview
                    state.responseBodyPreview?.takeIf { it.isNotBlank() }?.let { preview ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "پاسخ سرور: ${preview.take(120)}",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Terminal Logs (Last 8 lines)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "لاگ‌های لحظه‌ای سیستم:",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF020617)
                    ) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(6.dp),
                            reverseLayout = true
                        ) {
                            items(state.logs.reversed()) { logLine ->
                                Text(
                                    text = logLine,
                                    color = if (logLine.contains("EXCEPTION") || logLine.contains("FAILED") || logLine.contains("DENIED")) {
                                        Color(0xFFF87171)
                                    } else if (logLine.contains("STAGE:")) {
                                        Color(0xFF60A5FA)
                                    } else if (logLine.contains("SUCCESS") || logLine.contains("UI_DISPLAY") || logLine.contains("200")) {
                                        Color(0xFF34D399)
                                    } else {
                                        Color(0xFFCBD5E1)
                                    },
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricRow(
    label: String,
    value: String,
    isSuccess: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = Color(0xFF94A3B8),
            fontSize = 11.sp
        )
        Text(
            text = value,
            color = if (isSuccess) Color(0xFF34D399) else Color(0xFFF87171),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    }
}
