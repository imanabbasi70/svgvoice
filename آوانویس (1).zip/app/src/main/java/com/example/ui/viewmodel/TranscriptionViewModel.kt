package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioMetadata
import com.example.audio.stt.TranscriptionConfig
import com.example.audio.stt.TranscriptionRepository
import com.example.audio.stt.TranscriptionRepositoryImpl
import com.example.audio.stt.TranscriptionStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TranscriptionViewModel(
    private val repository: TranscriptionRepository = TranscriptionRepositoryImpl()
) : ViewModel() {

    private val _uiState = MutableStateFlow(TranscriptionUiState())
    val uiState: StateFlow<TranscriptionUiState> = _uiState.asStateFlow()

    private var currentTranscriptionJob: Job? = null

    /**
     * Starts transcribing the provided [audioMetadata].
     * Any previously active transcription job is cleanly cancelled.
     */
    fun startTranscription(
        audioMetadata: AudioMetadata,
        config: TranscriptionConfig = TranscriptionConfig()
    ) {
        // Cancel any active in-flight transcription before launching a new one
        currentTranscriptionJob?.cancel()

        _uiState.update {
            it.copy(
                status = TranscriptionStatus.Idle,
                currentAudioMetadata = audioMetadata,
                config = config
            )
        }

        currentTranscriptionJob = viewModelScope.launch {
            try {
                repository.transcribe(audioMetadata, config).collect { status ->
                    _uiState.update { it.copy(status = status) }
                }
            } catch (e: CancellationException) {
                // Legitimate coroutine cancellation: do not treat as an error
                // The status will be set to Cancelled via cancelTranscription() or new start
            } catch (e: Exception) {
                // Handled in repository, but safety fallback in case of unexpected exception
            }
        }
    }

    /**
     * Actively cancels the currently running transcription.
     */
    fun cancelTranscription() {
        val jobToCancel = currentTranscriptionJob
        currentTranscriptionJob = null

        viewModelScope.launch {
            try {
                repository.cancel()
            } catch (_: Exception) {}

            jobToCancel?.cancel()
            _uiState.update { it.copy(status = TranscriptionStatus.Cancelled) }
        }
    }

    /**
     * Retries the last failed transcription if it is marked as retryable.
     */
    fun retry() {
        if (!_uiState.value.canRetry) return

        val lastAudio = _uiState.value.currentAudioMetadata ?: return
        val lastConfig = _uiState.value.config
        startTranscription(lastAudio, lastConfig)
    }

    /**
     * Resets the state back to Idle.
     */
    fun resetToIdle() {
        currentTranscriptionJob?.cancel()
        currentTranscriptionJob = null
        _uiState.update {
            it.copy(status = TranscriptionStatus.Idle)
        }
    }

    override fun onCleared() {
        super.onCleared()
        currentTranscriptionJob?.cancel()
        currentTranscriptionJob = null
    }
}
