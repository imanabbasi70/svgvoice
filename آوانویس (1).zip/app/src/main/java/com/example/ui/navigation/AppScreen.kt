package com.example.ui.navigation

import com.example.audio.AudioMetadata

sealed class AppScreen(val route: String, val title: String) {
    object Home : AppScreen("home", "خانه")
    object Record : AppScreen("record", "ضبط صدا")
    data class Result(
        val transcriptionId: String = "sample_1",
        val audioMetadata: AudioMetadata? = null
    ) : AppScreen("result", "متن تبدیل‌شده")
    object History : AppScreen("history", "تاریخچه")
    object Settings : AppScreen("settings", "تنظیمات")
}
