package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.stt.ServerConfig
import com.example.ui.theme.GoftinoPurple
import com.example.ui.theme.GoftinoPurpleContainer
import com.example.ui.theme.StudioRecordCoral
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

@Composable
fun SettingsScreen(
    isDarkTheme: Boolean,
    onToggleDarkTheme: (Boolean) -> Unit
) {
    val context = LocalContext.current
    var autoDeleteAudio by remember { mutableStateOf(false) }
    var isTesting by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    var backendUrlInput by remember { mutableStateOf(ServerConfig.getBaseUrl(context)) }
    var saveSuccessMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .verticalScroll(rememberScrollState())
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Section 1: Appearance
        Text(
            text = "ظاهر و تم برنامه",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = GoftinoPurple
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFEEEEEE), RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(GoftinoPurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DarkMode,
                            contentDescription = null,
                            tint = GoftinoPurple,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "تم تاریک فعال باشد",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoftinoPurple
                        )
                        Text(
                            text = "تغییر تم رنگی اپلیکیشن به تیره",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = onToggleDarkTheme,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = GoftinoPurple,
                        uncheckedThumbColor = Color.White,
                        uncheckedTrackColor = Color(0xFFE0E0E0)
                    ),
                    modifier = Modifier.testTag("dark_theme_switch")
                )
            }
        }

        // Section 2: Backend & Proxy Info
        Text(
            text = "تنظیمات اتصال به سرور",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = GoftinoPurple
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFEEEEEE), RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(GoftinoPurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = GoftinoPurple,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "نشانی سرور رونویسی",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoftinoPurple
                        )
                        Text(
                            text = "آدرس متصل به پردازشگر صوتی",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Editable backend URL field
                OutlinedTextField(
                    value = backendUrlInput,
                    onValueChange = {
                        backendUrlInput = it
                        saveSuccessMsg = ""
                    },
                    label = { Text("آدرس سرور رونویسی") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("backend_url_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoftinoPurple,
                        unfocusedBorderColor = Color(0xFFE0E0E0),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                // Buttons: Save & Reset
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            ServerConfig.setBaseUrl(context, backendUrlInput)
                            saveSuccessMsg = "آدرس با موفقیت ذخیره شد ✓"
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoftinoPurple,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ذخیره آدرس")
                    }

                    OutlinedButton(
                        onClick = {
                            ServerConfig.resetToDefault(context)
                            backendUrlInput = ServerConfig.getBaseUrl(context)
                            saveSuccessMsg = "به آدرس پیش‌فرض شبیه‌ساز بازگردانده شد"
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("پیش‌فرض")
                    }
                }

                if (saveSuccessMsg.isNotEmpty()) {
                    Text(
                        text = saveSuccessMsg,
                        style = MaterialTheme.typography.bodySmall,
                        color = GoftinoPurple,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Test Connection Button
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            isTesting = true
                            testStatus = ""
                            val currentUrl = ServerConfig.normalize(backendUrlInput)
                            val healthUrl = "${currentUrl}health"
                            val client = OkHttpClient.Builder()
                                .connectTimeout(10, TimeUnit.SECONDS)
                                .readTimeout(10, TimeUnit.SECONDS)
                                .addInterceptor { chain ->
                                    val req = chain.request().newBuilder()
                                        .addHeader("bypass-tunnel-reminder", "true")
                                        .addHeader("User-Agent", "AvaNevis/1.0.0")
                                        .build()
                                    chain.proceed(req)
                                }
                                .build()
                            val request = Request.Builder().url(healthUrl).build()
                            val result = withContext(Dispatchers.IO) {
                                try {
                                    val res = client.newCall(request).execute()
                                    val bodyStr = res.body?.string() ?: ""
                                    if (res.code == 200) {
                                        "اتصال برقرار است ✓ (HTTP 200 OK)"
                                    } else {
                                        "خطای پاسخ سرور (HTTP ${res.code}): ${bodyStr.take(100)}"
                                    }
                                } catch (e: Exception) {
                                    "خطا در برقراری ارتباط با $healthUrl: ${e.message}"
                                }
                            }
                            testStatus = result
                            isTesting = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_backend_url_button"),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isTesting,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = GoftinoPurple
                    )
                ) {
                    Text(if (isTesting) "در حال تست..." else "تست اتصال به سرور (/health)")
                }

                if (testStatus.isNotEmpty()) {
                    Text(
                        text = testStatus,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = if (testStatus.contains("اتصال برقرار است")) GoftinoPurple else StudioRecordCoral,
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .testTag("connection_test_status")
                    )
                }
            }
        }

        // Section 3: Privacy & Security
        Text(
            text = "حریم خصوصی و حافظه",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = GoftinoPurple
        )

        OutlinedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.outlinedCardColors(
                containerColor = Color.White
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE0E0E0))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = GoftinoPurple,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "امنیت ۱۰۰٪ داده‌ها",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoftinoPurple
                    )
                }
                Text(
                    text = "فایل‌های صوتی و متن‌های رونویسی‌شده صرفاً در حافظه داخلی گوشی شما نگهداری می‌شوند و هر زمان بخواهید با یک کلیک قابل پاک‌سازی هستند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = { /* Clear action fallback */ },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clear_all_data_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = StudioRecordCoral
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "پاک‌سازی داده‌ها",
                        tint = StudioRecordCoral,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "پاک‌سازی تمام تاریخچه و فایل‌های صوتی",
                        color = StudioRecordCoral,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Section 4: App Version Info
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "گفتینو (Goftino) — نسخه ۱.۰.۰",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "طراحی‌شده با متریال ۳ فارسی",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}
