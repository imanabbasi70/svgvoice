package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioFileImporter
import com.example.audio.AudioMetadata
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FileImportUiState(
    val isImporting: Boolean = false,
    val loadingMessage: String? = null,
    val errorMessage: String? = null
)

class FileImportViewModel(application: Application) : AndroidViewModel(application) {

    private val importer = AudioFileImporter(application.applicationContext)

    private val _uiState = MutableStateFlow(FileImportUiState())
    val uiState: StateFlow<FileImportUiState> = _uiState.asStateFlow()

    fun importAudioFile(uri: Uri, onSuccess: (AudioMetadata) -> Unit) {
        _uiState.update {
            it.copy(
                isImporting = true,
                loadingMessage = "در حال کپی و بررسی فایل صوتی...",
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val result = importer.importAudioFile(uri)
            if (result.isSuccess) {
                _uiState.update { it.copy(isImporting = false, loadingMessage = null) }
                onSuccess(result.getOrThrow())
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "خطا در خواندن فایل صوتی."
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        loadingMessage = null,
                        errorMessage = errorMsg
                    )
                }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}
