package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val ModernStudioDarkColorScheme = darkColorScheme(
    primary = StudioNeonCyan,
    onPrimary = StudioDarkBackground,
    primaryContainer = StudioNeonCyanContainer,
    onPrimaryContainer = StudioCyanLight,
    secondary = StudioCyanLight,
    onSecondary = StudioDarkBackground,
    secondaryContainer = StudioDarkSurfaceVariant,
    onSecondaryContainer = StudioTextPrimaryDark,
    tertiary = StudioRecordCoral,
    onTertiary = StudioTextPrimaryDark,
    tertiaryContainer = StudioRecordCoralContainer,
    onTertiaryContainer = StudioRecordCoral,
    background = StudioDarkBackground,
    onBackground = StudioTextPrimaryDark,
    surface = StudioDarkSurface,
    onSurface = StudioTextPrimaryDark,
    surfaceVariant = StudioDarkSurfaceVariant,
    onSurfaceVariant = StudioTextSecondaryDark,
    outline = StudioDarkCardBorder,
    outlineVariant = StudioDarkCardBorder
)

val ModernStudioLightColorScheme = lightColorScheme(
    primary = StudioCyanDeep,
    onPrimary = StudioLightSurface,
    primaryContainer = StudioCyanDeepContainer,
    onPrimaryContainer = StudioCyanDeep,
    secondary = StudioCyanDeep,
    onSecondary = StudioLightSurface,
    secondaryContainer = StudioLightSurfaceVariant,
    onSecondaryContainer = StudioTextPrimaryLight,
    tertiary = StudioRecordCoral,
    onTertiary = StudioLightSurface,
    tertiaryContainer = StudioRecordCoralContainer,
    onTertiaryContainer = StudioRecordCoral,
    background = StudioLightBackground,
    onBackground = StudioTextPrimaryLight,
    surface = StudioLightSurface,
    onSurface = StudioTextPrimaryLight,
    surfaceVariant = StudioLightSurfaceVariant,
    onSurfaceVariant = StudioTextSecondaryLight,
    outline = StudioLightCardBorder,
    outlineVariant = StudioLightCardBorder
)

@Composable
fun AvaNevisTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ModernStudioDarkColorScheme else ModernStudioLightColorScheme

    // Enforce RTL direction globally for Persian language support
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
