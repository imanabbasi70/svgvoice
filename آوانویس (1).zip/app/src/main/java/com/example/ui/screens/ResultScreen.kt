package com.example.ui.screens

import android.util.Log

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.audio.AudioMetadata
import com.example.audio.stt.TranscriptionError
import com.example.audio.stt.TranscriptionStatus
import com.example.diagnostic.DiagnosticLogger
import com.example.ui.components.DiagnosticOverlayCard
import com.example.ui.model.MockDataProvider
import com.example.ui.theme.*
import com.example.ui.viewmodel.TranscriptionViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    transcriptionId: String? = null,
    audioMetadata: AudioMetadata? = null,
    viewModel: TranscriptionViewModel = viewModel(),
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val uiState by viewModel.uiState.collectAsState()

    var currentTitle by remember { mutableStateOf("یادداشت صوتی هوشمند") }
    var currentText by remember { mutableStateOf("") }
    var isCopiedAnim by remember { mutableStateOf(false) }

    // Intercept hardware/gesture back press
    BackHandler {
        if (uiState.isProcessing) {
            viewModel.cancelTranscription()
        }
        onNavigateBack()
    }

    // Load initial data
    LaunchedEffect(transcriptionId, audioMetadata) {
        if (transcriptionId != null) {
            val item = MockDataProvider.sampleList.find { it.id == transcriptionId }
            if (item != null) {
                currentTitle = item.title
                currentText = item.fullText
            }
        } else if (audioMetadata != null) {
            currentTitle = audioMetadata.displayName ?: "یادداشت صوتی جدید"
            viewModel.startTranscription(audioMetadata)
        }
    }

    // React to successful transcription results
    LaunchedEffect(uiState.status) {
        val status = uiState.status
        if (status is TranscriptionStatus.Success) {
            currentText = if (status.result.fullText.isNotBlank()) {
                status.result.fullText
            } else {
                "هیچ کلام یا گفتاری در فایل صوتی شناسایی نشد (فایل فاقد کلام یا سکوت بود)."
            }
            DiagnosticLogger.logUiDisplay(currentText.length)
            Log.i("ResultScreen", "[PIPELINE] UI_UPDATE")
            Log.i("ResultScreen", "[UI] state=Success textLength=${currentText.length} textPreview=${currentText.take(40)}")
            println("[PIPELINE] UI_UPDATE")
            println("[UI] state=Success textLength=${currentText.length} textPreview=${currentText.take(40)}")
        } else {
            Log.i("ResultScreen", "[UI] state=${status::class.simpleName ?: "Unknown"} textLength=${currentText.length}")
        }
    }

    fun shareText(textToShare: String) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, textToShare)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "اشتراک‌گذاری متن یادداشت")
        context.startActivity(shareIntent)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("result_screen"),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "نتیجه تبدیل گفتار",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (uiState.isProcessing) viewModel.cancelTranscription()
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("result_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { shareText(currentText) },
                        modifier = Modifier.testTag("result_top_share")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "اشتراک‌گذاری",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Audio Info Badges Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Duration Badge
                val duration = audioMetadata?.durationFormatted ?: "۰۱:۱۵"
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = duration,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Word Count Badge
                val wordCount = currentText.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }.size
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Subject,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "$wordCount کلمه",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // AI Model Tag
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = VoiceAiIndigoContainer.copy(alpha = 0.5f),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(VoiceAiIndigo, VoiceAiCyan))
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = VoiceAiCyanGlow
                        )
                        Text(
                            text = "Gemini Flash AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = VoiceAiIndigoLight,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Processing Banner (Animated)
            AnimatedVisibility(visible = uiState.isProcessing) {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("result_processing_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(VoiceAiIndigo, VoiceAiCyan))
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 3.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Column {
                                    Text(
                                        text = when (uiState.status) {
                                            is TranscriptionStatus.Uploading -> "در حال آماده‌سازی و ارسال فایل صوتی..."
                                            else -> "در حال پردازش گفتار فارسی با هوش مصنوعی..."
                                        },
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "تشخیص واژگان، علائم نگارشی و ساختار جمله",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            IconButton(
                                onClick = { viewModel.cancelTranscription() },
                                modifier = Modifier.testTag("result_cancel_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "لغو",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }

                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surface
                        )
                    }
                }
            }

            // Error Banner
            AnimatedVisibility(visible = uiState.status is TranscriptionStatus.Error) {
                val error = (uiState.status as? TranscriptionStatus.Error)?.error
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("result_error_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = "خطا",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = "خطا در پردازش صوت",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Text(
                            text = error?.userMessagePersian ?: "خطای ناشناخته رخ داده است.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        if (uiState.canRetry) {
                            Button(
                                onClick = { viewModel.retry() },
                                modifier = Modifier.align(Alignment.End).testTag("result_retry_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "تلاش مجدد",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تلاش مجدد")
                            }
                        }
                    }
                }
            }

            // Title Editor
            OutlinedTextField(
                value = currentTitle,
                onValueChange = { currentTitle = it },
                label = { Text("عنوان یادداشت") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("result_title_input"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                singleLine = true
            )

            // Main Text Editor Area (Spacious & Clean Persian Typography)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "متن پیاده‌سازی شده (قابل ویرایش):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(currentText))
                                isCopiedAnim = true
                                scope.launch {
                                    snackbarHostState.showSnackbar("متن در حافظه کپی شد ✓")
                                    delay(2000)
                                    isCopiedAnim = false
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (isCopiedAnim) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "کپی",
                                tint = if (isCopiedAnim) VoiceAiSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = currentText,
                        onValueChange = { currentText = it },
                        placeholder = {
                            Text(
                                if (uiState.isProcessing) "در حال استخراج گفتار با هوش مصنوعی..."
                                else "متن حاصل از تبدیل صوت در این بخش قرار می‌گیرد..."
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .testTag("result_text_editor"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        ),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 16.sp,
                            lineHeight = 30.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            // Primary Action Buttons (Copy & Share & New Recording)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(currentText))
                        isCopiedAnim = true
                        scope.launch {
                            snackbarHostState.showSnackbar("متن با موفقیت کپی شد ✓")
                            delay(2000)
                            isCopiedAnim = false
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("result_copy_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCopiedAnim) VoiceAiSuccess else MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = if (isCopiedAnim) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = "کپی",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isCopiedAnim) "کپی شد!" else "کپی متن",
                        fontWeight = FontWeight.Bold
                    )
                }

                FilledTonalButton(
                    onClick = { shareText(currentText) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("result_share_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "ارسال",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "اشتراک‌گذاری", fontWeight = FontWeight.Bold)
                }
            }

            // Quick New Voice Action
            OutlinedButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("result_new_voice_button"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "شروع ضبط یا تبدیل جدید", fontWeight = FontWeight.Medium)
            }

            // Real Device Live Diagnostic Panel
            DiagnosticOverlayCard(modifier = Modifier.padding(top = 12.dp, bottom = 24.dp))

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
