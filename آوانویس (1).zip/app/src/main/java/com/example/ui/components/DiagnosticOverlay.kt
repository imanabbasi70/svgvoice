package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.diagnostic.DiagnosticLogger
import com.example.diagnostic.DiagnosticState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DiagnosticOverlayCard(
    modifier: Modifier = Modifier
) {
    val diagState by DiagnosticLogger.state.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    var isExpanded by remember { mutableStateOf(true) }
    var urlInput by remember { mutableStateOf(diagState.customBackendUrl) }
    var copiedFeedback by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("diagnostic_overlay_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                listOf(
                    MaterialTheme.colorScheme.primary,
                    MaterialTheme.colorScheme.tertiary
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "عیب‌یابی",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "پنل عیب‌یابی زنده (Diagnostic Mode)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            val report = diagState.toFormattedReport()
                            clipboardManager.setText(AnnotatedString(report))
                            copiedFeedback = true
                        },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("btn_copy_diagnostic_report")
                    ) {
                        Icon(
                            imageVector = if (copiedFeedback) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "کپی گزارش",
                            tint = if (copiedFeedback) Color(0xFF10B981) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "باز/بسته",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Stage Badges Grid
                    Text(
                        text = "مراحل زنجیره (Pipeline Stages):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StageBadge("PERM", diagState.recordPermission)
                        StageBadge("START", diagState.recordingStart)
                        StageBadge("ACTIVE", diagState.recordingActive)
                        StageBadge("STOP", diagState.recordingStop)
                        StageBadge("FILE", diagState.fileValidation)
                        StageBadge("TRANS_START", diagState.transcriptionStart)
                        StageBadge("NET_START", diagState.networkStart)
                        StageBadge("NET_RESP", diagState.networkResponse)
                        StageBadge("TXT_RCVD", diagState.textReceived)
                        StageBadge("UI_DISP", diagState.uiDisplay)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // File Details Section
                    val fileInfo = diagState.fileInfo
                    Text(
                        text = "مشخصات فایل صوتی ضبط‌شده:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        CodeText("permission: ${fileInfo.permission}")
                        CodeText("recordingStarted: ${fileInfo.recordingStarted}")
                        CodeText("recordingStopped: ${fileInfo.recordingStopped}")
                        CodeText("fileExists: ${fileInfo.fileExists}")
                        CodeText("filePath: ${fileInfo.filePath}")
                        CodeText("fileSizeBytes: ${fileInfo.fileSizeBytes} B")
                        CodeText("durationMs: ${fileInfo.durationMs} ms")
                        CodeText("mimeType: ${fileInfo.mimeType}")
                        CodeText("hasAudioTrack: ${fileInfo.hasAudioTrack}")
                    }

                    // Network Details Section
                    val netInfo = diagState.networkInfo
                    Text(
                        text = "جزئیات درخواست شبکه (HTTP/Backend):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        CodeText("REQUEST_URL: ${netInfo.requestUrl.ifBlank { "Not sent yet" }}")
                        CodeText("HTTP_METHOD: ${netInfo.httpMethod}")
                        CodeText("REQUEST_STARTED: ${netInfo.requestStarted}")
                        CodeText("HTTP_STATUS: ${netInfo.httpStatus}")
                        CodeText("RESPONSE_LENGTH: ${netInfo.responseBodyLength} chars")
                        if (netInfo.responseBodyPreview.isNotBlank()) {
                            CodeText("RESPONSE_PREVIEW: ${netInfo.responseBodyPreview.take(150)}")
                        }
                        if (netInfo.requestExceptionClass.isNotBlank()) {
                            CodeText("EXCEPTION_CLASS: ${netInfo.requestExceptionClass}", isError = true)
                            CodeText("EXCEPTION_MSG: ${netInfo.requestExceptionMessage}", isError = true)
                            CodeText("EXCEPTION_CAUSE: ${netInfo.requestExceptionCause}", isError = true)
                        }
                        if (netInfo.responseBodyError.isNotBlank()) {
                            CodeText("RESPONSE_ERROR_BODY: ${netInfo.responseBodyError}", isError = true)
                        }
                    }

                    // Editable Backend URL Section
                    Text(
                        text = "آدرس Backend (قابل ویرایش):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = {
                                urlInput = it
                                DiagnosticLogger.updateBackendUrl(it)
                            },
                            placeholder = { Text("https://your-backend-domain.com/") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("diagnostic_url_input"),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                        )

                        Button(
                            onClick = {
                                DiagnosticLogger.updateBackendUrl(urlInput)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("اعمال", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    // Log Trail Box
                    Text(
                        text = "لاین زنده لاگ (Real-time Log Trail):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B))
                            .padding(8.dp)
                    ) {
                        val scrollState = rememberScrollState()
                        LaunchedEffect(diagState.logs.size) {
                            scrollState.scrollTo(scrollState.maxValue)
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(scrollState)
                        ) {
                            diagState.logs.forEach { logLine ->
                                Text(
                                    text = logLine,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (logLine.contains("FAIL") || logLine.contains("ERROR") || logLine.contains("Exc=")) Color(0xFFF87171) else Color(0xFF38BDF8)
                                    )
                                )
                            }
                        }
                    }

                    // Copy Full Diagnostic Report Button
                    Button(
                        onClick = {
                            val report = diagState.toFormattedReport()
                            clipboardManager.setText(AnnotatedString(report))
                            copiedFeedback = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_copy_full_report"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = if (copiedFeedback) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (copiedFeedback) "گزارش در حافظه کپی شد ✓" else "کپی کامل گزارش عیب‌یابی (برای ارسال به توسعه‌دهنده)",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StageBadge(label: String, status: String) {
    val (bgColor, textColor) = when (status) {
        "PASS" -> Color(0xFF059669) to Color.White
        "FAIL" -> Color(0xFFDC2626) to Color.White
        else -> MaterialTheme.colorScheme.surface to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(0.5.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(
            text = "$label: $status",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            ),
            color = textColor
        )
    }
}

@Composable
private fun CodeText(text: String, isError: Boolean = false) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = if (isError) Color(0xFFDC2626) else MaterialTheme.colorScheme.onSurface
        )
    )
}
