package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.audio.AudioMetadata
import com.example.audio.SampleAudioItem
import com.example.audio.SampleAudioProvider
import com.example.audio.stt.TranscriptionStatus
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.ui.components.DiagnosticOverlayCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.RecorderViewModel
import com.example.ui.viewmodel.TranscriptionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    recorderViewModel: RecorderViewModel,
    transcriptionViewModel: TranscriptionViewModel,
    onAudioFileSelected: (Uri) -> Unit,
    onFinishAndTranscribe: (AudioMetadata) -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val recorderState by recorderViewModel.uiState.collectAsState()
    val transcriptionState by transcriptionViewModel.uiState.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var showSampleSheet by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            recorderViewModel.startRecording()
        } else {
            recorderViewModel.setError("دسترسی میکروفون فعال نیست.")
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { onAudioFileSelected(it) }
    }

    val isRecording = recorderState.isRecording
    val isPaused = recorderState.isPaused
    val isProcessing = transcriptionState.isProcessing

    // Ambient pulsing animation for idle/recording states
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isRecording) 1.22f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isRecording) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = if (isRecording) 0.8f else 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isRecording) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_alpha"
    )

    // Rotating progress for AI processing
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("home_screen"),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "لوگو",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "آوانویس هوشمند",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "تبدیل گفتار به متن با هوش مصنوعی",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    // Secondary action: Import audio file
                    IconButton(
                        onClick = { filePickerLauncher.launch(arrayOf("audio/*")) },
                        modifier = Modifier.testTag("home_btn_import_file")
                    ) {
                        Icon(
                            imageVector = Icons.Default.UploadFile,
                            contentDescription = "آپلود فایل صوتی",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // Test sample modal
                    IconButton(
                        onClick = { showSampleSheet = true },
                        modifier = Modifier.testTag("home_btn_samples")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "نمونه‌های صوتی تستی",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Error Alert Banner if recording failed
            if (recorderState.errorMessage != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "هشدار",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = recorderState.errorMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        IconButton(
                            onClick = { recorderViewModel.clearError() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "بستن",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            // ==========================================
            // STATUS PILL (Live Context Indicator)
            // ==========================================
            AnimatedContent(
                targetState = when {
                    isProcessing -> "processing"
                    isRecording && isPaused -> "paused"
                    isRecording -> "recording"
                    else -> "idle"
                },
                label = "status_pill_transition"
            ) { state ->
                val (pillBg, pillTextColor, pillText, pillDotColor) = when (state) {
                    "processing" -> Tuple4(
                        VoiceAiIndigoContainer.copy(alpha = 0.5f),
                        VoiceAiIndigoLight,
                        "در حال پردازش هوش مصنوعی Gemini...",
                        VoiceAiIndigoLight
                    )
                    "recording" -> Tuple4(
                        VoiceAiRecordCoral.copy(alpha = 0.12f),
                        VoiceAiRecordCoral,
                        "در حال ضبط صدا (زنده)",
                        VoiceAiRecordCoral
                    )
                    "paused" -> Tuple4(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.onSurfaceVariant,
                        "ضبط موقتاً متوقف شد",
                        Color.Gray
                    )
                    else -> Tuple4(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        MaterialTheme.colorScheme.onSurfaceVariant,
                        "آماده برای گفتار فارسی",
                        VoiceAiSuccess
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(pillBg)
                        .border(
                            1.dp,
                            if (state == "recording") VoiceAiRecordCoral.copy(alpha = 0.3f) else Color.Transparent,
                            RoundedCornerShape(24.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(pillDotColor)
                    )
                    Text(
                        text = pillText,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium,
                        color = pillTextColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ==========================================
            // REAL-TIME AUDIO WAVEFORM VISUALIZER
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isRecording) {
                    AudioWaveformVisualizer(
                        amplitudes = recorderState.amplitudes,
                        isPaused = isPaused,
                        color = VoiceAiRecordCoral
                    )
                } else if (isProcessing) {
                    AiWaveformShimmer(rotation = rotationAngle)
                } else {
                    // Subtle resting soundline
                    IdleAudioSoundline()
                }
            }

            // ==========================================
            // CENTER STAGE: GIANT GLOWING VOICE AI MIC
            // ==========================================
            Box(
                modifier = Modifier
                    .size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Breathing Ambient Aura
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    if (isRecording) VoiceAiRecordCoral.copy(alpha = auraAlpha * 0.4f)
                                    else VoiceAiIndigo.copy(alpha = auraAlpha * 0.35f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Secondary Ripple Ring
                Box(
                    modifier = Modifier
                        .size(175.dp)
                        .scale(if (isRecording) pulseScale * 0.95f else 1.04f)
                        .clip(CircleShape)
                        .border(
                            1.5.dp,
                            if (isRecording) VoiceAiRecordCoral.copy(alpha = 0.5f)
                            else VoiceAiIndigoLight.copy(alpha = 0.25f),
                            CircleShape
                        )
                )

                // AI Processing Spinner Ring
                if (isProcessing) {
                    Canvas(modifier = Modifier.size(150.dp)) {
                        drawCircle(
                            brush = Brush.sweepGradient(
                                listOf(Color.Transparent, VoiceAiCyan, VoiceAiIndigo, Color.Transparent)
                            ),
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }

                // Core Giant Microphone Button (130dp)
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .shadow(
                            elevation = if (isRecording) 16.dp else 10.dp,
                            shape = CircleShape,
                            spotColor = if (isRecording) VoiceAiRecordCoral else VoiceAiIndigo
                        )
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = when {
                                    isRecording -> listOf(VoiceAiRecordCoral, Color(0xFFE11D48))
                                    isProcessing -> listOf(VoiceAiIndigo, VoiceAiCyan)
                                    else -> listOf(VoiceAiIndigo, VoiceAiIndigoDark)
                                }
                            )
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, color = Color.White)
                        ) {
                            if (isProcessing) return@clickable

                            if (isRecording) {
                                // Stop and transcribe
                                recorderViewModel.stopRecording { metadata ->
                                    onFinishAndTranscribe(metadata)
                                }
                            } else {
                                // Start recording
                                if (!hasMicPermission) {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    recorderViewModel.startRecording()
                                }
                            }
                        }
                        .testTag("giant_center_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            isProcessing -> Icons.Default.AutoAwesome
                            isRecording -> Icons.Default.Stop
                            else -> Icons.Default.Mic
                        },
                        contentDescription = "دکمه میکروفون ضبط صدا",
                        tint = Color.White,
                        modifier = Modifier.size(56.dp)
                    )
                }
            }

            // ==========================================
            // DYNAMIC TIMER & PROMPT GUIDE
            // ==========================================
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (isRecording) {
                    Text(
                        text = recorderState.timerFormatted,
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (isPaused) "برای ادامه یا اتمام روی دکمه‌های زیر بزنید" else "در حال شنیدن و ضبط کلام...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (isProcessing) {
                    Text(
                        text = "در حال تحلیل گفتار...",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "هوش مصنوعی در حال تبدیل صوت به متن با علائم نگارشی است",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        text = "برای شروع ضبط لمس کنید",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "کلام شما با دقت بالا به متن فارسی تبدیل و ویرایش می‌شود",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // ==========================================
            // RECORDING CONTROLS BAR (Active only while recording)
            // ==========================================
            AnimatedVisibility(
                visible = isRecording,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Cancel Button
                    OutlinedIconButton(
                        onClick = { recorderViewModel.cancelRecording() },
                        shape = CircleShape,
                        modifier = Modifier.size(52.dp).testTag("rec_control_cancel"),
                        colors = IconButtonDefaults.outlinedIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "لغو ضبط",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }

                    // Pause / Resume Button
                    FilledTonalIconButton(
                        onClick = { recorderViewModel.togglePauseResume() },
                        shape = CircleShape,
                        modifier = Modifier.size(60.dp).testTag("rec_control_pause"),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = "مکث یا ادامه",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Done & Transcribe Button
                    FilledIconButton(
                        onClick = {
                            recorderViewModel.stopRecording { metadata ->
                                onFinishAndTranscribe(metadata)
                            }
                        },
                        shape = CircleShape,
                        modifier = Modifier.size(52.dp).testTag("rec_control_done"),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = VoiceAiSuccess
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "اتمام و تبدیل به متن",
                            tint = Color.White
                        )
                    }
                }
            }

            // ==========================================
            // BOTTOM UTILITY CHIP: FAST EMULATOR TEST
            // ==========================================
            if (!isRecording) {
                Surface(
                    onClick = { showSampleSheet = true },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(VoiceAiIndigo.copy(alpha = 0.3f), VoiceAiCyan.copy(alpha = 0.3f))
                        )
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("home_quick_sample_bar")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = "تست فوری با صدای نمونه فارسی",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "مناسب برای تست تبدیل در شبیه‌ساز",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Real Device Live Diagnostic Panel
            DiagnosticOverlayCard(modifier = Modifier.padding(bottom = 24.dp))
        }
    }

    // ==========================================
    // SAMPLE AUDIO BOTTOM SHEET
    // ==========================================
    if (showSampleSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSampleSheet = false },
            sheetState = rememberModalBottomSheetState(),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "نمونه‌های صوتی فارسی آماده تست",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "برای تبدیل مستقیم هوش مصنوعی یکی را انتخاب کنید",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                SampleAudioProvider.samples.forEach { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                showSampleSheet = false
                                val metadata = SampleAudioProvider.loadSample(context, item)
                                if (metadata != null) {
                                    onFinishAndTranscribe(metadata)
                                }
                            }
                            .testTag("sample_sheet_item_" + item.id),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = item.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            FilledTonalButton(
                                onClick = {
                                    showSampleSheet = false
                                    val metadata = SampleAudioProvider.loadSample(context, item)
                                    if (metadata != null) {
                                        onFinishAndTranscribe(metadata)
                                    }
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("تبدیل", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

// ==========================================
// AUDIO WAVEFORM COMPOSABLES
// ==========================================

@Composable
fun AudioWaveformVisualizer(
    amplitudes: List<Float>,
    isPaused: Boolean,
    color: Color
) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .padding(horizontal = 16.dp)
    ) {
        val width = size.width
        val height = size.height
        val barCount = amplitudes.size.coerceAtLeast(1)
        val barSpacing = width / (barCount * 1.6f)
        val barWidth = barSpacing * 0.6f

        val startX = (width - (barCount * barSpacing)) / 2f

        amplitudes.forEachIndexed { index, amp ->
            val effectiveAmp = if (isPaused) 0.15f else amp.coerceIn(0.12f, 1.0f)
            val barHeight = (height * 0.8f * effectiveAmp).coerceAtLeast(6f)
            val x = startX + (index * barSpacing)
            val y = (height - barHeight) / 2f

            drawRoundRect(
                color = color.copy(alpha = if (isPaused) 0.4f else 0.85f),
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}

@Composable
fun IdleAudioSoundline() {
    Canvas(
        modifier = Modifier
            .width(180.dp)
            .height(30.dp)
    ) {
        val width = size.width
        val height = size.height
        val barCount = 14
        val barSpacing = width / barCount
        val barWidth = 3.dp.toPx()

        for (i in 0 until barCount) {
            val centerDist = kotlin.math.abs(i - (barCount / 2f)) / (barCount / 2f)
            val barHeight = ((1f - centerDist * 0.7f) * height * 0.5f).coerceAtLeast(4.dp.toPx())
            val x = i * barSpacing + (barSpacing - barWidth) / 2f
            val y = (height - barHeight) / 2f

            drawRoundRect(
                color = Color.Gray.copy(alpha = 0.25f),
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}

@Composable
fun AiWaveformShimmer(rotation: Float) {
    Canvas(
        modifier = Modifier
            .width(220.dp)
            .height(40.dp)
    ) {
        val width = size.width
        val height = size.height
        val barCount = 18
        val barSpacing = width / barCount
        val barWidth = 4.dp.toPx()

        for (i in 0 until barCount) {
            val phase = (i.toFloat() / barCount * 360f + rotation) % 360f
            val rad = Math.toRadians(phase.toDouble()).toFloat()
            val amp = (kotlin.math.sin(rad) + 1f) / 2f
            val barHeight = (height * (0.2f + 0.8f * amp)).coerceAtLeast(6f)
            val x = i * barSpacing
            val y = (height - barHeight) / 2f

            drawRoundRect(
                brush = Brush.verticalGradient(listOf(VoiceAiCyan, VoiceAiIndigo)),
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}

data class Tuple4<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
