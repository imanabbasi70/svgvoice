package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.AudioMetadata
import com.example.ui.theme.GoftinoGreenBg
import com.example.ui.theme.GoftinoGreenText
import com.example.ui.theme.GoftinoPurple
import com.example.ui.theme.GoftinoPurpleContainer
import com.example.ui.theme.StudioRecordCoral
import com.example.ui.theme.StudioSuccess
import com.example.ui.viewmodel.RecorderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordScreen(
    viewModel: RecorderViewModel,
    onNavigateBack: () -> Unit,
    onFinishAndTranscribe: (AudioMetadata) -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
        if (isGranted) {
            viewModel.startRecording()
        }
    }

    // Intercept back button to cancel recording safely
    BackHandler {
        if (uiState.isRecording) {
            viewModel.cancelRecording()
        }
        onNavigateBack()
    }

    // Handle and display error messages via Snackbar
    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { errorMsg ->
            snackbarHostState.showSnackbar(errorMsg)
            viewModel.clearError()
        }
    }

    // Infinite pulsing ripple effect for microphone recording
    val infiniteTransition = rememberInfiniteTransition()
    val rippleScale1 by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    val rippleAlpha1 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("record_screen_root"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. TOP HEADER STATUS BAR (Branding and direct download indicators matching the mockup)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Direct APK Download button on Left
                Button(
                    onClick = { /* Simulated action */ },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E3A8A), // Indigo blue color from mockup
                        contentColor = Color.White
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "دانلود مستقیم APK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Status Badge on Right: "اندروید آماده پردازش"
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(GoftinoGreenBg)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Online pulse green dot
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(GoftinoGreenText)
                    )
                    Text(
                        text = "اندروید آماده پردازش",
                        color = GoftinoGreenText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 2. MAIN LOGO ROW (گفتینو + Mic Icon)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "گفتینو",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = GoftinoPurple,
                    textAlign = TextAlign.Center
                )
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(GoftinoPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = GoftinoPurple,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Subtitle
            Text(
                text = "تبدیل آسان و سریع گفتار و صدای فارسی به متن",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3. TEXT PREVIEW CARD (• پیش‌نمایش متن)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "• پیش‌نمایش متن",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .border(1.dp, GoftinoPurple.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                        .testTag("preview_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome, // Sparkles AI icon from mockup
                                contentDescription = null,
                                tint = GoftinoPurple.copy(alpha = 0.7f),
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = if (uiState.isRecording) "در حال شنیدن و ضبط صدای شما..." else "برای شروع روی میکروفون بزنید و صحبت کنید",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoftinoPurple,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = if (uiState.isRecording) {
                                    if (uiState.isPaused) "ضبط صدا موقتاً متوقف شده است." else "صدای شما با دقت بالا در حال ذخیره‌سازی موقت است."
                                } else {
                                    "صدای شما با دقت بالا به متن فارسی تبدیل شده و در این کادر قرار می‌گیرد."
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4. TIMER & STATUS INDICATOR (00:00 - آماده)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .border(1.dp, GoftinoPurple.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Timer
                val minutes = (uiState.durationSeconds / 60).toString().padStart(2, '0')
                val seconds = (uiState.durationSeconds % 60).toString().padStart(2, '0')
                Text(
                    text = "$minutes:$seconds",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoftinoTextPrimary
                )

                // Divider line
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(14.dp)
                        .background(GoftinoPurple.copy(alpha = 0.2f))
                )

                // Status Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (uiState.isRecording) StudioRecordCoral else Color(0xFFFF5252))
                    )
                    Text(
                        text = if (uiState.isRecording) {
                            if (uiState.isPaused) "موقت" else "در حال ضبط"
                        } else {
                            "آماده"
                        },
                        color = if (uiState.isRecording) StudioRecordCoral else Color(0xFFFF5252),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 5. MICROPHONE BUTTON & ACTION AREA
            Box(
                modifier = Modifier
                    .size(170.dp),
                contentAlignment = Alignment.Center
            ) {
                // Pulsing Ripple behind microphone when recording
                if (uiState.isRecording && !uiState.isPaused) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .scale(rippleScale1)
                            .clip(CircleShape)
                            .background(GoftinoPurple.copy(alpha = rippleAlpha1))
                    )
                }

                // Main Purple Mic Toggle Button
                FilledIconButton(
                    onClick = {
                        if (!hasAudioPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (!uiState.isRecording) {
                                viewModel.startRecording()
                            } else {
                                // Tapping again finishes recording and transcribes (Goftino UX)
                                viewModel.stopRecording { metadata ->
                                    onFinishAndTranscribe(metadata)
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .size(80.dp)
                        .testTag("record_mic_button"),
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (uiState.isRecording && !uiState.isPaused) StudioRecordCoral else GoftinoPurple,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "میکروفون",
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Active Recording Overlaid controls (Discard / Pause/ Resume / Finish check)
                if (uiState.isRecording) {
                    // Discard / Cancel button on Left
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 4.dp)
                    ) {
                        OutlinedIconButton(
                            onClick = {
                                viewModel.cancelRecording()
                                onNavigateBack()
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("discard_record_button"),
                            shape = CircleShape,
                            colors = IconButtonDefaults.outlinedIconButtonColors(
                                containerColor = Color.White,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "انصراف",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Pause / Resume button on Right
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 4.dp)
                    ) {
                        FilledIconButton(
                            onClick = { viewModel.togglePauseResume() },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("record_toggle_pause_button"),
                            shape = CircleShape,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = GoftinoPurpleContainer,
                                contentColor = GoftinoPurple
                            )
                        ) {
                            Icon(
                                imageVector = if (uiState.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = "مکث",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Success Finish checkmark button at Top
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 4.dp)
                    ) {
                        FilledIconButton(
                            onClick = {
                                viewModel.stopRecording { metadata ->
                                    onFinishAndTranscribe(metadata)
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("finish_record_button"),
                            shape = CircleShape,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = StudioSuccess,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "تایید",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Labels under mic button
            Text(
                text = if (uiState.isRecording) "در حال ضبط صدا... ضربه بزنید تا رونویسی شود" else "برای شروع ضبط ضربه بزنید",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GoftinoPurple,
                textAlign = TextAlign.Center
            )

            Text(
                text = "برای شروع صحبت روی دکمه بزنید یا فایل آپلود کنید",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }
    }
}
