package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Goftino Purple & Elegant Light Palette (Core UI Concept)
val GoftinoPurple = Color(0xFF673AB7) // Primary Goftino Brand Violet
val GoftinoPurpleLight = Color(0xFFD1C4E9) // Accent purple tint
val GoftinoPurpleDark = Color(0xFF512DA8) // Darker shade of violet
val GoftinoPurpleContainer = Color(0xFFEDE7F6) // Soft violet background tint

// Green Badge (Android Ready for Processing Status)
val GoftinoGreenBg = Color(0xFFE8F5E9)
val GoftinoGreenText = Color(0xFF2E7D32)

// Premium UI Background & Surfaces
val GoftinoBackground = Color(0xFFF5F6FA) // Light clean background
val GoftinoSurface = Color(0xFFFFFFFF) // Pristine card surface
val GoftinoSurfaceVariant = Color(0xFFEDEFEF) // Subtle separator tint
val GoftinoBorder = Color(0xFFE0E0E0) // Delicate border line

// Text Colors
val GoftinoTextPrimary = Color(0xFF212121) // High contrast title text
val GoftinoTextSecondary = Color(0xFF666666) // Readable body text
val GoftinoTextMuted = Color(0xFF9E9E9E) // Unobtrusive caption text

// Keep original variable names for compatibility but map them to Goftino colors
val StudioDarkBackground = Color(0xFF12101A) // Deep violet-black
val StudioDarkSurface = Color(0xFF1D1A27) // Dark card
val StudioDarkSurfaceVariant = Color(0xFF272335)
val StudioDarkCardBorder = Color(0xFF38334B)
val StudioNeonCyan = GoftinoPurple // Remapped to Purple
val StudioNeonCyanContainer = Color(0xFF311B92)
val StudioCyanLight = Color(0xFFB39DDB)
val StudioRecordCoral = Color(0xFFE91E63) // Vibrant Accent / Active recording red
val StudioRecordCoralContainer = Color(0xFF880E4F)
val StudioTextPrimaryDark = Color(0xFFF3E5F5)
val StudioTextSecondaryDark = Color(0xFFB39DDB)
val StudioTextMutedDark = Color(0xFF7E57C2)

val StudioLightBackground = GoftinoBackground
val StudioLightSurface = GoftinoSurface
val StudioLightSurfaceVariant = GoftinoSurfaceVariant
val StudioLightCardBorder = GoftinoBorder
val StudioCyanDeep = GoftinoPurple
val StudioCyanDeepContainer = GoftinoPurpleContainer
val StudioTextPrimaryLight = GoftinoTextPrimary
val StudioTextSecondaryLight = GoftinoTextSecondary
val StudioTextMutedLight = GoftinoTextMuted

// Semantic Colors
val StudioSuccess = GoftinoGreenText
val StudioWarning = Color(0xFFFF9800)
val StudioNeonCyanContainerLight = GoftinoPurpleContainer
val StudioRecordCoralContainerLight = Color(0xFFFFEBEE)
