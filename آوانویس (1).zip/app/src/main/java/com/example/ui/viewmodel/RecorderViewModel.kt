package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioMetadata
import com.example.audio.AudioRecorderManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

import com.example.diagnostic.DiagnosticLogger

data class RecorderUiState(
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val durationSeconds: Long = 0L,
    val amplitudes: List<Float> = List(18) { 0.15f },
    val errorMessage: String? = null,
    val lastRecordedMetadata: AudioMetadata? = null
) {
    val timerFormatted: String
        get() {
            val minutes = durationSeconds / 60
            val seconds = durationSeconds % 60
            return String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
}

class RecorderViewModel(application: Application) : AndroidViewModel(application) {
    private val recorderManager = AudioRecorderManager(application.applicationContext)

    private val _uiState = MutableStateFlow(RecorderUiState())
    val uiState: StateFlow<RecorderUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var amplitudeJob: Job? = null

    fun startRecording(): Boolean {
        val recordingsDir = File(getApplication<Application>().filesDir, "recordings").apply {
            if (!exists()) mkdirs()
        }
        val outputFile = File(recordingsDir, "rec_${System.currentTimeMillis()}.m4a")
        val result = recorderManager.start(outputFile)
        return if (result.isSuccess) {
            _uiState.update {
                it.copy(
                    isRecording = true,
                    isPaused = false,
                    durationSeconds = 0L,
                    errorMessage = null
                )
            }
            startTimerAndVisualizer()
            true
        } else {
            val message = result.exceptionOrNull()?.localizedMessage ?: "شروع ضبط با خطا مواجه شد."
            _uiState.update { it.copy(errorMessage = message) }
            false
        }
    }

    fun togglePauseResume() {
        if (!_uiState.value.isRecording) return
        if (_uiState.value.isPaused) {
            val res = recorderManager.resume()
            if (res.isSuccess) {
                _uiState.update { it.copy(isPaused = false) }
            } else {
                _uiState.update { it.copy(errorMessage = "امکان ادامه ضبط وجود ندارد.") }
            }
        } else {
            val res = recorderManager.pause()
            if (res.isSuccess) {
                _uiState.update { it.copy(isPaused = true) }
            } else {
                _uiState.update { it.copy(errorMessage = "امکان مکث در ضبط وجود ندارد.") }
            }
        }
    }

    fun stopRecording(onSuccess: (AudioMetadata) -> Unit) {
        stopJobs()
        val result = recorderManager.stop()
        if (result.isSuccess) {
            val metadata = result.getOrThrow()
            _uiState.update {
                it.copy(
                    isRecording = false,
                    isPaused = false,
                    lastRecordedMetadata = metadata,
                    errorMessage = null
                )
            }
            onSuccess(metadata)
        } else {
            val error = result.exceptionOrNull()?.message ?: "خطا در ذخیره فایل صوتی."
            _uiState.update {
                it.copy(
                    isRecording = false,
                    isPaused = false,
                    errorMessage = error
                )
            }
        }
    }

    fun cancelRecording() {
        stopJobs()
        recorderManager.cancel()
        _uiState.update {
            it.copy(
                isRecording = false,
                isPaused = false,
                durationSeconds = 0L,
                errorMessage = null
            )
        }
    }

    fun setError(message: String) {
        _uiState.update { it.copy(errorMessage = message) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun startTimerAndVisualizer() {
        stopJobs()

        // 1-second increment timer
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                if (!_uiState.value.isPaused && _uiState.value.isRecording) {
                    val newSec = _uiState.value.durationSeconds + 1
                    _uiState.update { it.copy(durationSeconds = newSec) }
                    DiagnosticLogger.logRecordingActive(newSec)
                }
            }
        }

        // Approximate amplitude visualizer polling (~10 times/second)
        amplitudeJob = viewModelScope.launch {
            while (isActive) {
                delay(100L)
                if (!_uiState.value.isPaused && _uiState.value.isRecording) {
                    val rawAmp = recorderManager.getMaxAmplitude()
                    // Normalize 0..32767 to 0.15f..1.0f
                    val normalized = (rawAmp.toFloat() / 32767f).coerceIn(0.12f, 1.0f)
                    _uiState.update { current ->
                        val updated = current.amplitudes.drop(1) + normalized
                        current.copy(amplitudes = updated)
                    }
                }
            }
        }
    }

    private fun stopJobs() {
        timerJob?.cancel()
        timerJob = null
        amplitudeJob?.cancel()
        amplitudeJob = null
    }

    override fun onCleared() {
        super.onCleared()
        stopJobs()
        recorderManager.cancel()
    }
}
